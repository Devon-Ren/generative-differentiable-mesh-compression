# MeshSplatting → shared appearance → compressed delivery

This is a complete source package. Read `package.json` to identify the route:

- **dense**: original 30,000-step reconstruction → strict 4096-code dictionary
  (1,000 appearance steps) → 1024-code residual dictionary (full coverage,
  zero extra training) → q18 XYZ/q8 DC → strip-fetch reordering → causal XYZ
  prediction and custom shared-edge arithmetic coding → standalone decode/render.
- **collapse**: the same original reconstruction and dictionary seed preparation
  → historical hierarchy build at errors 1,2,4 → select error 2 → independent
  coarse optimization (800 steps) → refit shared dictionaries → shared appearance
  optimization (400 steps) → the same final codec → standalone decode/render.

The collapse route does not depend on a prior experiment or the dense package.
Its seed dictionaries are generated from its own reconstruction. Geometry uses
the local-altitude trust constraints; topology stays fixed during adaptation.
The dense route never invokes collapse. The packages include the complete original
upstream implementation and CUDA/CPU extension sources, plus our Stage 2 and codec.

## Historical reference points, not output-size guarantees

Room dense: 3,193,592 vertices / 6,452,971 triangles, 41.399 MB,
PSNR 27.9342, SSIM 0.861777, LPIPS 0.379369.
Room collapse: 2,005,918 vertices / 4,041,039 triangles, 26.883858 MB,
PSNR 27.3467449, SSIM 0.8579761, LPIPS 0.3971170.
These are earlier measured runs. Retraining is not bit-deterministic and input
images/cameras affect results. The collapse route remains an experimental quality
tradeoff: approximately 0.917 dB below its original Room test baseline. It exports
measurements even when quality drops. It is a single coarse asset, not progressive
base/patch delivery. The earlier Room q18 result had 47 orientation reversals and
one newly zero-area face after quantization. Reports retain these observations.

## Dependencies and first setup

Linux CUDA GPU, host C++ compiler, Python 3.11; reference runtime is
PyTorch 2.7.1+cu126 and CUDA toolkit 12.6 (nvcc). Existing NYU environment:

```bash
export STAGE2_ENV=/scratch/zr2245/conda-envs/pmsh-cu126
bash setup.sh
```

Run setup on a GPU node. It creates an isolated `.venv` inside THIS package,
inherits PyTorch, installs Python dependencies and builds bundled extensions.
Original `diff_triangle_rasterization` and our `stage2_triangle_rasterization`
have separate import names. CUDA libraries include the Conda targets directory.
Effrdel's helper modules are included and added to PYTHONPATH by env.sh.
First installation and the first LPIPS call may download dependencies/VGG weights.
This ZIP contains source, not CUDA binaries, datasets, pretrained scene checkpoints
or third-party runtime wheels. No other research code folder is required.

If building a fresh runtime rather than using the existing one:

```bash
conda create -n mesh-delivery python=3.11 pip -y
conda activate mesh-delivery
conda install -c nvidia/label/cuda-12.6.0 cuda-nvcc=12.6.20 cuda-libraries-dev cuda-nvtx cuda-cupti -y
python -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cu126
export STAGE2_ENV="$CONDA_PREFIX"
bash setup.sh
```

Package availability and supported driver/compiler must be checked on the target
cluster; use the already validated environment when available. `nvcc --version`
must report 12.6 for this reference setup.

## Input option A: raw multi-view photographs

Install the COLMAP command-line application separately (or load the cluster's
COLMAP module); `colmap -h` must work. Then:

```bash
bash run.sh --photos /absolute/path/to/photos --output /scratch/zr2245/new-scene-run
```

The package runs feature extraction, exhaustive matching, mapping, selects the
largest registered component, and undistorts images. It produces the cameras and
sparse points needed by MeshSplatting. COLMAP registration can fail with weak
overlap or texture; sfm-report.json records registered-image count and selected
component. This is multi-view reconstruction, not single-image generation.
COLMAP command reference: https://colmap.github.io/cli.html

## Input option B: prepared COLMAP dataset (Room reproduction)

```bash
bash run.sh --dataset /scratch/zr2245/datasets/m360/room \
  --images images_2 --output /scratch/zr2245/room-new-run
```

This starts at reconstruction, not from a previous trained asset. Dataset layout:
`images_2/` (or `images/`) and `sparse/0/{cameras,images,points3D}.bin`.
Use a new output path. On a login node, submit from THIS extracted directory:

```bash
sbatch --account=torch_pr_38_tandon_advanced submit.sh \
  --dataset /scratch/zr2245/datasets/m360/room --images images_2 \
  --output /scratch/zr2245/room-new-run
```

Edit/override account, GPU constraint, memory or time to match your allocation.
submit.sh builds dependencies on first execution. Its default requests one L40S,
48 GB RAM, eight CPUs and eight hours; completion time is not guaranteed.
Logs: `mesh-delivery-JOBID.out/.err` in the submission directory, and per-stage
logs under OUTPUT/logs. No backup or deletion of existing experiments occurs.

Collapse controls: `--coarse-error 1|2|4`, `--independent-steps 800`,
`--shared-steps 400`. `--independent-steps 0` directly shares the unadapted coarse.
Error thresholds do not prescribe a face count or guarantee a 50% reduction.

## Outputs

- `original/`: original reconstruction and its checkpoint.
- `strict/`, `shared/`: dictionary checkpoints, metrics and test PNGs.
- Dense: `delivery/asset.mslb`; collapse: `coarse/delivery/asset.mslb`.
- `decoded.pt`: recovered shared representation, no source checkpoint required.
- `decoded-render/png/`: all test GT/render pairs; `metrics.json`: per-view and mean.
- `result.json` and `results.csv`: original/final sizes, vertex/face counts,
  compression ratio versus raw PT and matched test metrics.
- Collapse additionally: `coarse/results.csv`, `coarse-summary.json`,
  intermediate measurements, collapse map and geometry/quantization reports.

Validation excludes adaptation views, but was seen during original reconstruction.
Test cameras are excluded from parameter/model selection. Quality is measured in
floating point before PNG serialization, LPIPS uses VGG; compare like protocols.

`--resume` skips stages with completion markers and identical configuration.
It does not promise mid-optimizer or mid-COLMAP recovery. Interrupted partial
stages may require a fresh output; existing assets are never silently overwritten.

## Independent decoder and renderer

After setup, source env.sh. CPU decode needs only the bitstream and a C++ compiler:

```bash
source env.sh
.venv/bin/python decode.py --asset /path/to/asset.mslb --output /path/to/decoded.pt
```

Add `--expand-sh` to recover independent per-vertex SH in an inference checkpoint.
The expanded tensor can be much larger than the compressed file. This is not a
training-resume checkpoint and synthesized training-statistic arrays are zeros.
No original asset, original vertex-ID permutation, dictionary seed or images are
needed for decode. On a CPU-only machine, install torch and requirements-runtime.txt
in a Python environment and call `python decode.py` directly; CUDA builds are not
needed for decoding. Use trusted input bitstreams; this is a research decoder.

GPU test-view rendering needs cameras/images, but no original scene checkpoint:

```bash
.venv/bin/python render_asset.py --asset /path/to/asset.mslb \
  --dataset /scratch/zr2245/datasets/m360/room --images images_2 \
  --output /path/to/new-render-output
```

This uses our bundled rasterizer and expands shared SH during rendering; compressed
file size is not GPU memory usage. Millions of triangles remain in these assets.

## Verification and provenance

`python verify.py` checks SOURCE_MANIFEST.json, allowing local scheduler/env edits.
UPSTREAM_PROVENANCE.json records original source hashes and explicit build-only
changes. Training and original rendering sources are copied unchanged.
TEST_REPORT.xml records local CPU tests. Full photo-to-asset GPU runs are not
re-executed locally for this packaging task. Historical core stages have HPC results;
the new orchestration and raw-photo COLMAP entry need end-to-end HPC validation.
All included upstream license notices remain in upstream/ and third-party folders.
