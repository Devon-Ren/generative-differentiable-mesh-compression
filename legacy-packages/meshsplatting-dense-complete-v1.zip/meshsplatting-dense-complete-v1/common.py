"""Shared CLI utilities; all paths are package-relative."""
import os,sys,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def setup_paths():
    for p in [ROOT/'stage2',ROOT/'stage2/codec',ROOT/'stage2/renderer',ROOT/'upstream',ROOT/'upstream/submodules/effrdel/src']:
        sys.path.insert(0,str(p))
def save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(obj,indent=2,allow_nan=False));tmp.replace(path)
def run(cmd,log,cwd=None):
    cmd=list(map(str,cmd));print('RUN',cmd,flush=True)
    log=Path(log);log.parent.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();env['PYTHONUNBUFFERED']='1'
    paths=[ROOT/'upstream/submodules/effrdel/src',ROOT/'stage2/renderer',ROOT/'stage2',ROOT/'stage2/codec']
    env['PYTHONPATH']=os.pathsep.join(map(str,paths))+os.pathsep+env.get('PYTHONPATH','')
    with log.open('w') as stream:
        process=subprocess.Popen(cmd,cwd=cwd or ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        for line in process.stdout:print(line,end='',flush=True);stream.write(line);stream.flush()
        code=process.wait()
    if code:raise subprocess.CalledProcessError(code,cmd)
