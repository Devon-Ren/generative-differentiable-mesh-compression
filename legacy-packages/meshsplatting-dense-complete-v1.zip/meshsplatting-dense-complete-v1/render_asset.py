"""Render a decoded delivery asset at dataset test cameras, without original PT."""
import argparse
from pathlib import Path
from types import SimpleNamespace
from common import setup_paths,save
setup_paths()
import torch
from decode import decode
from model import SharedMesh
from runtime import Evaluator

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for k in ('asset','dataset','output'):p.add_argument('--'+k,required=True)
    p.add_argument('--images',default='images');a=p.parse_args()
    if not torch.cuda.is_available():p.error('CUDA GPU required for rasterization; decoding alone is CPU-only')
    from scene.dataset_readers import readColmapSceneInfo
    from utils.camera_utils import cameraList_from_camInfos
    from utils.loss_utils import ssim
    args=SimpleNamespace(resolution=1,data_device='cpu',train_test_exp=False)
    info=readColmapSceneInfo(a.dataset,a.images,True)
    cameras=cameraList_from_camInfos(sorted(info.test_cameras,key=lambda c:c.image_name),1,args)
    if not cameras:raise ValueError('Empty test cameras')
    out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
    model=SharedMesh(decode(a.asset))
    result=Evaluator(ssim,4)(model,cameras,png_dir=out/'png')
    save(out/'metrics.json',result)
    print({k:result[k] for k in ('psnr','ssim','lpips','views')})
