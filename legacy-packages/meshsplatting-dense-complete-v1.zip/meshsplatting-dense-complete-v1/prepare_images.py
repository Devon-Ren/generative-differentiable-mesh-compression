"""Raw photographs -> COLMAP cameras, sparse points and undistorted images."""
import argparse,shutil,struct,subprocess
from pathlib import Path
from common import run,save

def prepare(images,output,colmap='colmap'):
    images=Path(images).resolve();output=Path(output).resolve()
    if not images.is_dir():raise ValueError('Missing input photo directory')
    if not shutil.which(colmap):raise RuntimeError('Install COLMAP CLI (see README) or provide a prepared --dataset')
    output.mkdir(parents=True,exist_ok=False)
    db=output/'database.db';maps=output/'models';maps.mkdir()
    log=output/'logs'
    run([colmap,'feature_extractor','--database_path',db,'--image_path',images],log/'features.log')
    run([colmap,'exhaustive_matcher','--database_path',db],log/'matching.log')
    run([colmap,'mapper','--database_path',db,'--image_path',images,'--output_path',maps],log/'mapping.log')
    models=list(maps.glob('*/images.bin'))
    if not models:raise RuntimeError('COLMAP registered no model; inspect mapping.log')
    def count(p):
        with p.open('rb') as f:return struct.unpack('<Q',f.read(8))[0]
    chosen=max(models,key=count);dataset=output/'dataset'
    run([colmap,'image_undistorter','--image_path',images,'--input_path',chosen.parent,
         '--output_path',dataset,'--output_type','COLMAP'],log/'undistort.log')
    sparse=dataset/'sparse'
    if (sparse/'cameras.bin').exists():
        (sparse/'0').mkdir()
        for name in ('cameras.bin','images.bin','points3D.bin'):shutil.move(str(sparse/name),str(sparse/'0'/name))
    if not (sparse/'0/cameras.bin').is_file():raise RuntimeError('Unexpected COLMAP output layout')
    save(output/'sfm-report.json',dict(input=str(images),dataset=str(dataset),selected_model=str(chosen.parent),
         registered_images=count(chosen),models=len(models),note='Largest registered component; unregistered photos are not reconstructed'))
    return dataset
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--photos',required=True);p.add_argument('--output',required=True);p.add_argument('--colmap',default='colmap')
    a=p.parse_args();print(prepare(a.photos,a.output,a.colmap))
