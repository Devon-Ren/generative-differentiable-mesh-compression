#!/usr/bin/env bash
# Source this file after extracting the package. No conda activation hooks.
PKG_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
ENV_PATH=${STAGE2_ENV:-${CONDA_PREFIX:-/scratch/zr2245/conda-envs/pmsh-cu126}}
export CUDA_HOME="$ENV_PATH"
export PATH="$ENV_PATH/bin:$PATH"
export LIBRARY_PATH="$ENV_PATH/targets/x86_64-linux/lib:$ENV_PATH/lib:$ENV_PATH/lib64:${LIBRARY_PATH:-}"
export LD_LIBRARY_PATH="$ENV_PATH/targets/x86_64-linux/lib:$ENV_PATH/lib:$ENV_PATH/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$PKG_ROOT/upstream/submodules/effrdel/src:$PKG_ROOT/stage2/renderer:$PKG_ROOT/stage2:$PKG_ROOT/stage2/codec:${PYTHONPATH:-}"
export MAX_JOBS=${MAX_JOBS:-4} OMP_NUM_THREADS=${OMP_NUM_THREADS:-8}
unset NVCC_PREPEND_FLAGS NVCC_APPEND_FLAGS
if [[ -x "$ENV_PATH/bin/x86_64-conda-linux-gnu-c++" ]]; then
    export CC="$ENV_PATH/bin/x86_64-conda-linux-gnu-cc" CXX="$ENV_PATH/bin/x86_64-conda-linux-gnu-c++"
else export CC=/usr/bin/gcc CXX=/usr/bin/g++; fi
export CUDAHOSTCXX="$CXX"
