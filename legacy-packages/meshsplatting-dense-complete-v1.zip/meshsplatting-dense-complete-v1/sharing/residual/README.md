# Directional sharing v1: controlled single-mesh experiment

Uses the completed original MeshSplatting checkpoint. No Stage 1, no hierarchy,
no decimation, no coordinate/DC/weight training. This is an appearance-module
ablation before reintegrating into the progressive framework.

## Methods

- Independent source: unchanged reference, newly evaluated through the same path.
- Old patch: spatial cells (1% bbox diagonal), DC bins .25, connectivity, cap64,
  coefficient RMS >.03, at most10% sparse exception vertices. Same single-mesh
  initialization as the old implementation, NOT the old multi-level training run.
- Strict codebook: one learned 15x3 direction function per code, one label/vertex.
- Gain codebook: unit-norm function per RGB channel plus three learned FP32 gains
  per vertex. Gains may be signed. No per-vertex full SH residual in dictionary modes.

Initialization minimizes uniform-sphere directional-function L2 (equivalent to
coefficient L2 for orthonormal SH). It does NOT implement visibility-weighted
clustering. Sampled Lloyd fitting is followed by blocked full-vertex assignment;
gain mode solves per-channel least squares. No N x N or full N x K array.
Empty codes remain available in training; unused codes are removed on delivery.

Image fitting: 0.8 L1 +0.2(1-SSIM) + .01 sampled coefficient-anchor MSE. Fixed geometry,
DC, weights, original supersampling4. Bank LR5e-5, gain LR1e-3. Old sparse corrections
use bank LR. Every500 steps, dictionary modes reassign against a 50/50 blend of their
current function and source function, resetting Adam state; no reassignment for old
patch mode. These defaults are initial experimental choices, not tuned guarantees.
Validation every250 steps, selecting minimum mean image distortion including step0.
If fitting fails to improve validation, step0 is delivered and explicitly reported.
Splits: every8th sorted source training view is adaptation validation; test set is
untouched for fitting/selection. Source reconstruction did see adaptation validation.
All methods use the same training camera sequence and frozen DC, including old patch.

## Run

Reuse the existing original-lossless-v1 .venv and official compiled renderer. No
new CUDA compilation is needed. Requires torch/numpy/scipy/Pillow/lpips/zstandard/
meshoptimizer from that environment. CPU tests: python -m unittest test_sharing -v.
Run `python run_experiment.py --help` for paths and options. Default sweep is old
patch, strict K256/K1024, gain K256/K1024;1000 fitting steps per trial. Runtime on a
full scene is unmeasured. Test/render performance is not the optimization target.

Rendering uses Python SH + the official rasterizer's precomputed-color path;
one adaptation-validation view is compared to untouched CUDA-SH forward with a
1e-4 maximum-error gate. Missing/zero/nonfinite appearance gradients stop the run.
This is not a substitute for HPC execution; local tests are CPU only.

## Delivery and accounting

Each `asset.mslb` is a complete standalone packet: all original saved state except
dense directional SH, plus dictionary/index/gain/exception arrays, block metadata
and checksums. It uses the same byte-shuffle+Zstd9 CPU codec as the original control.
Auxiliary original fields are retained for a matched whole-asset comparison.
FP32 values are not quantized. Wire parameter bits and decoded materialization are
checked, then all test views are rendered from decoded parameters with PNGs and
float-image PSNR/SSIM/LPIPS. Float metrics differ in protocol from upstream metrics.py
which reads PNGs; use the independent reference generated in this experiment.
Lossless refers to the NEW trained representation, not original independent SH.

CPU decode: `python decode_asset.py TRIAL/asset.mslb NEW_PATH/point_cloud_state_dict.pt`.
No original checkpoint or dictionary lookup external to the packet is required.
Rendering the recovered PT still requires camera/config settings and the original
renderer. This prototype records those settings in experiment.json/splits.json.

Reports: results.csv, summary.json, per-trial complete.json, codec-report.json,
training.jsonl, best.pt, and test/{renders,gt}. Best.pt is a training artifact and
NOT counted in delivery size. Only asset.mslb is counted as the scene payload.

Resume only skips completed trials with identical configuration/source/code hash.
Partially trained trials are intentionally not silently overwritten or restarted;
run remaining modes in a new output if interrupted. Summary is updated per trial.
Do not infer compression success from lower K alone; compare matched test quality
AND full packet bytes. No tenfold ratio or nondecreasing quality is promised.
