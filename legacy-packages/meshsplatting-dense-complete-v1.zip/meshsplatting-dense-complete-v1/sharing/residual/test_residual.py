import unittest
import tempfile
from pathlib import Path
import numpy as np
import torch
from appearance import Directional, initialize_residual, expand_wire
from codec_benchmark import pack, unpack, equal

class ResidualTests(unittest.TestCase):
    def make(self,device='cpu'):
        torch.manual_seed(7)
        source=torch.randn(80,15,3,device=device)
        base=Directional(source[:4],torch.arange(80,device=device)%4)
        return source,initialize_residual(source,base,4,.25,20,2,7)

    def test_gradients_codec_and_frozen_base(self):
        x,m=self.make();initial=m.bank.detach().clone()
        before=m.correction.detach().clone();opt=torch.optim.Adam([m.correction],lr=.01)
        loss=(m.materialize()-x).square().mean();loss.backward()
        self.assertIsNone(m.bank.grad)
        self.assertTrue(torch.isfinite(m.correction.grad).all())
        self.assertGreater(float(m.correction.grad.abs().sum()),0)
        opt.step();self.assertTrue(torch.equal(m.bank,initial));self.assertFalse(torch.equal(before,m.correction))
        ids=torch.tensor([79,0,20,20,3])
        self.assertTrue(torch.equal(m.materialize(ids),m.materialize()[ids]))
        wire=m.wire()
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'asset.mslb';pack(wire,path,'shuffle-zstd');decoded=unpack(path);equal(wire,decoded)
            np.testing.assert_array_equal(expand_wire(decoded),m.materialize().detach().numpy())
        m.reassign(x,.5);self.assertTrue(torch.equal(m.bank,initial))

    def test_invalid_rows(self):
        _,m=self.make();w=m.wire();w['app_rows'][1]=w['app_rows'][0]
        with self.assertRaises(ValueError):expand_wire(w)

    def test_zero_residual(self):
        x=torch.zeros(20,15,3);b=Directional(x[:2],torch.zeros(20,dtype=torch.long))
        m=initialize_residual(x,b,2,.5,10,2,7)
        m.materialize().sum().backward()
        self.assertTrue(torch.isfinite(m.correction.grad).all())
        np.testing.assert_array_equal(expand_wire(m.wire()),x.numpy())

    @unittest.skipUnless(torch.cuda.is_available(),'CUDA unavailable')
    def test_cuda_cpu_exact(self):
        x,m=self.make('cuda');(m.materialize()-x).square().mean().backward()
        self.assertTrue(torch.isfinite(m.correction.grad).all())
        np.testing.assert_array_equal(expand_wire(m.wire()),m.materialize().detach().cpu().numpy())

if __name__=='__main__':unittest.main()
