import tempfile
from pathlib import Path
import unittest
import numpy as np
import torch
from appearance import Directional, assign, initialize, unit_bank, expand_wire, old_partition
from codec_benchmark import pack, unpack, equal

class SharingTests(unittest.TestCase):
    def setUp(self):torch.manual_seed(2)
    def test_zero_bank_backward(self):
        m=Directional(torch.zeros(2,15,3),torch.tensor([0,1]),torch.ones(2,3))
        (m.materialize()-1).square().mean().backward()
        self.assertTrue(torch.isfinite(m.bank.grad).all())
        self.assertTrue(torch.isfinite(m.gains.grad).all())
    def test_zero_channel_backward(self):
        bank=torch.randn(3,15,3);bank[:,:,1]=0
        m=Directional(bank,torch.tensor([0,1,2,0]),torch.ones(4,3))
        m.materialize().sum().backward()
        self.assertTrue(torch.isfinite(m.bank.grad).all())
    def test_near_zero_normalization(self):
        bank=torch.full((2,15,3),1e-20,requires_grad=True)
        out=unit_bank(bank);out.sum().backward()
        self.assertTrue(torch.isfinite(out).all());self.assertTrue(torch.isfinite(bank.grad).all())
    def test_blocked_assignment(self):
        x=torch.randn(19,15,3);bank=torch.randn(7,15,3)
        z,_=assign(x,bank,False,4,2)
        expected=(x[:,None]-bank[None]).square().sum((2,3)).argmin(1)
        self.assertTrue(torch.equal(z,expected))
    def test_gain_assignment(self):
        b=unit_bank(torch.randn(5,15,3));truth=torch.tensor([4,1,2,0]);g=torch.randn(4,3)
        x=b[truth]*g[:,None]
        z,a=assign(x,b,True,2,2)
        self.assertTrue(torch.equal(z,truth));torch.testing.assert_close(a,g)
    def test_ties_and_zero(self):
        z,g=assign(torch.zeros(3,15,3),torch.zeros(2,15,3),True,2,1)
        self.assertTrue(torch.equal(z,torch.zeros_like(z)));self.assertTrue(torch.isfinite(g).all())
    def test_sampled_initialization(self):
        source=torch.randn(30,15,3)
        m=initialize(source,4,False,20,2);self.assertEqual(m.materialize().shape,source.shape)
    def test_gain_gradient(self):
        m=Directional(torch.randn(4,15,3),torch.arange(20)%4,torch.ones(20,3))
        target=torch.randn(20,15,3);opt=torch.optim.Adam(m.parameters(),lr=.01)
        before=(m.materialize()-target).square().mean().item()
        for _ in range(20):
            opt.zero_grad();loss=(m.materialize()-target).square().mean();loss.backward();opt.step()
        self.assertLess(loss.item(),before)
        self.assertGreater(m.bank.grad.abs().sum().item(),0);self.assertGreater(m.gains.grad.abs().sum().item(),0)
    def test_reassignment(self):
        m=Directional(torch.randn(4,15,3),torch.arange(20)%4,torch.ones(20,3));m.reassign(torch.randn(20,15,3),.5)
        self.assertTrue(torch.isfinite(m.materialize()).all())
    def test_sparse_indexing(self):
        m=Directional(torch.randn(3,15,3),torch.arange(10)%3,rows=torch.tensor([2,7]),correction=torch.randn(2,15,3))
        ids=torch.tensor([9,2,4,7,0]);torch.testing.assert_close(m.materialize(ids),m.materialize()[ids])
    def test_wire_all_modes(self):
        for mode in ('strict','gain','old'):
            m=Directional(torch.randn(4,15,3),torch.arange(20)%3,
                torch.randn(20,3) if mode=='gain' else None,
                torch.tensor([1,9]) if mode=='old' else None,torch.randn(2,15,3) if mode=='old' else None)
            w=m.wire();np.testing.assert_array_equal(expand_wire(w),m.materialize().detach().numpy())
            with tempfile.TemporaryDirectory() as d:
                path=Path(d)/'asset';pack(w,path,'shuffle-zstd');decoded=unpack(path);equal(w,decoded)
                np.testing.assert_array_equal(expand_wire(decoded),expand_wire(w))
    def test_invalid_wire(self):
        m=Directional(torch.randn(2,15,3),torch.tensor([0,1]));w=m.wire();w['app_mapping'][1]=4
        with self.assertRaises(ValueError):expand_wire(w)
    def test_old_partition(self):
        v=np.array([[0,0,0],[.0001,0,0],[0,.0001,0],[10,0,0]],np.float32)
        f=np.array([[0,1,2]],np.int32);dc=np.zeros((4,1,3),np.float32)
        z=old_partition(v,f,dc);self.assertEqual(z[0],z[1]);self.assertNotEqual(z[0],z[3])

if __name__=='__main__':unittest.main()
