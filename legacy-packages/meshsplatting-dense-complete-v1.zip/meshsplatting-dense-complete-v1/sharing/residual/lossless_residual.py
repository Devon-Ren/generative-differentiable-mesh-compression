"""Trusted assets only. CPU exact SH recovery; no training or quantization."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np
import torch
from appearance import expand_wire
from codec_benchmark import pack, unpack, equal, array_of

def sha_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for data in iter(lambda:f.read(8*1024*1024),b''):h.update(data)
    return np.frombuffer(h.digest(),np.uint8).copy()

def words(a):
    a=np.asarray(a)
    if a.dtype!=np.float32:raise ValueError('Expected float32 SH')
    return np.ascontiguousarray(a).view(np.uint32)

def encode_residual(target,prediction,split=False):
    if target.shape!=prediction.shape:raise ValueError('SH shape mismatch')
    x=words(target)^words(prediction)
    if not split:return dict(xor=x)
    return dict(sign=(x>>31).astype(np.uint8),exponent=((x>>23)&255).astype(np.uint8),
                mantissa_high7=((x>>16)&127).astype(np.uint8),mantissa_low16=(x&65535).astype(np.uint16))

def recover(prediction,payload):
    if 'xor' in payload:x=payload['xor']
    else:x=(payload['sign'].astype(np.uint32)<<31)|(payload['exponent'].astype(np.uint32)<<23)|(payload['mantissa_high7'].astype(np.uint32)<<16)|payload['mantissa_low16'].astype(np.uint32)
    if x.shape!=prediction.shape:raise ValueError('Residual shape mismatch')
    restored=(words(prediction)^x).view(np.float32)
    return restored

def decode(shared_path,patch_path):
    p=unpack(patch_path)
    if p['schema']!=1 or not np.array_equal(p['shared_sha256'],sha_file(shared_path)):raise ValueError('Wrong shared asset')
    state=unpack(shared_path);prediction=expand_wire(state)
    if not np.array_equal(p['prediction_sha256'],np.frombuffer(hashlib.sha256(prediction.tobytes()).digest(),np.uint8)):raise ValueError('Predictor arithmetic mismatch')
    restored=recover(prediction,p)
    if not np.array_equal(p['target_sha256'],np.frombuffer(hashlib.sha256(restored.tobytes()).digest(),np.uint8)):raise ValueError('Recovered SH checksum mismatch')
    state={k:v for k,v in state.items() if not k.startswith('app_')}
    state['features_rest']=torch.from_numpy(restored)
    return state

def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True)
    b=sub.add_parser('benchmark');b.add_argument('--source',required=True);b.add_argument('--shared',required=True);b.add_argument('--output',required=True);b.add_argument('--baseline-report',required=True)
    d=sub.add_parser('decode');d.add_argument('--shared',required=True);d.add_argument('--patch',required=True);d.add_argument('--output',required=True)
    a=p.parse_args();out=Path(a.output)
    if out.exists():raise FileExistsError(out)
    if a.command=='decode':
        state=decode(a.shared,a.patch);out.parent.mkdir(parents=True,exist_ok=True);torch.save(state,out);print('Decoded:',out);return
    source=torch.load(a.source,map_location='cpu',weights_only=False)
    shared=unpack(a.shared)
    other={k:v for k,v in shared.items() if not k.startswith('app_')}
    equal({k:v for k,v in source.items() if k!='features_rest'},other)
    target=array_of(source['features_rest'])[0];prediction=expand_wire(shared)
    baseline=json.loads(Path(a.baseline_report).read_text())
    # Ensure the comparison packet really represents this source, not another run.
    base_method=min(baseline['methods'],key=lambda r:r['file_bytes'])
    base_path=Path(a.baseline_report).parent/(base_method['method']+'.mslb')
    reference=unpack(base_path);equal(source,reference);del reference
    out.mkdir(parents=True)
    meta=dict(schema=1,shared_sha256=sha_file(a.shared),
        prediction_sha256=np.frombuffer(hashlib.sha256(prediction.tobytes()).digest(),np.uint8).copy(),
        target_sha256=np.frombuffer(hashlib.sha256(target.tobytes()).digest(),np.uint8).copy())
    report=dict(source=str(a.source),shared=str(a.shared),shared_bytes=Path(a.shared).stat().st_size,
        baseline_bytes=base_path.stat().st_size,baseline_method=base_method['method'],
        vertices=len(target),directional_scalars=target.size,experiments=[],
        scope='Shared asset plus exact SH recovery patch; all saved source fields recovered. No render executed.')
    for name,split,method in [('xor-zstd',False,'zstd'),('xor-shuffle-zstd',False,'shuffle-zstd'),('xor-fields-zstd',True,'shuffle-zstd')]:
        payload=encode_residual(target,prediction,split);payload.update(meta)
        path=out/(name+'.mslb');info=pack(payload,path,method);del payload
        start=time.perf_counter();restored=decode(a.shared,path)
        equal(source,{k:restored[k] for k in source});elapsed=time.perf_counter()-start;del restored
        total=report['shared_bytes']+path.stat().st_size
        row=dict(name=name,patch_bytes=path.stat().st_size,total_bytes=total,
            residual_bits_per_scalar=path.stat().st_size*8/target.size,
            ratio_vs_baseline=report['baseline_bytes']/total,bit_exact_all_source_fields=True,
            decode_seconds=elapsed,encode_seconds=info['encode_seconds'],
            payload_bytes_by_field={f['name']:f.get('payload_bytes',0) for f in info['fields']})
        report['experiments'].append(row)
        (out/'lossless-summary.json').write_text(json.dumps(report,indent=2))
        print(name,'patch MB',row['patch_bytes']/1e6,'TOTAL MB',total/1e6,'bits/scalar',row['residual_bits_per_scalar'],'EXACT PASS',flush=True)
    print('Saved:',out/'lossless-summary.json')

if __name__=='__main__':main()
