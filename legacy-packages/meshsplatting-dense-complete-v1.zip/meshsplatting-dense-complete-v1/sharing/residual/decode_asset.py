"""CPU decoding into the original model's state dictionary; source PT not required."""
import argparse
from pathlib import Path
import torch
from appearance import expand_wire
from codec_benchmark import unpack
p=argparse.ArgumentParser();p.add_argument('packet');p.add_argument('output_pt');a=p.parse_args()
target=Path(a.output_pt)
if target.exists():raise FileExistsError(target)
state=unpack(a.packet)
if 'app_schema' in state:
    rest=torch.from_numpy(expand_wire(state));state={k:v for k,v in state.items() if not k.startswith('app_')};state['features_rest']=rest
target.parent.mkdir(parents=True,exist_ok=True);torch.save(state,target);print('Decoded:',target)
