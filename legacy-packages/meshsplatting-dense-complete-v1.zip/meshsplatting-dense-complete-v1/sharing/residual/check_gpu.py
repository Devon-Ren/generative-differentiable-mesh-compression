"""Small actual-rasterizer smoke: SH forward agreement and appearance parameter updates."""
import argparse
from pathlib import Path
import sys
from types import SimpleNamespace
import numpy as np
import torch
from appearance import Directional

p=argparse.ArgumentParser();p.add_argument('--lab',required=True);a=p.parse_args()
root=Path(a.lab).resolve()/'upstream'
sys.path.insert(0,str(root/'submodules/effrdel/src'));sys.path.insert(0,str(root))
from scene.triangle_model import TriangleModel
from scene.cameras import Camera
from triangle_renderer import render
from utils.sh_utils import eval_sh
import diff_triangle_rasterization._C as ext
assert torch.cuda.is_available()
assert not hasattr(ext,'growth_backward_revision')
torch.manual_seed(7)
mesh=TriangleModel(3);mesh.scaling=1;mesh.active_sh_degree=3;mesh.max_sh_degree=3
mesh.vertices=torch.tensor([[-.6,-.6,3.],[.6,-.6,3.],[0.,.6,3.]],device='cuda')
mesh._triangle_indices=torch.tensor([[0,1,2]],dtype=torch.int32,device='cuda')
mesh.vertex_weight=torch.full((3,1),3.,device='cuda');mesh._sigma=0.
mesh._features_dc=torch.full((3,1,3),.1,device='cuda')
mesh._features_rest=torch.randn(3,15,3,device='cuda')*.01
camera=Camera(0,np.eye(3),np.zeros(3),1.,1.,None,torch.zeros(3,64,64),None,None,'smoke',0)
pipe=SimpleNamespace(debug=False,convert_SHs_python=False,depth_ratio=1.)
background=torch.zeros(3,device='cuda')
def draw(rest):
    d=mesh.vertices-camera.camera_center[None];d=d/d.norm(dim=1,keepdim=True)
    c=(eval_sh(3,torch.cat((mesh._features_dc,rest),1).transpose(1,2),d)+.5).clamp_min(0)
    return render(camera,mesh,pipe,background,override_color=c.contiguous())['render']
with torch.no_grad():
    error=float((draw(mesh._features_rest)-render(camera,mesh,pipe,background)['render']).abs().max())
assert error<1e-4,error
for gain in (False,True):
    m=Directional(torch.randn(1,15,3,device='cuda')*.01,torch.zeros(3,dtype=torch.long,device='cuda'),
                  torch.full((3,3),.05,device='cuda') if gain else None)
    with torch.no_grad():target=draw(torch.ones(3,15,3,device='cuda')*.02)
    opt=torch.optim.Adam(m.parameters(),lr=1e-3)
    initial={k:v.detach().clone() for k,v in m.named_parameters()}
    with torch.no_grad():before=float((draw(m.materialize())-target).square().mean())
    for _ in range(30):
        opt.zero_grad();loss=(draw(m.materialize())-target).square().mean();loss.backward()
        assert m.bank.grad is not None and torch.isfinite(m.bank.grad).all() and m.bank.grad.abs().max()>0
        opt.step()
    with torch.no_grad():after=float((draw(m.materialize())-target).square().mean())
    assert after<before,(gain,before,after)
    assert not torch.equal(initial['bank'],m.bank)
    if gain:assert not torch.equal(initial['gains'],m.gains)
    print('PASS actual rasterizer', 'gain' if gain else 'strict','loss',before,'->',after)
print('GPU SMOKE PASS; renderer',ext.__file__,'forward error',error)
