"""Frozen-mesh directional sharing experiment. Run only on your own checkpoints."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import random
import sys
import time
from types import SimpleNamespace
import numpy as np
import torch
from appearance import initialize, initialize_old, expand_wire, Directional, initialize_residual
from codec_benchmark import pack, unpack, equal

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while b:=f.read(8*1024**2):h.update(b)
    return h.hexdigest()

def atomic_json(path,obj):
    path=Path(path);temp=path.with_suffix('.tmp');temp.write_text(json.dumps(obj,indent=2,allow_nan=False));temp.replace(path)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--lab',required=True,help='Existing original-lossless-v1 directory with official upstream/')
    p.add_argument('--model',required=True,help='Existing original model directory, not PT filename')
    p.add_argument('--dataset',required=True);p.add_argument('--output',required=True)
    p.add_argument('--images',default='images_4');p.add_argument('--resolution',type=int,default=1)
    p.add_argument('--iteration',type=int,default=30000);p.add_argument('--white-background',action='store_true')
    p.add_argument('--ks',default='256,1024');p.add_argument('--modes',default='old,strict,gain')
    p.add_argument('--steps',type=int,default=1000);p.add_argument('--interval',type=int,default=250)
    p.add_argument('--reassign-every',type=int,default=500)
    p.add_argument('--bank-lr',type=float,default=5e-5);p.add_argument('--gain-lr',type=float,default=1e-3)
    p.add_argument('--anchor-weight',type=float,default=.01);p.add_argument('--reassign-anchor',type=float,default=.5)
    p.add_argument('--samples',type=int,default=65536);p.add_argument('--cluster-rounds',type=int,default=8)
    p.add_argument('--seed',type=int,default=7);p.add_argument('--resume',action='store_true')
    p.add_argument('--base-checkpoint',required=True,help='Trusted strict best.pt from the same source asset')
    p.add_argument('--residual-k',type=int,default=256)
    p.add_argument('--residual-fraction',type=float,default=.25)
    a=p.parse_args()
    if not torch.cuda.is_available():p.error('CUDA required for this experiment; CPU codec tests are separate')
    if a.steps<0 or min(a.interval,a.samples,a.cluster_rounds)<=0 or a.reassign_every<0:p.error('Invalid schedule')
    if min(a.bank_lr,a.gain_lr)<=0 or a.anchor_weight<0 or not 0<=a.reassign_anchor<=1:p.error('Invalid learning parameters')
    modes=a.modes.split(',');ks=list(map(int,a.ks.split(',')))
    if modes!=['strict'] or len(ks)!=1:p.error('Residual experiment requires --modes strict and one --ks value')
    if not 0<a.residual_fraction<=1 or a.residual_k<1:p.error('Invalid residual settings')
    if not set(modes)<= {'old','strict','gain'} or len(modes)!=len(set(modes)) or len(ks)!=len(set(ks)) or min(ks)<1:p.error('Invalid modes or K')
    upstream=Path(a.lab).resolve()/'upstream'
    sys.path.insert(0,str(upstream/'submodules/effrdel/src'));sys.path.insert(0,str(upstream))
    from scene import Scene
    from scene.triangle_model import TriangleModel
    from triangle_renderer import render
    from utils.sh_utils import eval_sh
    from utils.loss_utils import ssim
    import lpips
    from PIL import Image
    import diff_triangle_rasterization._C as extension
    if hasattr(extension,'growth_backward_revision'):p.error('Use the isolated official renderer, not growth-modified extension')
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.manual_seed(a.seed);np.random.seed(a.seed);random.seed(a.seed)
    source_path=Path(a.model).resolve()/'point_cloud'/f'iteration_{a.iteration}'/'point_cloud_state_dict.pt'
    source=torch.load(source_path,map_location='cpu',weights_only=False)
    base_path=Path(a.base_checkpoint).resolve()
    base_meta=json.loads((base_path.parent.parent/'experiment.json').read_text())
    if base_meta['source_sha256']!=digest(source_path):p.error('Base checkpoint belongs to a different source')
    if source['features_rest'].shape[1:]!=(15,3) or int(source['active_sh_degree'])!=3:p.error('This prototype requires active degree-3 SH')
    out=Path(a.output).resolve()
    if out==Path(a.model).resolve() or out in source_path.parents:p.error('Output must not overwrite source')
    config={k:v for k,v in vars(a).items() if k!='resume'}
    fingerprint=dict(config=config,base_sha256=digest(base_path),source_sha256=digest(source_path),code_sha256=digest(Path(__file__)),appearance_sha256=digest(Path(__file__).with_name('appearance.py')),codec_sha256=digest(Path(__file__).with_name('codec_benchmark.py')))
    if out.exists():
        if not a.resume or not (out/'experiment.json').exists() or json.loads((out/'experiment.json').read_text())!=fingerprint:p.error('Use new output, or --resume with identical configuration')
    else:out.mkdir(parents=True);atomic_json(out/'experiment.json',fingerprint)
    # Scene loads an existing model; this path does not write source camera files.
    data=SimpleNamespace(source_path=str(Path(a.dataset).resolve()),model_path=str(Path(a.model).resolve()),images=a.images,resolution=a.resolution,
        eval=True,white_background=a.white_background,data_device='cpu',sh_degree=3)
    mesh=TriangleModel(3);mesh.scaling=4
    scene=Scene(data,mesh,None,None,load_iteration=a.iteration,shuffle=False)
    for value in vars(mesh).values():
        if isinstance(value,torch.Tensor):value.requires_grad_(False)
    train_all=sorted(scene.getTrainCameras(),key=lambda c:(c.image_name,c.uid))
    validation=train_all[::8];train=[c for i,c in enumerate(train_all) if i%8]
    test=sorted(scene.getTestCameras(),key=lambda c:(c.image_name,c.uid))
    if not train or not validation or not test:p.error('Empty split')
    atomic_json(out/'splits.json',dict(train=[c.image_name for c in train],validation=[c.image_name for c in validation],test=[c.image_name for c in test],
        caveat='Validation held out from appearance adaptation only; source reconstruction saw these training views. No test-based model selection.'))
    original=mesh._features_rest.detach().clone();dc=mesh._features_dc.detach()
    atomic_json(out/'runtime.json',dict(torch=torch.__version__,cuda=torch.version.cuda,
        gpu=torch.cuda.get_device_name(),vertices=len(mesh.vertices),faces=len(mesh._triangle_indices),
        supersampling=mesh.scaling,renderer=extension.__file__,python=sys.executable,
        frozen=['positions','connectivity','DC','weights'],training='directional appearance only'))
    bg=torch.tensor([1.,1.,1.] if a.white_background else [0.,0.,0.],device='cuda')
    pipe=SimpleNamespace(debug=False,convert_SHs_python=False,depth_ratio=1.)
    perceptual=lpips.LPIPS(net='vgg').cuda().eval()
    for param in perceptual.parameters():param.requires_grad_(False)
    def draw(camera,rest):
        # Python SH avoids modifying the official CUDA SH backward implementation.
        # Directions follow the official CUDA world-frame convention.
        direction=mesh.vertices-camera.camera_center[None]
        direction=direction/direction.norm(dim=1,keepdim=True).clamp_min(1e-12)
        features=torch.cat((dc,rest),1).transpose(1,2)
        colors=(eval_sh(3,features,direction)+.5).clamp_min(0).contiguous()
        return render(camera,mesh,pipe,bg,override_color=colors)['render'].clamp(0,1)
    def objective(image,gt):return .8*(image-gt).abs().mean()+.2*(1-ssim(image,gt))
    @torch.no_grad()
    def evaluate(rest,cameras,folder=None,reference=None):
        rows=[]
        if folder:
            (folder/'renders').mkdir(parents=True,exist_ok=True);(folder/'gt').mkdir(exist_ok=True)
        for i,camera in enumerate(cameras):
            image=draw(camera,rest);gt=camera.original_image[:3].cuda().clamp(0,1)
            mse=(image-gt).square().mean()
            row=dict(camera=camera.image_name,psnr=float(-10*torch.log10(mse.clamp_min(1e-12))),ssim=float(ssim(image,gt)),distortion=float(objective(image,gt)))
            if folder:
                row['lpips']=float(perceptual(image[None]*2-1,gt[None]*2-1).mean())
                for label,img in [('renders',image),('gt',gt)]:
                    arr=(img.permute(1,2,0).cpu().numpy()*255).round().clip(0,255).astype(np.uint8)
                    Image.fromarray(arr).save(folder/label/f'{i:04d}.png')
            if reference is not None:
                row['render_roundtrip_max_error']=float((image-draw(camera,reference)).abs().max())
            rows.append(row)
        keys=('psnr','ssim','distortion','lpips') if folder else ('psnr','ssim','distortion')
        return {**{k:float(np.mean([r[k] for r in rows])) for k in keys},'views':len(rows),'per_view':rows}
    # Gate the override-color path against the untouched original forward renderer.
    with torch.no_grad():
        c=validation[0];x=draw(c,original);y=render(c,mesh,pipe,bg)['render'].clamp(0,1)
        error=float((x-y).abs().max());mean=float((x-y).abs().mean())
    atomic_json(out/'renderer-check.json',dict(max_error=error,mean_error=mean,extension=extension.__file__,tolerance=1e-4))
    if error>1e-4:raise RuntimeError('Python SH vs official CUDA forward mismatch; stopped before training')
    # Correctness gate on appearance-only backward, not a geometry-gradient study.
    probe=original.clone().requires_grad_(True);image=draw(validation[0],probe)
    loss=objective(image,validation[0].original_image[:3].cuda());loss.backward()
    if probe.grad is None or not torch.isfinite(probe.grad).all() or probe.grad.abs().max()==0:raise RuntimeError('Appearance gradient missing, zero or nonfinite')
    del probe,image,loss
    results=[]
    baseline_path=out/'independent'
    if (baseline_path/'complete.json').exists():results.append(json.loads((baseline_path/'complete.json').read_text()))
    else:
        baseline_path.mkdir(exist_ok=True)
        baseline=evaluate(original,test,baseline_path/'test')
        packet=baseline_path/'asset.mslb'
        if packet.exists():raise RuntimeError('Partial baseline exists; use new output or inspect interrupted export')
        info=pack(source,packet,'shuffle-zstd');decoded=unpack(packet);equal(source,decoded);del decoded
        row=dict(name='independent',**baseline,file_bytes=info['file_bytes'],SH_payload_bytes=sum(f.get('payload_bytes',0) for f in info['fields'] if f['category']=='SH'),bit_exact=True)
        atomic_json(baseline_path/'complete.json',row);results.append(row)
    atomic_json(out/'summary.json',dict(fingerprint=fingerprint,results=results))
    jobs=[('old',0)] if 'old' in modes else []
    jobs += [(m,k) for m in modes if m!='old' for k in ks]
    order_rng=random.Random(a.seed);order=[order_rng.randrange(len(train)) for _ in range(a.steps)]
    for mode,k in jobs:
        name=f'residual_k{k}_r{a.residual_k}_f{a.residual_fraction:g}';folder=out/name
        if (folder/'complete.json').exists():results.append(json.loads((folder/'complete.json').read_text()));continue
        if folder.exists():raise RuntimeError(f'Partial trial exists: {folder}. Do not overwrite; run remaining modes in a new output.')
        folder.mkdir();start=time.perf_counter()
        print('START',name,flush=True)
        saved=torch.load(base_path,map_location='cuda',weights_only=True)
        if set(saved)!={'bank','mapping','rows','correction'} or saved['bank'].shape!=(k,15,3) or saved['mapping'].shape!=(len(original),) or saved['rows'].numel() or saved['correction'].numel():raise ValueError('Expected strict dictionary checkpoint without exceptions')
        if not torch.isfinite(saved['bank']).all() or saved['mapping'].min()<0 or saved['mapping'].max()>=k:raise ValueError('Invalid base dictionary')
        base=Directional(saved['bank'],saved['mapping']);base.load_state_dict(saved)
        # Fixed validation reference: never select capacity using test views.
        atomic_json(folder/'base-validation.json',evaluate(base.materialize(),validation))
        model=initialize_residual(original,base,a.residual_k,a.residual_fraction,a.samples,a.cluster_rounds,a.seed)
        del base,saved
        def optimizer():
            groups=[dict(params=[p for p in model.parameters() if p.requires_grad],lr=a.bank_lr)]
            if model.gains is not None:groups.append(dict(params=[model.gains],lr=a.gain_lr))
            return torch.optim.Adam(groups,eps=1e-8)
        opt=optimizer();best=evaluate(model.materialize(),validation);best_step=0
        torch.save(model.state_dict(),folder/'best.pt')
        atomic_json(folder/'initial-validation.json',best)
        for step in range(1,a.steps+1):
            opt.zero_grad(set_to_none=True)
            camera=train[order[step-1]];rest=model.materialize();image=draw(camera,rest)
            image_loss=objective(image,camera.original_image[:3].cuda())
            generator=torch.Generator(device='cuda').manual_seed(a.seed+step)
            ids=torch.randint(len(original),(min(8192,len(original)),),generator=generator,device='cuda')
            anchor=(model.materialize(ids)-original[ids]).square().mean()
            loss=image_loss+a.anchor_weight*anchor
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite loss')
            loss.backward()
            bad=[]
            for parameter_name,param in model.named_parameters():
                if not param.requires_grad or not param.numel():continue
                if param.grad is None:bad.append(dict(parameter=parameter_name,reason='missing'))
                elif not torch.isfinite(param.grad).all():
                    bad.append(dict(parameter=parameter_name,reason='nonfinite',count=int((~torch.isfinite(param.grad)).sum())))
            if bad:
                atomic_json(folder/'gradient-failure.json',dict(step=step,parameters=bad,
                    bank_zero_channels=int((model.bank.detach().square().sum(1)==0).sum()),
                    bank_small_channels=int((model.bank.detach().square().sum(1)<1e-16).sum())))
                raise FloatingPointError(f'Invalid appearance gradient at step {step}: {bad}; see gradient-failure.json')
            opt.step()
            if any(not torch.isfinite(t).all() for t in model.parameters()):raise FloatingPointError('Nonfinite parameter')
            if step==1 or step%50==0:print(name,'step',step,'image',float(image_loss.detach()),'anchor',float(anchor.detach()),flush=True)
            del rest,image,loss,image_loss,anchor
            if step%a.interval==0 or step==a.steps:
                val=evaluate(model.materialize(),validation)
                with (folder/'training.jsonl').open('a') as f:f.write(json.dumps(dict(step=step,**val))+'\n')
                print(name,'validation',step,val['psnr'],val['ssim'],flush=True)
                if val['distortion']<best['distortion']:
                    best=val;best_step=step;torch.save(model.state_dict(),folder/'best.pt')
            if mode!='old' and a.reassign_every and step%a.reassign_every==0 and step<a.steps:
                model.reassign(original,a.reassign_anchor);opt=optimizer()
        model.load_state_dict(torch.load(folder/'best.pt',map_location='cuda',weights_only=True))
        base_val=json.loads((folder/'base-validation.json').read_text())
        atomic_json(folder/'adaptation-report.json',dict(base_validation=base_val,initial_validation=json.loads((folder/'initial-validation.json').read_text()),best_validation=best,best_step=best_step,improves_base_validation_distortion=best['distortion']<base_val['distortion'],selection='top fraction by source SH coefficient MSE; not visibility-aware',primary_dictionary_frozen=True))
        with torch.no_grad():
            wire=model.wire();trained=model.materialize().detach()
        state={key:value for key,value in source.items() if key!='features_rest'};state.update(wire)
        packet=folder/'asset.mslb';info=pack(state,packet,'shuffle-zstd')
        decoded=unpack(packet);equal(state,decoded)
        expanded=expand_wire(decoded);decoded_rest=torch.from_numpy(expanded).cuda()
        # Decode and materialization are a distinct guarantee from wire parameter identity.
        if not torch.equal(trained,decoded_rest):raise RuntimeError('CPU/GPU appearance materialization differs; inspect before acceptance')
        for key in source:
            if key!='features_rest':equal({key:source[key]},{key:decoded[key]})
        measured=evaluate(decoded_rest,test,folder/'test',reference=trained)
        if any(r['render_roundtrip_max_error']!=0 for r in measured['per_view']):raise RuntimeError('Render roundtrip mismatch')
        counts=np.bincount(wire['app_mapping'].astype(np.int64));used=len(counts)
        row=dict(name=name,**measured,requested_K=k,used_K=used,mean_vertices_per_group=len(original)/used,
            singleton_groups=int((counts==1).sum()),sparse_vertices=0,residual_vertices=len(wire['app_rows']),residual_codes=len(wire['app_residual_bank']),gain_scalars=wire['app_gain'].size,
            group_size_quantiles={str(q):float(np.quantile(counts,q)) for q in (0,.25,.5,.75,.95,1)},
            best_step=best_step,best_validation=best,file_bytes=info['file_bytes'],
            appearance_payload_bytes=sum(f.get('payload_bytes',0) for f in info['fields'] if f['name'].startswith('app_')),
            bit_exact=True,geometry_DC_weights_unchanged=True,seconds=time.perf_counter()-start)
        atomic_json(folder/'codec-report.json',info);atomic_json(folder/'complete.json',row);results.append(row)
        del model,opt,trained,decoded_rest,decoded,expanded,state,wire
        torch.cuda.empty_cache()
        atomic_json(out/'summary.json',dict(fingerprint=fingerprint,results=results))
        with (out/'results.csv').open('w',newline='') as f:
            keys=['name','psnr','ssim','lpips','views','file_bytes','used_K','mean_vertices_per_group','best_step','bit_exact']
            writer=csv.DictWriter(f,keys,extrasaction='ignore');writer.writeheader();writer.writerows(results)
        print('COMPLETE',name,'MB',row['file_bytes']/1e6,'PSNR',row['psnr'],flush=True)
    print('Finished:',out/'summary.json')

if __name__=='__main__':main()
