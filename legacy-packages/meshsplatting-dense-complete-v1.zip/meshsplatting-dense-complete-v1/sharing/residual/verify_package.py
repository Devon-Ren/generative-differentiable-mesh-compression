import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for path,digest in manifest.items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
print(len(manifest),'files verified')
