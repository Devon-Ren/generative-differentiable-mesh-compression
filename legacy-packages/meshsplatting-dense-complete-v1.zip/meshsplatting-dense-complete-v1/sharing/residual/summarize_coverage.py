"""Collect coverage results without using test metrics to select a winner."""
import json
import sys
from pathlib import Path

root=Path(sys.argv[1])
rows=[]
for fraction in ('0.25','0.50','1.0'):
    folder=root/('fraction-'+fraction)
    summary=json.loads((folder/'summary.json').read_text())
    config=summary['fingerprint']['config']
    if config['steps']!=0:raise ValueError('Expected initialization-only experiment')
    row=next(r for r in summary['results'] if r['name'].startswith('residual_'))
    report=json.loads((folder/row['name']/'adaptation-report.json').read_text())
    rows.append(dict(fraction=float(fraction),file_MB=row['file_bytes']/1e6,
        appearance_MB=row['appearance_payload_bytes']/1e6,
        residual_vertices=row['residual_vertices'],residual_codes=row['residual_codes'],
        validation_psnr=report['best_validation']['psnr'],
        validation_ssim=report['best_validation']['ssim'],
        validation_distortion=report['best_validation']['distortion'],
        test_psnr=row['psnr'],test_ssim=row['ssim'],test_lpips=row['lpips'],
        bit_exact=row['bit_exact'],best_step=row['best_step']))
result=dict(experiment='initialization-only coverage sweep; no image fine-tuning',
    note='Separate residual dictionaries fitted per coverage; not nested. Test metrics for reporting only.',results=rows)
target=root/'coverage-summary.json'
target.write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2));print('Saved:',target)
