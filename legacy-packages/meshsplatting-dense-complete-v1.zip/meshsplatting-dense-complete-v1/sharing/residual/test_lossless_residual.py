import unittest
import numpy as np
import tempfile,hashlib
from pathlib import Path
import torch
from appearance import Directional,expand_wire
from codec_benchmark import pack
from lossless_residual import encode_residual,recover,decode,sha_file

class ExactTests(unittest.TestCase):
    def test_packet_decode(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);shared=root/'shared.mslb';patch=root/'patch.mslb'
            model=Directional(torch.zeros(2,15,3),torch.tensor([0,1,0]))
            wire=model.wire();wire['features_dc']=torch.zeros(3,1,3)
            pack(wire,shared,'shuffle-zstd')
            predicted=expand_wire(wire);target=np.random.default_rng(9).normal(size=predicted.shape).astype(np.float32)
            payload=encode_residual(target,predicted,True)
            payload.update(schema=1,shared_sha256=sha_file(shared),
                prediction_sha256=np.frombuffer(hashlib.sha256(predicted.tobytes()).digest(),np.uint8).copy(),
                target_sha256=np.frombuffer(hashlib.sha256(target.tobytes()).digest(),np.uint8).copy())
            pack(payload,patch,'shuffle-zstd')
            restored=decode(shared,patch)
            np.testing.assert_array_equal(restored['features_rest'].numpy().view(np.uint32),target.view(np.uint32))
            self.assertTrue(torch.equal(restored['features_dc'],wire['features_dc']))
    def test_all_bits(self):
        rng=np.random.default_rng(7)
        x=rng.integers(0,2**32,size=(80,15,3),dtype=np.uint32)
        y=rng.integers(0,2**32,size=x.shape,dtype=np.uint32)
        x.ravel()[:5]=[0,0x80000000,0x7f800000,0x7fc01234,1]
        for split in (False,True):
            result=recover(y.view(np.float32),encode_residual(x.view(np.float32),y.view(np.float32),split))
            np.testing.assert_array_equal(result.view(np.uint32),x)

if __name__=='__main__':unittest.main()
