#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
LAB=/scratch/zr2245/meshsplatting-original-lossless-v1
source "$LAB/.venv/bin/activate"
export OMP_NUM_THREADS=8
python verify_package.py
python -m unittest test_residual -v
python -u run_experiment.py \
  --lab "$LAB" \
  --model /scratch/zr2245/treehill-lossless-GlUov7/run/original \
  --dataset /scratch/zr2245/datasets/m360-extra/treehill \
  --base-checkpoint /scratch/zr2245/treehill-strict4096-qjm6UM/run/strict_k4096/best.pt \
  --output "${1:?Provide a NEW output directory}" \
  --ks 4096 --modes strict --residual-k 256 --residual-fraction 0.25 \
  --steps 1000 --interval 250 --reassign-every 500
