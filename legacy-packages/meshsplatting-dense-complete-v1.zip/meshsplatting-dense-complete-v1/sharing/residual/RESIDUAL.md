# Selective shared residual experiment

Coverage update: run_coverage.sh runs 25%, 50%, 100% coverage with --steps 0.
Each fits a separate residual dictionary with K=256; these are not nested codes.
No image fine-tuning; clustering still runs. best_step must be zero. Existing
independent evaluation/packing and CPU/GPU codec/render roundtrip checks remain.
summarize_coverage.py collects validation and test metrics and actual packet bytes.
The sweep costs three full evaluations/exports and repeats independent controls.

Use run_residual.sh, NOT the inherited run_treehill.sh. Requires the existing
original-lossless lab, official renderer, source trained mesh and strict K4096
best.pt with its parent experiment.json. No Stage 1 retraining.

A_i = B[z_i] + R[u_i] for selected vertices; otherwise B[z_i]. B, main mapping,
DC, positions, topology and weights stay frozen. Select top 25% source coefficient
MSE vertices with stable ties, cluster residuals into 256 shared codes, train only
these codes with the existing image objective. Reassign residual IDs at step 500.
No gains or independent exceptions. This is NOT visibility-aware allocation.

Validation selects minimum image distortion including initialization. Base,
initialized residual and best validation are saved in adaptation-report.json.
A failed improvement is still exported as an experiment, NOT certified as better.
Test views do not select the model. Independent is also evaluated, not retrained.

Schema 2 stores main bank/mapping, selected vertex IDs and residual bank/mapping.
Existing shuffle-Zstd compresses all arrays, including selection/index overhead.
decode_asset.py decodes on CPU without original checkpoint. Export checks exact
wire parameters, CPU/GPU expanded SH equality, unchanged geometry/DC/weights,
and zero test render roundtrip error. Exactness refers to the NEW representation.
No quantization. Local CPU tests do not establish GPU integration or quality.
