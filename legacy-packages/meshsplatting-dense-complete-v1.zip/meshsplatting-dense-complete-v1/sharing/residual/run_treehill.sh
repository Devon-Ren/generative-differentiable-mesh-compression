#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
LAB=/scratch/zr2245/meshsplatting-original-lossless-v1
source "$LAB/.venv/bin/activate"
export PYTHONPATH="$LAB/upstream/submodules/effrdel/src${PYTHONPATH:+:$PYTHONPATH}"
export OMP_NUM_THREADS=8
python verify_package.py
python -m unittest test_sharing -v
python check_gpu.py --lab "$LAB"
python -u run_experiment.py \
  --lab "$LAB" \
  --model /scratch/zr2245/treehill-lossless-GlUov7/run/original \
  --dataset /scratch/zr2245/datasets/m360-extra/treehill \
  --output "${1:?Provide a new output directory}" \
  --ks 256,1024 --modes old,strict,gain --steps 1000 --interval 250
