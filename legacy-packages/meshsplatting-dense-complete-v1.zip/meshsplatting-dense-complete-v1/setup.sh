#!/usr/bin/env bash
set -eo pipefail
source "$(dirname -- "$0")/env.sh"
cd "$PKG_ROOT"
BASE_PYTHON=${BASE_PYTHON:-$ENV_PATH/bin/python}
"$BASE_PYTHON" -c 'import torch; assert torch.cuda.is_available(), "Run setup in a CUDA GPU allocation"; print(torch.__version__,torch.version.cuda)'
if [[ ! -x .venv/bin/python ]]; then "$BASE_PYTHON" -m venv --system-site-packages .venv; fi
PY="$PKG_ROOT/.venv/bin/python"
"$PY" -m pip install -r requirements-runtime.txt
export TORCH_CUDA_ARCH_LIST
TORCH_CUDA_ARCH_LIST=$("$PY" -c 'import torch; a,b=torch.cuda.get_device_capability(); print(f"{a}.{b}")')
"$PY" verify.py
for ext in diff-triangle-mesh-rasterization simple-knn effrdel; do
    "$PY" -m pip install --no-build-isolation --no-deps --force-reinstall "./upstream/submodules/$ext"
done
(cd stage2/renderer && "$PY" setup.py build_ext --inplace)
(cd stage2 && "$PY" build_cpu.py && "$PY" build_legacy.py)
"$PY" - <<'PY'
import torch,rdel,tetutils,intersect
import diff_triangle_rasterization._C as original
import stage2_triangle_rasterization._C as adapted
assert not hasattr(original,'growth_backward_revision')
assert adapted.shared_stage2_backward_revision()==2
print('Renderers isolated; CUDA and RDel imports PASS')
PY
"$PY" -m pytest -q tests stage2/test_cpu.py stage2/test_coarse_once.py
"$PY" stage2/check_gradients.py --output "$PKG_ROOT/gpu-startup-check.json"
"$PY" -m pip freeze > environment-installed.txt
echo 'Setup complete. Run bash run.sh or sbatch submit.sh.'
