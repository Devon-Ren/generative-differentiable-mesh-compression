"""Complete photos/prepared-COLMAP -> original reconstruction -> compressed asset."""
import argparse,json,sys,shutil,hashlib,csv
from pathlib import Path
from common import ROOT,run,save

def main():
    p=argparse.ArgumentParser(description=__doc__)
    source=p.add_mutually_exclusive_group(required=True)
    source.add_argument('--photos',help='Raw photographs; runs COLMAP first')
    source.add_argument('--dataset',help='Prepared COLMAP scene with sparse/0')
    p.add_argument('--images',default='images');p.add_argument('--output',required=True)
    p.add_argument('--resume',action='store_true');p.add_argument('--coarse-error',type=float,choices=[1,2,4],default=2)
    p.add_argument('--independent-steps',type=int,default=800);p.add_argument('--shared-steps',type=int,default=400)
    a=p.parse_args();flavor=json.loads((ROOT/'package.json').read_text())['route'];out=Path(a.output).resolve()
    config=dict(route=flavor,code_manifest_sha256=hashlib.sha256((ROOT/'SOURCE_MANIFEST.json').read_bytes()).hexdigest(),
        **{k:v for k,v in vars(a).items() if k!='resume'})
    if a.independent_steps<0 or a.shared_steps<0:p.error('Optimization steps must be nonnegative')
    if out.exists():
        if not a.resume or not (out/'pipeline.json').exists() or json.loads((out/'pipeline.json').read_text())!=config:
            raise ValueError('New output required, or --resume with identical arguments')
    else:out.mkdir(parents=True);save(out/'pipeline.json',config)
    def stage(name,cmd,cwd=None):
        done=out/'completed'/f'{name}.json'
        if done.exists():print('SKIP completed',name,flush=True);return
        try:run(cmd,out/'logs'/f'{name}.log',cwd)
        except Exception as e:
            save(out/'status.json',dict(stage=name,status='failed',error=str(e)));raise
        save(done,dict(stage=name,status='complete'));save(out/'status.json',dict(stage=name,status='complete'))
    py=sys.executable
    if a.photos:
        stage('sfm',[py,ROOT/'prepare_images.py','--photos',Path(a.photos).resolve(),'--output',out/'sfm'])
        dataset=out/'sfm/dataset';images='images'
    else:dataset=Path(a.dataset).resolve();images=a.images
    if not (dataset/'sparse/0').is_dir() or not (dataset/images).is_dir():raise ValueError('Missing prepared images or sparse/0')
    model=out/'original'
    stage('reconstruction',[py,ROOT/'upstream/train.py','-s',dataset,'-i',images,'-r','1','--eval','--data_device','cpu','-m',model,'--iterations','30000'],ROOT/'upstream')
    source=model/'point_cloud/iteration_30000/point_cloud_state_dict.pt'
    base=[ '--lab',ROOT,'--model',model,'--dataset',dataset,'--images',images,'--resolution','1','--ks','4096','--modes','strict','--seed','7']
    stage('strict_dictionary',[py,ROOT/'sharing/strict/run_experiment.py',*base,'--output',out/'strict','--steps','1000','--interval','250','--reassign-every','500','--resume'])
    stage('residual_dictionary',[py,ROOT/'sharing/residual/run_experiment.py',*base,'--output',out/'shared',
        '--base-checkpoint',out/'strict/strict_k4096/best.pt','--residual-k','1024','--residual-fraction','1',
        '--steps','0','--interval','250','--reassign-every','0','--resume'])
    shared=out/'shared/residual_k4096_r1024_f1/asset.mslb'
    if flavor=='dense':
        stage('encode',[py,ROOT/'encode.py','--shared',shared,'--output',out/'delivery'])
        asset=out/'delivery/asset.mslb'
    else:
        stage('coarse',[py,ROOT/'stage2/coarse_once.py','--lab',ROOT,'--source',source,'--seed-asset',shared,
            '--dataset',dataset,'--images',images,'--output',out/'coarse','--coarse-error',str(a.coarse_error),
            '--independent-steps',str(a.independent_steps),'--shared-steps',str(a.shared_steps)])
        asset=out/'coarse/delivery/asset.mslb'
    stage('standalone_decode',[py,ROOT/'decode.py','--asset',asset,'--output',out/'decoded.pt'])
    stage('decoded_render',[py,ROOT/'render_asset.py','--asset',asset,'--dataset',dataset,'--images',images,'--output',out/'decoded-render'])
    metrics=json.loads((out/'decoded-render/metrics.json').read_text())
    baseline=next(r for r in json.loads((out/'shared/summary.json').read_text())['results'] if r['name']=='independent')
    counts=json.loads((out/'decoded.json').read_text())
    runtime=json.loads((out/'shared/runtime.json').read_text())
    save(out/'result.json',dict(route=flavor,asset=str(asset),file_bytes=asset.stat().st_size,original_pt_bytes=source.stat().st_size,
        ratio_vs_original=source.stat().st_size/asset.stat().st_size,metrics=metrics,
        original_metrics={k:baseline[k] for k in ('psnr','ssim','lpips')},
        vertices=counts['vertices'],faces=counts['faces'],original_vertices=runtime['vertices'],original_faces=runtime['faces'],
        scope='Measured current run; historical 41.399/26.884 MB results are reference points, not guarantees'))
    with (out/'results.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['stage','vertices','faces','file_MB','ratio_vs_original','psnr','ssim','lpips']);writer.writeheader()
        for name,v,n,size,m in [('original',runtime['vertices'],runtime['faces'],source.stat().st_size,baseline),
                ('decoded_delivery',counts['vertices'],counts['faces'],asset.stat().st_size,metrics)]:
            writer.writerow(dict(stage=name,vertices=v,faces=n,file_MB=size/1e6,ratio_vs_original=source.stat().st_size/size,
                **{k:m[k] for k in ('psnr','ssim','lpips')}))
    print('COMPLETE',out/'result.json',flush=True)
if __name__=='__main__':main()
