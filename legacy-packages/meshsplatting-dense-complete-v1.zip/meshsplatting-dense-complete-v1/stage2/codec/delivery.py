"""Inference-only delivery format. No vertex reordering, pruning or SH changes."""
import argparse
from pathlib import Path
import numpy as np
import torch
from codec_benchmark import unpack, array_of
from appearance import expand_wire

AUX={'importance_score','image_size','pixel_count'}
XYZ_MODES=('f32','q20','q18','q16','q14')
DC_MODES=('f32','f16','q12','q10','q8')

def quantize(a,mode):
    a=np.asarray(a,dtype=np.float32)
    if not np.isfinite(a).all():raise ValueError('Nonfinite input')
    if mode=='f16':
        with np.errstate(over='ignore'):q=a.astype(np.float16)
        if not np.isfinite(q).all():raise ValueError('FP16 overflow')
        return q,dict(bits=16,kind=1)
    bits=int(mode[1:])
    if not 1<=bits<=24:raise ValueError('Invalid bits')
    flat=a.reshape(-1,3).astype(np.float64)
    low=flat.min(0);span=flat.max(0)-low
    scale=span/((1<<bits)-1);safe=np.where(scale>0,scale,1.)
    q=np.rint((flat-low)/safe).clip(0,(1<<bits)-1)
    q=q.astype(np.uint16 if bits<=16 else np.uint32).reshape(a.shape)
    return q,dict(bits=bits,kind=2,low=low,scale=scale)

def dequantize(q,meta):
    if meta['kind']==1:
        if q.dtype!=np.float16:raise ValueError('Invalid FP16 payload')
        return q.astype(np.float32)
    bits=meta['bits']
    if meta['kind']!=2 or not 1<=bits<=24 or q.dtype.kind!='u' or np.any(q>(1<<bits)-1):raise ValueError('Invalid integer quantization')
    low=np.asarray(meta['low']);scale=np.asarray(meta['scale'])
    if low.shape!=(3,) or scale.shape!=(3,) or not np.isfinite(low).all() or not np.isfinite(scale).all() or np.any(scale<0):raise ValueError('Invalid quantization range')
    return (q.astype(np.float64).reshape(-1,3)*scale+low).astype(np.float32).reshape(q.shape)

def prepare(state,xyz='f32',dc='f32',strip=True):
    if xyz not in XYZ_MODES or dc not in DC_MODES:raise ValueError('Unknown mode')
    result={k:v for k,v in state.items() if not strip or k not in AUX}
    result['delivery_schema']=1
    for key,mode in [('triangles_points',xyz),('features_dc',dc)]:
        if mode=='f32':continue
        a,kind=array_of(result[key])
        if kind!='torch' or a.dtype!=np.float32:raise ValueError('Expected source float32 tensor')
        q,meta=quantize(a,mode);result[key]=q
        for k,v in meta.items():result['quant_'+key+'_'+k]=v
    return result

def restore(state):
    if state.get('delivery_schema')!=1:raise ValueError('Unknown delivery schema')
    result={k:v for k,v in state.items() if not k.startswith('quant_') and k!='delivery_schema'}
    for key in ('triangles_points','features_dc'):
        prefix='quant_'+key+'_'
        meta={k[len(prefix):]:v for k,v in state.items() if k.startswith(prefix)}
        if meta:result[key]=torch.from_numpy(dequantize(np.asarray(state[key]),meta))
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('asset');p.add_argument('output_pt');a=p.parse_args()
    out=Path(a.output_pt)
    if out.exists():raise FileExistsError(out)
    state=restore(unpack(a.asset));rest=torch.from_numpy(expand_wire(state))
    state={k:v for k,v in state.items() if not k.startswith('app_')};state['features_rest']=rest
    # Compatibility only: these zero arrays are not original training statistics.
    f=len(state['_triangle_indices'])
    state.setdefault('importance_score',torch.zeros(f))
    state.setdefault('image_size',torch.zeros(f))
    state.setdefault('pixel_count',torch.zeros(f,dtype=torch.int32))
    out.parent.mkdir(parents=True,exist_ok=True);torch.save(state,out)
    print('Inference checkpoint (not a training resume checkpoint):',out)

if __name__=='__main__':main()
