"""CPU-only standalone decoder: needs only asset.mslb, never the source model."""
import argparse,tempfile
from pathlib import Path
from common import setup_paths,save
setup_paths()
import torch
import topology
from delivery import restore
from appearance import expand_wire

def decode(asset):
    with tempfile.TemporaryDirectory(prefix='mesh-decode-') as temp:
        temp=Path(temp);return restore(topology.read_asset(asset,temp/'native',temp))

def checkpoint(state):
    rest=torch.from_numpy(expand_wire(state))
    result={k:v for k,v in state.items() if not k.startswith('app_')}
    result['features_rest']=rest
    f=len(result['_triangle_indices'])
    for k in ('importance_score','image_size'):result[k]=torch.zeros(f)
    result['pixel_count']=torch.zeros(f,dtype=torch.int32)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--asset',required=True);p.add_argument('--output',required=True)
    p.add_argument('--expand-sh',action='store_true',help='Expand dictionaries to per-vertex SH for interoperability')
    a=p.parse_args();output=Path(a.output)
    if output.exists():p.error('Output exists')
    output.parent.mkdir(parents=True,exist_ok=True)
    state=decode(a.asset)
    torch.save(checkpoint(state) if a.expand_sh else state,output)
    save(output.with_suffix('.json'),dict(vertices=len(state['triangles_points']),faces=len(state['_triangle_indices']),
        expanded_sh=a.expand_sh,scope='Decoded inference asset; not an optimizer-resume checkpoint'))
    print('Decoded:',output)
