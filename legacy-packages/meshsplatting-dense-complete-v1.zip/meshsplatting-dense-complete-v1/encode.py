"""Fixed final codec: q18 XYZ, q8 DC, strip-fetch, causal XYZ and edge arithmetic."""
import argparse
from pathlib import Path
from common import setup_paths,save
setup_paths()
from codec_benchmark import unpack
from runtime import export_asset
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--shared',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    state=unpack(a.shared);state.setdefault('opacity_floor',.999)
    decoded,report=export_asset(state,Path(a.output))
    save(Path(a.output)/'encode-summary.json',report)
    print('Encoded bytes:',report['file_bytes'])
