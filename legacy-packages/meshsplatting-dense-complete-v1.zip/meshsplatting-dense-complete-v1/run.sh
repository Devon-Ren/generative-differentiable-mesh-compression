#!/usr/bin/env bash
set -eo pipefail
source "$(dirname -- "$0")/env.sh"
cd "$PKG_ROOT"
[[ -x .venv/bin/python ]] || { echo 'First run bash setup.sh in a GPU allocation'; exit 2; }
.venv/bin/python verify.py
exec .venv/bin/python -u pipeline.py "$@"
