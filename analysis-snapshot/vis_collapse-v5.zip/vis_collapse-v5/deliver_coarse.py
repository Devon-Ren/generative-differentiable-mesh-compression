"""Take a fine-tuned coarse mesh (best.pt from coarse_finetune.py) through Wenhao's Stage-2 delivery:
shared SH conversion (sharing_after.convert) -> shared appearance fit -> export_asset (q18 XYZ / q8 DC,
strip-fetch reorder, edge-arithmetic codec) -> decoded validation/test metrics.  Exactly the tail of
coarse_once.py, with the coarse mesh supplied from outside instead of built by the hierarchy.

Only IMPORTS the stage2 package (shared-collapse-stage2-v1); nothing there is modified.  Defaults for seed
asset / source / dataset / lab / learning rates are read from the historical run's config.json
(--historical-config), so the delivery is comparable with room-shared-collapse-QGQgyr.

Run through deliver_coarse.sh (it sets the same PYTHONPATH / CUDA env as run_room.sh).  Outputs in --output:
progress.json, shared-final.pt, delivery/asset.mslb + codec-report.json, summary.json, results.csv, png-delivery/.
"""
import argparse, csv, gc, json, sys, time
from pathlib import Path
import numpy as np
import torch

PACKAGE_VERSION = (Path(__file__).resolve().parent / 'VERSION').read_text().split()[0] if (Path(__file__).resolve().parent / 'VERSION').exists() else 'unknown'


def log(*a): print(f'[{time.strftime("%H:%M:%S")}]', *a, flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--coarse', required=True, help='best.pt from coarse_finetune.py (independent SH)')
    p.add_argument('--output', required=True)
    p.add_argument('--stage2', default='/scratch/zr2245/shared-collapse-stage2-v1')
    p.add_argument('--historical-config', default='/scratch/zr2245/room-shared-collapse-QGQgyr/run/config.json')
    for k in ('source', 'seed-asset', 'dataset', 'lab'): p.add_argument('--' + k, help='override the historical config')
    p.add_argument('--images'); p.add_argument('--shared-steps', type=int, help='default: historical (400)')
    p.add_argument('--dictionary-rounds', type=int); p.add_argument('--png', action='store_true', help='save decoded test renders')
    a = p.parse_args()
    hist = json.loads(Path(a.historical_config).read_text()) if Path(a.historical_config).exists() else {}
    if not hist: log('WARNING historical config not found; all paths must be given explicitly')
    cfg = dict(hist)
    for k in ('source', 'seed_asset', 'dataset', 'lab', 'images', 'shared_steps', 'dictionary_rounds'):
        v = getattr(a, k)
        if v is not None: cfg[k] = v
    defaults = dict(images='images_2', shared_steps=400, dictionary_rounds=2, geo_lr=.005, dc_lr=.002, bank_lr=.0001, residual_lr=.0003,
                    anchor_weight=.005, seed=17, eval_every=200, min_steps=400, patience=3, local_steps=0, max_flip_fraction=.0001,
                    train_factor=4, eval_factor=4)
    for k, v in defaults.items(): cfg.setdefault(k, v)
    for k in ('source', 'seed_asset', 'dataset', 'lab'):
        if k not in cfg: p.error(f'--{k.replace("_", "-")} required (historical config missing)')
    args = argparse.Namespace(**cfg)
    if not torch.cuda.is_available(): p.error('CUDA required')
    stage2 = Path(a.stage2).resolve()
    for d in (stage2 / 'renderer', stage2, stage2 / 'codec'):
        sys.path.insert(0, str(d))
    try:
        from stage2_triangle_rasterization import _C
    except ImportError as e:
        p.error(f'stage2 renderer extension not importable ({e}); run through deliver_coarse.sh or build it with "cd {stage2}/renderer && python setup.py build_ext --inplace"')
    if _C.shared_stage2_backward_revision() != 2: raise RuntimeError('Renderer revision 2 required')
    from runtime import load_scene, Evaluator, export_asset
    from algorithm import save_json, health
    from train_collapse_first import assess
    from optimize import fit
    from sharing_after import convert
    from codec_benchmark import unpack

    out = Path(a.output); out.mkdir(parents=True, exist_ok=True)
    save_json(out / 'config.json', dict(vars(args), coarse=a.coarse, package_version=PACKAGE_VERSION, stage2=str(stage2)))
    torch.manual_seed(args.seed); np.random.seed(args.seed); torch.backends.cuda.matmul.allow_tf32 = False
    log('vis_collapse package', PACKAGE_VERSION, '| stage2', stage2, '| seed asset', args.seed_asset)
    seed = unpack(args.seed_asset)
    if seed.get('app_schema') != 2 or np.asarray(seed.get('app_gain', [])).size: raise ValueError('Seed must contain residual SH dictionaries without gain')
    train, val, test, ssim = load_scene(args, False); evaluate = Evaluator(ssim, args.eval_factor)
    save_json(out / 'splits.json', dict(train=[c.image_name for c in train], validation=[c.image_name for c in val], test=[c.image_name for c in test]))

    w = torch.load(a.coarse, map_location='cpu', weights_only=False)
    keys = ('triangles_points', 'features_dc', 'features_rest', '_triangle_indices', 'vertex_weight', 'sigma', 'active_sh_degree')
    coarse = {k: (w[k].detach().cpu().clone() if isinstance(w[k], torch.Tensor) else w[k]) for k in keys}
    coarse['_triangle_indices'] = coarse['_triangle_indices'].to(torch.int32).contiguous()
    coarse['opacity_floor'] = float(w.get('opacity_floor', .999)); del w
    rows = []

    def measure(name, wire):
        row = dict(stage=name, vertices=len(wire['triangles_points']), faces=len(wire['_triangle_indices']), validation=assess(wire, evaluate, val))
        rows.append(row); save_json(out / 'progress.json', rows); log('MEASURE', name, row['faces'], round(row['validation']['psnr'], 4)); return row

    measure('coarse_input', coarse)
    input_test = assess(coarse, evaluate, test); log('coarse_input test PSNR', round(input_test['psnr'], 4))
    shared = convert(coarse, seed, args.dictionary_rounds); del seed; gc.collect(); torch.cuda.empty_cache()
    measure('shared_initial', shared)
    if args.shared_steps: shared = fit(shared, None, args.shared_steps, train, val, evaluate, ssim, args, out / 'shared-fit', appearance_only=True)
    torch.save(shared, out / 'shared-final.pt'); measure('shared_fitted', shared)
    delivery = out / 'delivery'
    if delivery.exists():
        import shutil; shutil.rmtree(delivery)
    decoded, codec = export_asset(shared, delivery); measure('decoded_delivery', decoded)
    delivery_test = assess(decoded, evaluate, test, png_dir=out / 'png-delivery' if a.png else None)
    summary = dict(package_version=PACKAGE_VERSION, coarse=a.coarse, stages=rows, codec=codec, input_test=input_test, delivery_test=delivery_test,
                   file_MB=codec['file_bytes'] / 1e6, vertices=len(coarse['triangles_points']), faces=len(coarse['_triangle_indices']),
                   geometry=health(coarse['triangles_points'], shared['triangles_points'], coarse['_triangle_indices']),
                   historical=dict(delivery_MB=26.884, delivery_test_psnr=27.3467, note='room-shared-collapse-QGQgyr, same face count'))
    save_json(out / 'summary.json', summary)
    with (out / 'results.csv').open('w', newline='') as stream:
        wr = csv.DictWriter(stream, fieldnames=['stage', 'split', 'vertices', 'faces', 'psnr', 'ssim', 'lpips', 'file_MB']); wr.writeheader()
        for row in rows:
            wr.writerow(dict(stage=row['stage'], split='validation', vertices=row['vertices'], faces=row['faces'],
                             **{k: row['validation'].get(k, '') for k in ('psnr', 'ssim', 'lpips')}, file_MB=codec['file_bytes'] / 1e6 if row['stage'] == 'decoded_delivery' else ''))
        for name, r in (('coarse_input', input_test), ('decoded_delivery', delivery_test)):
            wr.writerow(dict(stage=name, split='test', vertices=summary['vertices'], faces=summary['faces'], **{k: r[k] for k in ('psnr', 'ssim', 'lpips')},
                             file_MB=codec['file_bytes'] / 1e6 if name == 'decoded_delivery' else ''))
    log(f"DELIVERY {codec['file_bytes'] / 1e6:.3f} MB  test PSNR {delivery_test['psnr']:.4f} SSIM {delivery_test['ssim']:.4f} LPIPS {delivery_test['lpips']:.4f}")
    log('wrote', out / 'summary.json')


if __name__ == '__main__':
    main()
