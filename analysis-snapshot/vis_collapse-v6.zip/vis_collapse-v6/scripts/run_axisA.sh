#!/usr/bin/env bash
# Axis A (appearance redundancy): dictionary-size sweep K x R on ONE mesh through the same stage2 pipeline as axis B
# (k-means dictionaries built on the mesh, 400-step shared fit, q18/q8 export).  Default mesh = the finetuned 100%-vertex
# level of axis B; override with MESH=... .  Restartable; table in $W/axisA.txt.
set -o pipefail
W=/scratch/zr2245/room-vis-collapse
V6=/scratch/zr2245/analysis/vis_collapse-v6
MESH=${MESH:-$W/axisB/v1.0/finetune/best.pt}
KS=${KS:-"1024 4096 16384"}
RS=${RS:-"1 256 1024 4096"}
[ -f $MESH ] || { echo "mesh not found: $MESH (run axis B level 1.0 first, or set MESH=)"; exit 1; }
mkdir -p $W/axisA
for K in $KS; do for R in $RS; do
  name=$W/axisA/k${K}_r${R}; tag=axisA-k${K}-r${R}; echo "=== $tag ==="
  if [ ! -f $name/summary.json ]; then rm -rf $name
    bash $V6/deliver_coarse.sh --coarse $MESH --output $name --k $K --r $R --dictionary-rounds 4 > $name.log 2>&1 || { echo "FAILED $tag"; tail -3 $name.log; continue; }
  fi
  python - <<PY | tee -a $W/axisA.txt
import json; d=json.load(open('$name/summary.json')); t=d['delivery_test']; s={r['stage']:r['validation'] for r in d['stages']}
print('K $K R $R | val shared_initial', round(s['shared_initial']['psnr'],3), 'fitted', round(s['shared_fitted']['psnr'],3), 'decoded', round(s['decoded_delivery']['psnr'],3),
      '| delivered', d['file_MB'], 'MB test', round(t['psnr'],3), round(t['ssim'],4), round(t['lpips'],4),
      '| mapping MB', round((d['codec']['payload_bytes']['app_mapping']+d['codec']['payload_bytes']['app_residual_mapping'])/1e6,3), 'banks MB', round((d['codec']['payload_bytes']['app_bank']+d['codec']['payload_bytes']['app_residual_bank'])/1e6,3))
PY
done; done
echo "===== axisA.txt ====="; cat $W/axisA.txt
