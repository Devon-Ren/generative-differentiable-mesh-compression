#!/usr/bin/env bash
# Draco connectivity reference on (1) the original dense Room mesh and (2) the geo-only coarse mesh.
# Needs DracoPy in the active python (pip install DracoPy; if the GPU node has no network, run that one pip line on the login node once).
set -eo pipefail
W=/scratch/zr2245/room-vis-collapse
C=/scratch/zr2245/room-fixed-sharing-0N4OSU/run/original/point_cloud/iteration_30000/point_cloud_state_dict.pt
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
python -c "import DracoPy" 2>/dev/null || pip install -q DracoPy
mkdir -p $W/draco
# dense mesh: our topology stream is the top_stream of the 41.4 MB asset's codec report (adjust path if the report lives elsewhere)
DENSE_REPORT=$(ls /scratch/zr2245/room-topology-xmawwL/codec/strip-fetch_edge-arithmetic_xyz-ac-yd9hmv0b/*report*.json 2>/dev/null | head -1)
echo "dense codec report: ${DENSE_REPORT:-NOT FOUND (ours row will be missing; pass --top-stream-bytes)}"
python $HERE/topology_reference.py --mesh $C ${DENSE_REPORT:+--codec-report $DENSE_REPORT} --out $W/draco/dense.json 2>&1 | tee $W/draco/dense.log
# geo-only coarse mesh: top_stream comes from the delivery summary
python $HERE/topology_reference.py --mesh $W/finetune-geo-only/best.pt --summary $W/deliver-geo-only/summary.json --out $W/draco/geo-only.json 2>&1 | tee $W/draco/geo-only.log
