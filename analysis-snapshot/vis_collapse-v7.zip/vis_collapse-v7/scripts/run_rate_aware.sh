#!/usr/bin/env bash
# Rate-aware step 1: precision sweep WITHOUT training on the existing geo-only delivery (how many bits does XYZ/DC need?).
# Step 2: QAT deliveries (geometry pre-quantised + STE DC) at the candidate precisions, same mesh, same 400-step fit,
# to be compared with the no-training rows of step 1 and with the q18/q8 baseline (26.695 MB / test 27.624).
set -o pipefail
W=/scratch/zr2245/room-vis-collapse
V7=/scratch/zr2245/analysis/vis_collapse-v7
BASE=${BASE:-$W/deliver-geo-only}                       # has shared-final.pt + config.json
MESH=${MESH:-$W/finetune-geo-only/best.pt}
MODES=${MODES:-"q18/q8,q16/q8,q14/q8,q12/q8,q16/q6,q14/q6,q14/q5,q12/q6"}
QAT=${QAT:-"q14/q6 q12/q6 q14/q5"}
echo "=== step 1: precision sweep (no training) on $BASE ==="
[ -f $BASE/precision/sweep.txt ] || bash $V7/stage2_run.sh precision_sweep.py --deliver-dir $BASE --modes $MODES 2>&1 | tee $W/precision_sweep.log
cat $BASE/precision/sweep.txt
echo "=== step 2: QAT deliveries ==="
for m in $QAT; do xyz=${m%/*}; dc=${m#*/}; name=$W/qat_${xyz}_${dc}; tag=qat-$xyz-$dc; echo "--- $tag ---"
  if [ ! -f $name/summary.json ]; then rm -rf $name
    bash $V7/deliver_coarse.sh --coarse $MESH --output $name --xyz $xyz --dc $dc --qat > $name.log 2>&1 || { echo "FAILED $tag"; tail -3 $name.log; continue; }
  fi
  python - <<PY | tee -a $W/rate_aware.txt
import json; d=json.load(open('$name/summary.json')); t=d['delivery_test']; s={r['stage']:r['validation'] for r in d['stages']}
print('QAT $xyz/$dc | val shared_initial', round(s['shared_initial']['psnr'],3), 'fitted', round(s['shared_fitted']['psnr'],3), 'decoded', round(s['decoded_delivery']['psnr'],3),
      '| delivered', d['file_MB'], 'MB test', round(t['psnr'],3), round(t['ssim'],4), round(t['lpips'],4), '| flips', d['codec']['quantization_geometry']['flipped_faces'])
PY
done
echo "===== rate_aware.txt ====="; cat $W/rate_aware.txt 2>/dev/null
