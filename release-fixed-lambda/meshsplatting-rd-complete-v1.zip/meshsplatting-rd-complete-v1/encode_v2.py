"""encode_v2.py: ENCODER, stage2-v2 delivery format (constant opacity, neighbour-context SH index coder).

Input : the shared representation (shared-final.pt written by vis_collapse/deliver_coarse.py: mesh + DC + codebook
        SH indices after the shared fit), or any state dict with the same fields.
Output: ONE file <output>/asset.mslb.  The decoder (decode.py) needs nothing else.
        Encoder diagnostics (codec-report.json, encode-summary.json, the compiled native coders) are written to
        <output>/encoder-diagnostics/ and are never read by the decoder.

  python encode_v2.py --shared <deliver>/shared-final.pt --output <dir> [--xyz q14] [--dc q7]
"""
import argparse, shutil
from pathlib import Path
from common import setup_paths, save
setup_paths()
import torch
import delivery
from runtime import export_asset

delivery.XYZ_MODES = tuple(dict.fromkeys(delivery.XYZ_MODES + ('q15', 'q13', 'q12')))   # modes used by the 11-scene precision rule
delivery.DC_MODES = tuple(dict.fromkeys(delivery.DC_MODES + ('q7', 'q6', 'q5', 'q4')))

def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--shared', required=True, help='shared-final.pt (torch state dict with app_* codebook fields)')
    p.add_argument('--output', required=True, help='new directory; receives asset.mslb + encoder-diagnostics/')
    p.add_argument('--xyz', default='q14', help='XYZ grid bits: q13..q18 (xyz_rule_v1.py picks per scene)')
    p.add_argument('--dc', default='q7', help='DC bits: q7 default')
    p.add_argument('--weight', choices=['const', 'keep'], default='const')
    p.add_argument('--index-codec', choices=['ctx', 'zstd'], default='ctx')
    a = p.parse_args(); out = Path(a.output).resolve()
    if a.xyz not in delivery.XYZ_MODES or a.dc not in delivery.DC_MODES: p.error(f'unknown precision {a.xyz}/{a.dc}')
    if out.exists(): p.error(f'output exists: {out}')
    state = torch.load(a.shared, map_location='cpu', weights_only=False)
    state.setdefault('opacity_floor', .999)
    work = out.parent / (out.name + '.encoding'); shutil.rmtree(work, ignore_errors=True)
    decoded, report = export_asset(state, work, a.xyz, a.dc, weight=a.weight, index_codec=a.index_codec)
    out.mkdir(parents=True); diag = out / 'encoder-diagnostics'; diag.mkdir()
    (work / 'asset.mslb').replace(out / 'asset.mslb')
    for item in list(work.iterdir()): item.replace(diag / item.name)      # codec-report.json, native/
    work.rmdir()
    V, F = len(decoded['triangles_points']), len(decoded['_triangle_indices'])
    save(diag / 'encode-summary.json', dict(bitstream=str(out / 'asset.mslb'), file_bytes=report['file_bytes'], sha256=report['sha256'],
         xyz=a.xyz, dc=a.dc, weight=a.weight, index_codec=a.index_codec, vertices=V, faces=F,
         payload_bytes=report['payload_bytes'], semantic_audit=report['semantic_audit'], source=str(Path(a.shared).resolve())))
    print(f"BITSTREAM {out / 'asset.mslb'} | {report['file_bytes']} bytes | sha256 {report['sha256']} | V {V} F {F} | {a.xyz}/{a.dc} {a.weight}/{a.index_codec}")

if __name__ == '__main__': main()
