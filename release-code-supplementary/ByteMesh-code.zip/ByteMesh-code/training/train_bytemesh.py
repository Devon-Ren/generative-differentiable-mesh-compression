import argparse
import math
import json
import os
import shlex
import subprocess
import sys
import time
from random import randint

import torch
import torch.nn.functional as F

_pre = argparse.ArgumentParser(add_help=False)
_pre.add_argument('--lab', required=True)
_lab, _rest = _pre.parse_known_args()
UP = os.path.join(os.path.abspath(_lab.lab), 'upstream')
if not os.path.isdir(UP):
    sys.exit(f'upstream dir not found: {UP}')
sys.path.insert(0, UP)
os.chdir(UP)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import train as up
from arguments import ModelParams, PipelineParams, OptimizationParams, update_indoor
from scene import Scene, TriangleModel
from triangle_renderer import render
from utils.loss_utils import l1_loss, ssim, vertex_depth_loss_hr
from utils.general_utils import safe_state, get_expon_lr_func
from tqdm import tqdm
import lpips
from rd_growth import RDAccumulator, RDLog, rd_select, rd_split
from rd_prune import select_collapses, collapse_edges, edge_table, _face_normals

TOPO_KEYS = ('top_stream', '_triangle_indices', 'local_faces', 'local_rotations')
BANK_KEYS = ('app_bank', 'app_residual_bank')

class SizeModel:
    def __init__(self, rd):
        self.b_v = float(rd['bytes_per_vertex']) - 2.0 * float(rd['bytes_per_face']); self.b_f = float(rd['bytes_per_face'])
        self.overhead = float(rd['overhead_mb']) * 1e6; self.faces_per_vertex = float(rd['faces_per_vertex']); self.source = 'constants'; self.probes = []; self.probes_a = []
        if self.b_v <= 0: raise SystemExit(f"bytes_per_vertex {rd['bytes_per_vertex']} must exceed 2 * bytes_per_face {rd['bytes_per_face']}")
    def mb(self, V, F=None):
        if F is None: F = self.faces_per_vertex * V
        return (self.b_v * V + self.b_f * F + self.overhead) / 1e6
    def bytes_per_split(self): return 3.0 * (self.b_v + self.faces_per_vertex * self.b_f)
    def vertices_for(self, mb): return max(1.0, (mb * 1e6 - self.overhead) / (self.b_v + self.faces_per_vertex * self.b_f))
    def bytes_per_collapse(self, faces_removed=2.0): return self.b_v + faces_removed * self.b_f
    def update(self, probe):
        pb = probe['payload_bytes']; V, F = int(probe['vertices']), int(probe['faces'])
        topo = sum(b for k, b in pb.items() if k in TOPO_KEYS); banks = sum(b for k, b in pb.items() if k in BANK_KEYS)
        header = max(0, int(probe['file_bytes']) - sum(pb.values()))
        self.b_f = topo / max(F, 1); self.overhead = banks + header; self.b_v = (int(probe['file_bytes']) - topo - self.overhead) / max(V, 1)
        self.faces_per_vertex = F / max(V, 1); self.source = f"probe@{probe['iteration']}"; self.probes.append(probe)
        probe.update(b_v=round(self.b_v, 3), b_f=round(self.b_f, 3), overhead_mb=round(self.overhead / 1e6, 4), topo_keys_found=[k for k in pb if k in TOPO_KEYS])
    def update_attributes(self, probe):
        pb = probe['payload_bytes']; V, F = int(probe['vertices']), int(probe['faces'])
        topo = sum(b for k, b in pb.items() if k in TOPO_KEYS); banks = sum(b for k, b in pb.items() if k in BANK_KEYS)
        header = max(0, int(probe['file_bytes']) - sum(pb.values()))
        self.overhead = banks + header; self.b_v = (int(probe['file_bytes']) - topo - self.overhead) / max(V, 1)
        self.source = f"probe_a@{probe['iteration']}"; self.probes_a.append(probe)
        probe.update(b_v=round(self.b_v, 3), overhead_mb=round(self.overhead / 1e6, 4), soup_b_f=round(topo / max(F, 1), 3), soup_faces_per_vertex=round(F / max(V, 1), 4), topo_keys_found=[k for k in pb if k in TOPO_KEYS])
    def state(self): return dict(b_v=round(self.b_v, 3), b_f=round(self.b_f, 3), overhead_mb=round(self.overhead / 1e6, 4), faces_per_vertex=round(self.faces_per_vertex, 3), source=self.source)

def probe_bytes(triangles, scene, pipe, bg, rd, iteration, model_path, check=True, min_vertices=0):
    t1 = time.time()
    floor0 = float(triangles.opacity_floor); scale0 = getattr(triangles, 'scaling', 1)
    def importance(scaling):
        imp = torch.zeros(int(triangles._triangle_indices.shape[0]), dtype=torch.float32, device='cuda')
        try:
            triangles.opacity_floor = float(rd['probe_floor']); triangles.scaling = scaling
            for cam in scene.getTrainCameras():
                pk = render(cam, triangles, pipe, bg)
                imp = torch.maximum(imp, pk['max_blending'].detach().reshape(-1).float())
        finally:
            triangles.opacity_floor = floor0; triangles.scaling = scale0
        return imp
    kept_1x = None
    with torch.no_grad():
        T = int(triangles._triangle_indices.shape[0])
        imp = importance(int(rd['probe_scaling']))
        keep = imp > 0.5
        if check and rd.get('probe_check_scaling'):
            kept_1x = int((importance(1) > 0.5).sum())
            if not int(keep.sum()) > kept_1x:
                raise RuntimeError(f'probe scaling has no effect: kept {int(keep.sum())} faces at {rd["probe_scaling"]}x vs {kept_1x} at 1x (triangles.scaling not read by the renderer?)')
        faces = triangles._triangle_indices[keep].long()
        used = torch.zeros(triangles.vertices.shape[0], dtype=torch.bool, device=faces.device)
        if faces.numel(): used[faces.reshape(-1)] = True
        if min_vertices and int(used.sum()) < int(min_vertices):
            return None, used.cpu(), keep.cpu()
        remap = torch.cumsum(used.long(), 0) - 1
        state = dict(triangles_points=triangles.vertices.detach()[used].cpu().clone(), features_dc=triangles._features_dc.detach()[used].cpu().clone(),
                     features_rest=triangles._features_rest.detach()[used].cpu().clone(), _triangle_indices=remap[faces].to(torch.int32).cpu(),
                     vertex_weight=triangles.vertex_weight.detach()[used].cpu().clone(), sigma=triangles._sigma, active_sh_degree=int(triangles.active_sh_degree),
                     opacity_floor=floor0)
    pdir = os.path.join(model_path, 'probes'); os.makedirs(pdir, exist_ok=True)
    pt = os.path.join(pdir, f'probe-{iteration}.pt'); js = os.path.join(pdir, f'probe-{iteration}.json'); lg = os.path.join(pdir, f'probe-{iteration}.log')
    torch.save(state, pt)
    cmd = shlex.split(rd['probe_cmd']) + ['--coarse', pt, '--out', js, '--k', str(rd['probe_k']), '--r', str(rd['probe_r']), '--xyz', rd['probe_xyz'], '--dc', rd['probe_dc'],
                                          '--dictionary-rounds', str(rd['probe_dictionary_rounds'])]
    t2 = time.time()
    with open(lg, 'w') as f:
        rc = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT).returncode
    if rc != 0 or not os.path.exists(js):
        raise RuntimeError(f'byte probe failed at iteration {iteration} (rc {rc}); see {lg}')
    probe = json.load(open(js))
    probe.update(iteration=iteration, vertices_model=int(triangles.vertices.shape[0]), faces_model=T, faces_kept=int(keep.sum()), kept_frac=round(int(keep.sum()) / max(T, 1), 4), probe_floor=float(rd['probe_floor']), probe_scaling=int(rd['probe_scaling']), faces_kept_1x=kept_1x,
                 seconds_cleaning=round(t2 - t1, 1), seconds_probe=round(time.time() - t2, 1))
    os.remove(pt)
    return probe, used.cpu(), keep.cpu()

def faces_removed_by(faces, pairs, n_vertices):
    dev = faces.device
    f = faces.long()
    if pairs.numel() == 0: return torch.zeros(f.shape[0], dtype=torch.bool, device=dev)
    new_id = torch.arange(n_vertices, device=dev); new_id[pairs[:, 1].to(dev).long()] = pairs[:, 0].to(dev).long()
    f2 = new_id[f]
    degenerate = (f2[:, 0] == f2[:, 1]) | (f2[:, 1] == f2[:, 2]) | (f2[:, 0] == f2[:, 2])
    key, _ = torch.sort(f2, dim=1)
    _, first = torch.unique(key, dim=0, return_inverse=True)
    order = torch.arange(f2.shape[0], device=dev)
    firstpos = torch.full((int(first.max()) + 1,), f2.shape[0], dtype=torch.long, device=dev)
    firstpos.scatter_reduce_(0, first, order, reduce='amin')
    dup = (firstpos[first] != order) & ~degenerate
    return degenerate | dup

def edge_scores(vertices, faces, face_err, b_attr, b_face):
    f = faces.long(); V = vertices.shape[0]
    edges, inv, cnt = edge_table(f); err = face_err.double()
    D_v = torch.zeros(V, dtype=torch.float64, device=vertices.device)
    for k in range(3): D_v.index_add_(0, f[:, k], err)
    D_uv = torch.zeros(edges.shape[0], dtype=torch.float64, device=vertices.device); D_uv.index_add_(0, inv, err.repeat(3))
    dR = float(b_attr) + cnt.double() * float(b_face)
    score = (D_v[edges[:, 0]] + D_v[edges[:, 1]] - D_uv) / dR
    return edges, cnt, score

@torch.no_grad()
def _match_cheapest(e, s, V, passes=24):
    dev = e.device; C = e.shape[0]; picked = torch.zeros(C, dtype=torch.bool, device=dev); avail = torch.ones(V, dtype=torch.bool, device=dev)
    inf = torch.full_like(s, float('inf'))
    for _ in range(passes):
        live = ~picked & avail[e[:, 0]] & avail[e[:, 1]]
        if not bool(live.any()): break
        sl = torch.where(live, s, inf)
        vmin = torch.full((V,), float('inf'), dtype=s.dtype, device=dev)
        vmin.scatter_reduce_(0, e[:, 0], sl, reduce='amin'); vmin.scatter_reduce_(0, e[:, 1], sl, reduce='amin')
        idx = torch.nonzero(live & (sl == vmin[e[:, 0]]) & (sl == vmin[e[:, 1]]), as_tuple=True)[0]
        if idx.numel() == 0: break
        use = torch.zeros(V, dtype=torch.long, device=dev)
        use.index_add_(0, e[idx, 0], torch.ones_like(idx)); use.index_add_(0, e[idx, 1], torch.ones_like(idx))
        idx = idx[(use[e[idx, 0]] == 1) & (use[e[idx, 1]] == 1)]
        if idx.numel() == 0: break
        picked[idx] = True; avail[e[idx].reshape(-1)] = False
    return picked

@torch.no_grad()
def select_feasible(pos, faces, face_err, kept_v, kept_f, b_attr, b_face, want_bytes, max_pairs, max_iters=40):
    dev = pos.device; f = faces.long(); V = pos.shape[0]
    edges, inv, cnt = edge_table(f); E = edges.shape[0]; err = face_err.double().to(dev)
    D_v = torch.zeros(V, dtype=torch.float64, device=dev)
    for k in range(3): D_v.index_add_(0, f[:, k], err)
    D_uv = torch.zeros(E, dtype=torch.float64, device=dev); D_uv.index_add_(0, inv, err.repeat(3))
    kv = kept_v.to(dev).bool(); kf = kept_f.to(dev).bool()
    cnt_k = torch.zeros(E, dtype=torch.float64, device=dev); cnt_k.index_add_(0, inv, kf.double().repeat(3))
    dR = float(b_attr) * (kv[edges[:, 0]] & kv[edges[:, 1]]).double() + float(b_face) * cnt_k
    priced = dR > 0
    score = torch.where(priced, (D_v[edges[:, 0]] + D_v[edges[:, 1]] - D_uv) / torch.where(priced, dR, torch.ones_like(dR)), torch.full_like(dR, float('inf')))
    gen = torch.Generator(device=dev); gen.manual_seed(4321 + E)
    fin = score[priced]; scale = float(fin.mean()) if fin.numel() else 1.0
    s = score + torch.rand(E, dtype=torch.float64, device=dev, generator=gen) * 1e-9 * max(scale, 1e-30)
    order = torch.argsort(s); order = order[priced[order]]
    n0 = _face_normals(pos, f)
    avail = torch.ones(V, dtype=torch.bool, device=dev); banned = torch.zeros(E, dtype=torch.bool, device=dev)
    pos2 = pos.clone(); new_id = torch.arange(V, device=dev)
    acc = []; n_acc = 0; acc_bytes = 0.0; n_banned = 0; it = 0; n_dropped_batches = 0
    while it < max_iters and acc_bytes < want_bytes and n_acc < max_pairs:
        it += 1
        cand = order[~banned[order] & avail[edges[order, 0]] & avail[edges[order, 1]]]
        if cand.numel() == 0: break
        mean_b = (acc_bytes / n_acc) if n_acc else float(dR[cand[:2000]].mean())
        need = max(1, min(max_pairs - n_acc, int(0.7 * (want_bytes - acc_bytes) / max(mean_b, 1e-6)) + 1))
        cand = cand[:4 * need + 256]
        new = cand[_match_cheapest(edges[cand], s[cand], V)][:need]
        converged = False
        for _ in range(10):
            if new.numel() == 0: break
            u, v = edges[new, 0], edges[new, 1]
            p2 = pos2.clone(); mid = 0.5 * (pos[u] + pos[v]); p2[u] = mid; p2[v] = mid
            nid = new_id.clone(); nid[v] = u; f2 = nid[f]
            degenerate = (f2[:, 0] == f2[:, 1]) | (f2[:, 1] == f2[:, 2]) | (f2[:, 0] == f2[:, 2])
            flipped = ((n0 * _face_normals(p2, f)).sum(1) < 0) & ~degenerate
            if not bool(flipped.any()): converged = True; break
            pair_of_v = torch.full((V,), -1, dtype=torch.long, device=dev); kk = torch.arange(new.numel(), device=dev); pair_of_v[u] = kk; pair_of_v[v] = kk
            bad = pair_of_v[f[flipped].reshape(-1)]; bad = torch.unique(bad[bad >= 0])
            if bad.numel() == 0: break
            keep = torch.ones(new.numel(), dtype=torch.bool, device=dev); keep[bad] = False
            banned[new[~keep]] = True; n_banned += int(bad.numel()); new = new[keep]
        if not converged or new.numel() == 0:
            if new.numel(): banned[new] = True; n_dropped_batches += 1
            continue
        u, v = edges[new, 0], edges[new, 1]; mid = 0.5 * (pos[u] + pos[v]); pos2[u] = mid; pos2[v] = mid; new_id[v] = u
        avail[u] = False; avail[v] = False
        acc.append(new); n_acc += int(new.numel()); acc_bytes += float(dR[new].sum())
    sel = torch.cat(acc) if acc else torch.zeros(0, dtype=torch.long, device=dev)
    stats = dict(n_pairs=int(sel.numel()), planned_bytes=acc_bytes, want_bytes=float(want_bytes), n_banned=n_banned, iters=it, n_priced=int(priced.sum()), n_edges=E, dropped_batches=n_dropped_batches,
                 score_max=(float(score[sel].max()) if sel.numel() else None))
    return edges, sel, stats

def rank_threshold(score, n_wanted, margin=4.0):
    fin = score[torch.isfinite(score)]
    k = max(1, min(int(fin.numel()) - 1, int(margin * n_wanted) + 1))
    kth = float(torch.kthvalue(fin, k).values)
    return max(kth * (1.0 + 1e-6), 1e-30), k

def split_ratios(acc, triangles, bytes_per_split, size_probs_zero, size_probs_zero_image_space):
    dD = acc.distortion(); areas = triangles.triangle_areas().squeeze()
    ratio = dD / float(bytes_per_split)
    allowed = (areas >= size_probs_zero) & (triangles.image_size >= size_probs_zero_image_space)
    return torch.where(allowed, ratio, torch.zeros_like(ratio)), int(allowed.sum())

def plan_splits(V, V_star, sigmas, add_pct=None):
    remaining = len(sigmas)
    if remaining < 1 or V_star <= V or V <= 0: return 0.0, False
    def geo(v, r, s): return v * ((V_star / v) ** (1.0 / r) - 1.0) / (3.0 * max(s, 1e-3)) if (r >= 1 and V_star > v) else 0.0
    want = geo(V, remaining, sigmas[0])
    if add_pct is None: return want, False
    v = V
    for j, s in enumerate(sigmas):
        d = min(geo(v, remaining - j, s), max(0.0, add_pct * v - v))
        v += 3.0 * d * s
    if v < 0.995 * V_star: return max(want, max(0.0, add_pct * V - V)), True
    return want, False

def extrapolate_ratio(trend, iteration, r_meas, horizon_iter, window=6):
    if not trend or iteration >= horizon_iter: return r_meas, 0.0, 1.0
    xs, ns, n, prev = [], [], None, None
    for it0, p0, rem0 in trend:
        n = float(p0) if n is None else n * float(p0) / max(prev, 1e-9)
        xs.append(float(it0)); ns.append(n); prev = float(p0) - float(rem0)
    n = n * float(r_meas) / max(prev, 1e-9); xs.append(float(iteration)); ns.append(n)
    xs, ns = xs[-window:], ns[-window:]
    k = len(xs); mx = sum(xs) / k; my = sum(ns) / k
    sxx = sum((x - mx) ** 2 for x in xs)
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ns)) / sxx if sxx > 0 else 0.0
    g = max(0.8, (n + slope * (horizon_iter - iteration)) / max(n, 1e-9))
    return r_meas * g, slope * 1000.0, g

def extrapolate_probe(trend, iteration, r_meas, horizon_iter):
    if not trend or iteration >= horizon_iter: return r_meas, 0.0
    xs, ys, cum = [], [], 0.0
    for it0, p0, rem0 in trend:
        xs.append(float(it0)); ys.append(p0 + cum); cum += rem0
    xs.append(float(iteration)); ys.append(r_meas + cum)
    n = len(xs); mx = sum(xs) / n; my = sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx if sxx > 0 else 0.0
    return r_meas + slope * (horizon_iter - iteration), slope * 1000.0

def rank_lambda(ratio, n_allowed, k, lo, hi):
    if k < 1: return hi
    if k >= n_allowed or n_allowed < 1: return lo
    kth = float(torch.topk(ratio, int(k), largest=True, sorted=True).values[-1])
    return min(hi, max(lo, kth))

class SurvivalMeter:
    def __init__(self, window=3): self.window = window; self.hist = []; self.prev_after = None; self.prev_new = 0
    def observe(self, V_before):
        s = None
        if self.prev_after is not None and self.prev_new > 0 and V_before < self.prev_after:
            pruned = self.prev_after - V_before
            if pruned < self.prev_new:
                s = max(0.2, 1.0 - pruned / self.prev_new); self.hist.append(round(s, 4))
        return s
    def record(self, V_before, V_after): self.prev_after = V_after; self.prev_new = max(0, V_after - V_before)
    @property
    def sigma(self):
        h = self.hist[-self.window:]
        return sum(h) / len(h) if h else 1.0

def shadow_price(edges, score, pairs, mu):
    if pairs.numel() == 0: return None
    V = int(edges.max()) + 1
    key = edges[:, 0] * V + edges[:, 1]; order = torch.argsort(key); skey = key[order]
    u = torch.minimum(pairs[:, 0], pairs[:, 1]).long(); v = torch.maximum(pairs[:, 0], pairs[:, 1]).long(); pk = u * V + v
    pos = torch.searchsorted(skey, pk).clamp_max(skey.numel() - 1); e = order[pos]
    if not bool((skey[pos] == pk).all()): return None
    return float(score[e].max()) / float(mu)

def load_split_schedule(path):
    sched = {}
    with open(path) as f:
        for line in f:
            e = json.loads(line)
            if e.get('event') == 'densify':
                sched[int(e['iteration'])] = int(e['n_split'])
    if not sched:
        raise RuntimeError(f'no densify events in split schedule {path}')
    return sched

def training(dataset, opt, pipe, testing_iterations, checkpoint, debug_from, scene_name, rd):
    tb_writer = up.prepare_output_and_logger(dataset)
    triangles = TriangleModel(dataset.sh_degree)
    scene = Scene(dataset, triangles, opt.set_weight, opt.set_sigma)
    triangles.training_setup(opt, opt.feature_lr, opt.weight_lr, opt.lr_triangles_points_init)
    triangles.add_percentage = opt.add_percentage
    first_iter = 0
    if checkpoint:
        (model_params, first_iter) = torch.load(checkpoint)
        triangles.restore(model_params, opt)

    bg_color = [1, 1, 1] if dataset.white_background else [0, 0, 0]
    background = torch.tensor(bg_color, dtype=torch.float32, device='cuda')
    iter_start = torch.cuda.Event(enable_timing=True)
    iter_end = torch.cuda.Event(enable_timing=True)
    viewpoint_stack = scene.getTrainCameras().copy()
    number_of_training_views = len(viewpoint_stack)
    ema_loss_for_log = 0.0
    progress_bar = tqdm(range(first_iter, opt.iterations), desc='Training progress (RD growth)')
    first_iter += 1

    initial_sigma = opt.set_sigma
    final_sigma = 0.0001
    sigma_start = opt.sigma_start
    total_iters = opt.sigma_until
    init_opacity = 0.1
    final_opacity = .9999
    total_iters_opacity = opt.final_opacity_iter
    prune_triangles = opt.prune_triangles_threshold
    prune_size = opt.prune_size
    start_upsampling = opt.start_upsampling
    splitt_large_triangles = opt.splitt_large_triangles
    triangles.size_probs_zero = opt.size_probs_zero
    triangles.size_probs_zero_image_space = opt.size_probs_zero_image_space
    need_delaunay = False
    run_restricted_delaunay = opt.densify_until_iter + 1000
    depth_l1_weight = get_expon_lr_func(opt.depth_lambda_init, opt.depth_lambda_final, max_steps=opt.iterations)

    acc = RDAccumulator(triangles._triangle_indices.shape[0], mode=rd['dd_mode'], norm=rd['dd_norm'])
    log = RDLog(os.path.join(dataset.model_path, 'rd_log.jsonl'))
    size = SizeModel(rd); bytes_per_split = size.bytes_per_split()
    target_a = rd['target_mb'] * rd['phase_a_overshoot']
    sched = load_split_schedule(rd['split_schedule']) if rd['split_schedule'] else None
    prune_set = sorted(set(int(i) for i in rd['prune_iters']))
    if prune_set:
        if rd['dd_mode'] != 'error':
            raise SystemExit('pruning needs --dd_mode error (residual attribution); got ' + rd['dd_mode'])
        bad = [i for i in prune_set if not (run_restricted_delaunay + 1 < i < start_upsampling)]
        if bad and not rd['allow_any_prune_iter']:
            raise SystemExit(f'prune_iters {bad} must lie after the Delaunay rebuild ({run_restricted_delaunay}) and before supersampling ({start_upsampling}); --allow_any_prune_iter overrides (smoke only)')
    last_prune = max(prune_set) if prune_set else -1
    lam_now = float(rd['lam']); lam_hist = []; phase_b_started = False; last_faces_removed = None; surv = SurvivalMeter()
    last_bytes_per_pair = None; n_densify = 0; n_bound = 0; last_r_est = None
    extra_set = sorted(set(int(i) for i in rd['probe_extra_iters']))
    bad_x = [i for i in extra_set if i in prune_set or i <= last_prune or i >= opt.iterations]
    if bad_x: raise SystemExit(f'probe_extra_iters {bad_x} must lie after the last prune round ({last_prune}) and before the end ({opt.iterations}), and not be prune rounds')
    trend = []; k_asked = None; yield_hist = []
    last_probe_a = None; n_probe_a = 0
    if rd['probe_a_every'] < 0: raise SystemExit(f"--probe_a_every must be >= 0 (0 disables the phase-A probes), got {rd['probe_a_every']}")
    log.write(event='config', version='adapt-v9b', probe_a_every=rd['probe_a_every'], probe_a_smoke=rd['probe_a_smoke'], start_pruning=opt.start_pruning, probe_extra_iters=extra_set, probe_scaling=rd['probe_scaling'], sigma_prior=rd['sigma_prior'], target_mb=rd['target_mb'], target_a_mb=target_a, phase_a_overshoot=rd['phase_a_overshoot'], probe_floor=rd['probe_floor'],
              size_model=size.state(), probe_cmd=rd['probe_cmd'], probe=dict(k=rd['probe_k'], r=rd['probe_r'], xyz=rd['probe_xyz'], dc=rd['probe_dc'], dictionary_rounds=rd['probe_dictionary_rounds']),
              lam_min=rd['lam_min'], lam_max=rd['lam_max'], overhead_mb=rd['overhead_mb'], lam=rd['lam'], dd_mode=rd['dd_mode'], dd_norm=rd['dd_norm'], bytes_per_vertex=rd['bytes_per_vertex'],
              bytes_per_split=bytes_per_split, max_points=opt.max_points, add_percentage=opt.add_percentage,
              densify_from=opt.densify_from_iter, densify_until=opt.densify_until_iter, interval=opt.densification_interval,
              split_schedule=rd['split_schedule'], schedule_total=(sum(sched.values()) if sched else None),
              prune_iters=prune_set, prune_mu=rd['prune_mu'], prune_max_frac=rd['prune_max_frac'], bytes_per_face=rd['bytes_per_face'])
    print(f"[RD adapt] target {rd['target_mb']} MB (phase A aims at {target_a:.2f}) | lam0 {lam_now:.3e} | lambda = rank price of the planned count | phase-A probes every {rd['probe_a_every']} it after start_pruning {opt.start_pruning}{' (smoke: from the first interval)' if rd['probe_a_smoke'] else ''} | probe floor {rd['probe_floor']} | lam in [{rd['lam_min']:.1e}, {rd['lam_max']:.1e}] | size model {size.state()} | probe {rd['probe_k']}x{rd['probe_r']} {rd['probe_xyz']}/{rd['probe_dc']}")
    if prune_set:
        print('[RD] phase-B lambda-prune at', prune_set, '| mu', rd['prune_mu'], 'max_frac/round', rd['prune_max_frac'], 'B/face', rd['bytes_per_face'])
    if sched:
        print('[RD] matched-count control: schedule from', rd['split_schedule'], '|', len(sched), 'intervals, total chosen', sum(sched.values()))
    t0 = time.time()

    for iteration in range(first_iter, opt.iterations + 1):
        if need_delaunay:
            with torch.no_grad():
                triangles.run_restricted_delaunay()
            need_delaunay = False
            log.write(event='delaunay', iteration=iteration, vertices=int(triangles.vertices.shape[0]),
                      triangles=int(triangles._triangle_indices.shape[0]), elapsed_s=round(time.time() - t0))
            acc.reset(triangles._triangle_indices.shape[0])
        if iteration == start_upsampling:
            triangles.scaling = opt.upscaling_factor
        if iteration == start_upsampling + 5000:
            triangles.scaling = 4

        iter_start.record()
        triangles.update_learning_rate(iteration)
        if iteration < sigma_start:
            current_sigma = initial_sigma
        else:
            progress = min((iteration - sigma_start) / (total_iters - sigma_start), 1.0)
            current_sigma = initial_sigma - (initial_sigma - final_sigma) * progress
        triangles.set_sigma(current_sigma)
        if iteration % 1000 == 0:
            triangles.oneupSHdegree()
        if (iteration - 1) == debug_from:
            pipe.debug = True
        bg = torch.rand((3), device='cuda') if opt.random_background else background

        if not viewpoint_stack or len(scene.getTrainCameras()) + iteration == opt.iterations:
            viewpoint_stack = scene.getTrainCameras().copy()
            if len(scene.getTrainCameras()) + iteration == opt.iterations:
                triangles.importance_score = torch.zeros((triangles._triangle_indices.shape[0]), dtype=torch.float, device='cuda')
        viewpoint_cam = viewpoint_stack.pop(randint(0, len(viewpoint_stack) - 1))

        render_pkg = render(viewpoint_cam, triangles, pipe, bg)
        image = render_pkg['render']
        gt_image = viewpoint_cam.original_image.cuda()
        if getattr(viewpoint_cam, 'normal_map', None) is not None:
            gt_normal = viewpoint_cam.normal_map.cuda()
            gt_normal = F.interpolate(gt_normal.unsqueeze(0), size=(gt_image.shape[1], gt_image.shape[2]), mode='area').squeeze(0)
        else:
            gt_normal = None

        pixel_loss = l1_loss(image, gt_image)

        image_size = render_pkg['scaling'].detach()
        mask = image_size > triangles.image_size
        triangles.image_size[mask] = image_size[mask]
        importance_score = render_pkg['max_blending'].detach()
        mask = importance_score > triangles.importance_score
        triangles.importance_score[mask] = importance_score[mask]
        pixel_count = render_pkg['triangle_was_rendered'].detach()
        mask = pixel_count > triangles.pixel_count
        triangles.pixel_count[mask] = pixel_count[mask]

        if up.FUSED_SSIM_AVAILABLE:
            ssim_value = up.fused_ssim(image.unsqueeze(0), gt_image.unsqueeze(0))
        else:
            ssim_value = ssim(image, gt_image)
        loss = (1.0 - opt.lambda_dssim) * pixel_loss + opt.lambda_dssim * (1.0 - ssim_value)

        lambda_weight = opt.lambda_weight if iteration < opt.start_opacity_floor else 0
        if lambda_weight > 0:
            mask_out = triangles.vertices.shape[0]
            vertex_weights = triangles.get_vertex_weight[:mask_out][triangles._triangle_indices]
            loss += lambda_weight * vertex_weights.mean()

        lambda_vertex = opt.lambda_vertex if iteration > opt.start_vertex_opt else 0
        if lambda_vertex > 0:
            loss += lambda_vertex * vertex_depth_loss_hr(render_pkg['vertex_depth_out'], render_pkg['image_2D'], render_pkg['vertex_rendered'],
                                                         render_pkg['surf_depth'], max_diff_threshold=opt.max_diff_threshold)

        if depth_l1_weight(iteration) > 0 and getattr(viewpoint_cam, 'invdepthmap', None) is not None:
            invDepth = 1.0 / (render_pkg['expected_depth'] + 1e-6)
            mono_invdepth = viewpoint_cam.invdepthmap.cuda()
            depth_mask = viewpoint_cam.depth_mask.cuda()
            loss += depth_l1_weight(iteration) * torch.abs((invDepth - mono_invdepth) * depth_mask).mean()

        rend_normal = render_pkg['rend_normal']
        surf_normal = render_pkg['surf_normal']
        lambda_normal = opt.lambda_normals if iteration > opt.iteration_mesh else 0
        if lambda_normal > 0:
            loss += lambda_normal * (1 - (rend_normal * surf_normal).sum(dim=0))[None].mean()
        if gt_normal is not None:
            lambda_normals_super = opt.lambda_normals_super if iteration > opt.iteration_mesh else 0
            loss += lambda_normals_super * (1 - (rend_normal * gt_normal).sum(dim=0))[None].mean()

        loss.backward()
        iter_end.record()

        with torch.no_grad():
            if iteration < run_restricted_delaunay or iteration <= last_prune:
                acc.accumulate(render_pkg, image, gt_image, triangles._triangle_indices,
                               vertex_grad=triangles.vertices.grad if rd['dd_mode'] == 'grad' else None)

            ema_loss_for_log = 0.4 * loss.item() + 0.6 * ema_loss_for_log
            if iteration % 10 == 0:
                progress_bar.set_postfix({'Loss': f'{ema_loss_for_log:.5f}', 'V': int(triangles.vertices.shape[0])})
                progress_bar.update(10)
            if iteration == opt.iterations:
                progress_bar.close()
            up.training_report(tb_writer, scene_name, iteration, pixel_loss, loss, l1_loss, iter_start.elapsed_time(iter_end),
                               testing_iterations, scene, render, (pipe, background))

            if iteration % 500 == 0 and iteration < run_restricted_delaunay:
                triangle_vertex_weights = triangles.opacity_activation(triangles.vertex_weight[triangles._triangle_indices])
                min_weights = triangle_vertex_weights.min(dim=1).values
                mask_opacity = (min_weights <= prune_triangles).squeeze()
                mask_importance = (triangles.importance_score <= prune_triangles).squeeze()
                mask_size = (triangles.image_size > prune_size).squeeze()
                delete_mask = mask_opacity | mask_size
                if number_of_training_views < 500:
                    delete_mask = delete_mask | mask_importance
                keep_mask = ~delete_mask
                if iteration > opt.start_pruning:
                    triangles.prune_triangles(keep_mask)
                    acc.apply_mask(keep_mask)

                device = triangles.vertices.device
                used_vertex_mask = torch.zeros(triangles.vertices.shape[0], dtype=torch.bool, device=device)
                if triangles._triangle_indices.numel() > 0:
                    used_vertex_mask[triangles._triangle_indices.flatten()] = True
                weight_mask = (triangles.get_vertex_weight.squeeze() >= prune_triangles)
                mask_out = triangles.vertices.shape[0]
                vertex_mask = weight_mask[:mask_out] | used_vertex_mask
                valid_tris = vertex_mask[triangles._triangle_indices.long()].all(dim=1) if triangles._triangle_indices.numel() > 0 else None
                triangles._prune_vertices(vertex_mask)
                if valid_tris is not None:
                    acc.apply_mask(valid_tris)

                needs_densification = (iteration < opt.densify_until_iter and iteration % opt.densification_interval == 0
                                       and iteration > opt.densify_from_iter)
                if needs_densification:
                    V = int(triangles.vertices.shape[0])
                    max_split = max(0, min(opt.max_points, int(opt.add_percentage * V)) - V)
                    k_ref = None
                    if sched is not None:
                        k_ref = sched.get(iteration, 0)
                        max_split = min(max_split, k_ref)
                    s_obs = surv.observe(V); sigma = surv.sigma
                    if rd['probe_a_every'] > 0 and (iteration > opt.start_pruning or rd['probe_a_smoke']) and (last_probe_a is None or iteration - last_probe_a >= rd['probe_a_every']):
                        v_star_before = size.vertices_for(target_a); src_before = size.source; min_v = max(int(rd['probe_k']), int(rd['probe_r']))
                        pa, used_a, _ = probe_bytes(triangles, scene, pipe, bg, rd, iteration, dataset.model_path, check=False, min_vertices=min_v)
                        if pa is None:
                            log.write(event='probe_a_skipped', iteration=iteration, elapsed_s=round(time.time() - t0), vertices_model=V, kept_vertices=int(used_a.sum()), min_vertices=min_v, **size.state())
                            print(f"\n[RD probe-a {iteration}] skipped: {int(used_a.sum())} kept vertices of {V} < dictionary size {min_v}; size model stays {size.source}")
                        else:
                            size.update_attributes(pa); last_probe_a = iteration; n_probe_a += 1
                            r_pa = pa['file_bytes'] / 1e6; v_star_after = size.vertices_for(target_a); kappa = pa['vertices'] / max(V, 1)
                            log.write(event='probe_a', iteration=iteration, elapsed_s=round(time.time() - t0), probe_mb=round(r_pa, 4), probe_ratio=round(r_pa / rd['target_mb'], 4), probe_vertices=pa['vertices'], probe_faces=pa['faces'],
                                      vertices_model=V, faces_model=pa['faces_model'], kept_share=round(kappa, 4), probe_kept_frac=pa['kept_frac'], probe_seconds=pa['seconds_probe'], seconds_cleaning=pa['seconds_cleaning'],
                                      soup_b_f=pa['soup_b_f'], soup_faces_per_vertex=pa['soup_faces_per_vertex'], v_star_before=int(v_star_before), v_star_after=int(v_star_after), source_before=src_before, **size.state())
                            print(f"\n[RD probe-a {iteration}] soup {V} V -> cleaned {pa['vertices']} V {pa['faces']} F (kept share {kappa:.3f}) -> {r_pa:.3f} MB in {pa['seconds_cleaning']} + {pa['seconds_probe']} s | b_v {size.b_v:.2f} B (attributes per kept vertex) overhead {size.overhead / 1e6:.3f} MB | topology prior b_f {size.b_f:.2f} x {size.faces_per_vertex:.2f} faces/vertex (soup read {pa['soup_b_f']:.2f} x {pa['soup_faces_per_vertex']:.2f}, not used) | V* {int(v_star_before)} -> {int(v_star_after)} ({src_before} -> {size.source})")
                    rhat = size.mb(V)
                    remaining = max(1, -(-(opt.densify_until_iter - iteration) // opt.densification_interval))
                    V_star = size.vertices_for(target_a)
                    sig_meas = sigma if surv.hist else float(rd['sigma_prior'])
                    sigmas = [(sig_meas if iteration + opt.densification_interval * (j + 1) > opt.start_pruning else 1.0) for j in range(remaining)]
                    desired, front = plan_splits(V, V_star, sigmas, opt.add_percentage); cap = int(math.ceil(desired))
                    max_split_up = max_split; limiter_bound = (False if rd.get('hold_lambda') else bool(front or max_split_up < cap)); max_split = (max_split_up if rd.get('hold_lambda') else min(max_split_up, cap))
                    n_densify += 1; n_bound += int(limiter_bound)
                    lam_used = lam_now; lam_hist.append(lam_now)
                    ratio_pre, n_allowed = split_ratios(acc, triangles, bytes_per_split, triangles.size_probs_zero, triangles.size_probs_zero_image_space)
                    idx, st = rd_select(acc, triangles, lam_now, bytes_per_split, max_split,
                                        triangles.size_probs_zero, triangles.size_probs_zero_image_space)
                    n_split = rd_split(triangles, idx, iteration, splitt_large_triangles)
                    V_after = int(triangles.vertices.shape[0]); surv.record(V, V_after)
                    V_exp = V + sigmas[0] * (V_after - V)
                    desired_next = plan_splits(V_exp, V_star, sigmas[1:], opt.add_percentage)[0] if remaining > 1 else 0.0
                    if k_asked: yield_hist.append(min(5.0, max(0.2, float(st['n_pass']) / max(k_asked, 1))))
                    yl = yield_hist[-3:]; yld = sum(yl) / len(yl) if yl else 1.0
                    k_asked = int(math.ceil(desired_next / yld)) if desired_next > 0 else 0
                    lam_now = lam_used if rd.get('hold_lambda') else (rank_lambda(ratio_pre, n_allowed, k_asked, rd['lam_min'], rd['lam_max']) if k_asked > 0 else lam_used)
                    ratio = float(st['n_pass']) / max(desired, 1.0)
                    st.update(event='densify', hold_lambda=bool(rd.get('hold_lambda')), iteration=iteration, vertices_before=V, vertices_after=V_after,
                              triangles_after=int(triangles._triangle_indices.shape[0]), n_split_total=n_split, k_ref=k_ref, elapsed_s=round(time.time() - t0),
                              lam_used=lam_used, lam_next=lam_now, rhat_mb=round(rhat, 4), desired=round(desired, 1), desired_next=round(desired_next, 1), remaining=remaining, cap=cap,
                              pass_ratio=round(ratio, 4), sigma=round(sigma, 4), sigma_obs=(round(s_obs, 4) if s_obs is not None else None), sigma_plan=round(sigmas[0], 4), n_allowed=n_allowed, v_star=int(V_star), limiter_bound=limiter_bound, limiter_max=int(max_split_up), front_loaded=front, rank_yield=round(yld, 4), k_asked=k_asked, size_source=size.source)
                    log.write(**st)
                    print(f"\n[RD {iteration}] V {V}->{V_after} pass {st['n_pass']}/{st['n_tri']} split {n_split} "
                          f"(cap {cap} limiter {max_split_up}) ratio q50/q90/q99 {st['ratio_q50']:.2e}/{st['ratio_q90']:.2e}/{st['ratio_q99']:.2e} "
                          f"lam {lam_used:.2e} -> {lam_now:.2e} (projected {rhat:.2f} / phase-A aim {target_a:.2f} MB = {V_star} vertices, desired {desired:.0f} -> next {desired_next:.0f}{' LIMITER' if limiter_bound else ''}{' FRONT-LOAD' if front else ''}, pass/desired {ratio:.2f}, yield {yld:.2f} -> k {k_asked}, sigma {sigma:.2f} (obs {s_obs}, plan {sigmas[0]:.2f}), {remaining} intervals left) valid {st['valid_frac']}")
                acc.reset(triangles._triangle_indices.shape[0])

                if iteration > opt.start_opacity_floor:
                    a = min(1.0, max(0.0, (iteration - opt.start_opacity_floor) / max(1, total_iters_opacity - opt.start_opacity_floor)))
                    triangles.update_min_weight(min(init_opacity + (final_opacity - init_opacity) * a, final_opacity))
                    prune_triangles += 0.01
            elif iteration == run_restricted_delaunay:
                need_delaunay = True
            elif iteration % 500 == 0 and iteration > run_restricted_delaunay + 1000:
                if iteration > opt.start_opacity_floor:
                    a = min(1.0, max(0.0, (iteration - opt.start_opacity_floor) / max(1, total_iters_opacity - opt.start_opacity_floor)))
                    triangles.update_min_weight(min(init_opacity + (final_opacity - init_opacity) * a, final_opacity))
                    prune_triangles += 0.01

            if iteration in prune_set:
                V0, T0 = int(triangles.vertices.shape[0]), int(triangles._triangle_indices.shape[0])
                dD = acc.distortion()
                if dD.numel() != T0:
                    raise RuntimeError(f'accumulator/face mismatch at prune {iteration}: {dD.numel()} vs {T0}')
                n_views = acc.views
                probe, kept_v, kept_f = probe_bytes(triangles, scene, pipe, bg, rd, iteration, dataset.model_path)
                size.update(probe); r_meas = probe['file_bytes'] / 1e6
                rounds_left = len([i for i in prune_set if i >= iteration])
                te5 = (not rd.get('hold_lambda')) and int(rd.get('trim_exact') or 0) == 5; g_fac = 1.0
                predictive = iteration < int(total_iters_opacity)
                if te5: rounds_left = len([i for i in prune_set if i >= iteration and ((i < int(total_iters_opacity)) == predictive)])
                if te5: r_est, slope_k, g_fac = extrapolate_ratio(trend, iteration, r_meas, int(total_iters_opacity)); last_r_est = r_est
                else: r_est, slope_k = extrapolate_probe(trend, iteration, r_meas, int(total_iters_opacity)); last_r_est = r_est
                if te5 and rd.get('trim_hold'): r_est, slope_k, g_fac = r_meas, 0.0, 1.0; last_r_est = r_est; rounds_left = 1; predictive = False
                excess = (r_est - rd['target_mb'] * (1.0 + (float(rd.get('trim_margin') or 0.0) if (te5 and predictive) else 0.0))) * 1e6
                if last_bytes_per_pair: b_coll = last_bytes_per_pair
                else: b_coll = size.b_v * (probe['vertices'] / max(probe['vertices_model'], 1)) ** 2 + 2.0 * size.b_f * float(probe['kept_frac'])
                excess_pairs = excess / max(b_coll, 1e-6)
                desired = excess_pairs / rounds_left
                if not phase_b_started:
                    phase_b_started = True
                    if lam_hist:
                        tail = lam_hist[-20:]; lam_a = math.exp(sum(math.log(x) for x in tail) / len(tail))
                        print(f"\n[RD adapt {iteration}] phase A ended at lam {lam_now:.2e} (geo-mean of last {len(tail)} intervals {lam_a:.2e})")
                print(f"\n[RD adapt {iteration}] probe: {probe['vertices']} V {probe['faces']} F after cleaning -> {r_meas:.3f} MB ({r_meas / rd['target_mb']:.3f} x target), extrapolated to {int(total_iters_opacity)}: {r_est:.3f} MB ({r_est / rd['target_mb']:.3f} x, slope {slope_k:+.3f} MB/1k it) in {probe['seconds_probe']} s"
                      f" | b_v {size.b_v:.2f} b_f {size.b_f:.2f} overhead {size.overhead / 1e6:.3f} MB | {b_coll:.1f} B per collapse -> {desired:.0f} collapses wanted ({rounds_left} rounds left)")
                ev = dict(event='prune', iteration=iteration, views=n_views, elapsed_s=round(time.time() - t0), probe_mb=round(r_meas, 4), probe_ratio=round(r_meas / rd['target_mb'], 4),
                          probe_est_mb=round(r_est, 4), probe_est_ratio=round(r_est / rd['target_mb'], 4), probe_slope_mb_per_1k=round(slope_k, 4),
                          probe_vertices=probe['vertices'], probe_faces=probe['faces'], probe_kept_frac=probe['kept_frac'], probe_seconds=probe['seconds_probe'], desired_pairs=round(desired, 1), rounds_left=rounds_left,
                          bytes_per_collapse=round(b_coll, 2), **size.state())
                b_v_full = size.b_v + 2.0 * size.b_f
                edges, cnt, score = edge_scores(triangles.vertices, triangles._triangle_indices, dD, size.b_v, size.b_f)
                thr_lam = float(lam_now) * float(rd['prune_mu']); n_lam = int((score < thr_lam).sum())
                thr_rank, k_rank = (rank_threshold(score, desired) if desired >= 1.0 else (0.0, 0))
                count_driven = thr_rank > thr_lam
                thr = max(thr_rank, thr_lam)
                wanted = min(max(desired, float(n_lam)), excess_pairs) if excess > 0 else 0.0
                cap_bound = bool(excess > 0 and excess_pairs < max(desired, float(n_lam)))
                te = 0 if rd.get('hold_lambda') else int(rd.get('trim_exact') or 0)
                if te >= 3: wanted = (max(1.0, min(desired, excess_pairs)) if excess > 0 else 0.0); cap_bound = False
                if te == 5 and iteration < int(rd.get('trim_start') or 0): wanted = 0.0
                if te == 1: wanted = (min(desired, excess_pairs) if excess > 0 else 0.0); cap_bound = False
                if rd.get('hold_lambda'): wanted = float(n_lam); count_driven = False; cap_bound = False; thr = thr_lam
                removed_mb = 0.0; n_kept_faces_removed = 0
                if wanted < 1.0:
                    acc.reset(T0)
                    ev.update(skipped=True, mode='none', lam_now=lam_now, n_lam=n_lam, excess_pairs=round(excess_pairs, 1), vertices_before=V0, vertices_after=V0, faces_before=T0, faces_after=T0, n_pairs=0, kept_removed=0, kept_faces_removed=0, removed_mb=0.0)
                    log.write(**ev)
                    print(f"[RD prune {iteration}] landing {r_est:.3f} MB {'under' if excess <= 0 else 'at'} target {rd['target_mb']} MB: no collapse this round (lambda-prune held; {n_lam} edges below lam {lam_now:.2e})")
                else:
                    frac = min(rd['prune_max_frac'], wanted / V0)
                    pairs, ps = select_collapses(triangles.vertices, triangles._triangle_indices, dD, thr / rd['prune_mu'], rd['prune_mu'], b_v_full, size.b_f, frac)
                    if te in (1, 2):
                        goal = int(frac * V0); margin = 4.0; frac_eff = frac; tries = 1; first_pairs = int(ps['n_pairs']); n_fin = int(torch.isfinite(score).sum())
                        while ps['n_pairs'] < 0.97 * goal and tries < 14:
                            tries += 1
                            if ps['n_pass_pairs'] < int(frac_eff * V0):
                                margin *= 2.0; thr_m, k_m = rank_threshold(score, wanted, margin=margin)
                                if thr_m <= thr:
                                    if k_m >= n_fin - 1: break
                                    continue
                                thr = thr_m; count_driven = True
                            else:
                                if frac_eff >= 0.45: break
                                frac_eff = min(0.45, frac_eff * max(1.25, goal / max(ps['n_pairs'], 1)))
                            pairs, ps = select_collapses(triangles.vertices, triangles._triangle_indices, dD, thr / rd['prune_mu'], rd['prune_mu'], b_v_full, size.b_f, frac_eff)
                        if int(pairs.shape[0]) > goal:
                            Vn = int(edges.max()) + 1; key = edges[:, 0] * Vn + edges[:, 1]; order_e = torch.argsort(key); skey = key[order_e]
                            pu = torch.minimum(pairs[:, 0], pairs[:, 1]).long(); pv = torch.maximum(pairs[:, 0], pairs[:, 1]).long(); pk = pu * Vn + pv
                            pos = torch.searchsorted(skey, pk).clamp_max(skey.numel() - 1); sc = score[order_e[pos]]
                            pairs = pairs[torch.argsort(sc)[:goal]]; ps['n_pairs'] = int(pairs.shape[0])
                        ev.update(trim_exact=te, trim_goal=goal, trim_margin=margin, trim_frac_eff=round(frac_eff, 4), trim_tries=tries, trim_first_pairs=first_pairs)
                        print(f"[RD prune {iteration}] exact trim (mode {te}): goal {goal} pairs, first pass {first_pairs}, after {tries} tries (margin {margin:g}, pair cap {frac_eff:.3f} V) {ps['n_pairs']} pairs (matching found {ps['n_pass_pairs']}, flip-rejected {ps['n_flip_rejected']})")
                    if te >= 3:
                        first_pairs = int(ps['n_pairs']); want_bytes = (excess / g_fac / rounds_left) if te == 5 else excess / (rounds_left if te == 3 else min(rounds_left, 3)); cap_pairs = int(rd['prune_max_frac'] * V0)
                        edges_f, sel_f, st_f = select_feasible(triangles.vertices.detach(), triangles._triangle_indices, dD, kept_v, kept_f, size.b_v, size.b_f, want_bytes, cap_pairs)
                        if sel_f.numel() > 0:
                            pairs = edges_f[sel_f]; ps['n_pairs'] = int(pairs.shape[0]); ps['n_flip_rejected'] = st_f['n_banned']; ps['max_pairs'] = cap_pairs; count_driven = True
                        ev.update(trim_exact=te, trim_predictive=bool(predictive), trim_rounds_left=rounds_left, trim_growth=round(g_fac, 4), trim_want_mb=round(want_bytes / 1e6, 4), trim_planned_mb=round(st_f['planned_bytes'] / 1e6, 4), trim_batches=st_f['iters'], trim_banned=st_f['n_banned'],
                                  trim_first_pairs=first_pairs, trim_goal=int(st_f['n_pairs']), trim_priced=st_f['n_priced'], trim_dropped_batches=st_f['dropped_batches'])
                        print(f"[RD prune {iteration}] feasible trim (mode {te}): wanted {want_bytes / 1e6:.3f} MB, selected {st_f['n_pairs']} pairs freeing {st_f['planned_bytes'] / 1e6:.3f} MB in {st_f['iters']} batches ({st_f['n_banned']} pairs banned by the fold-over test, {st_f['n_priced']} of {st_f['n_edges']} edges free bytes); the original rule gave {first_pairs} pairs")
                    lam_sp = shadow_price(edges, score, pairs, rd['prune_mu'])
                    if (count_driven or cap_bound) and lam_sp is not None: lam_now = lam_sp
                    rm_f = faces_removed_by(triangles._triangle_indices, pairs, V0).cpu()
                    n_kept_faces_removed = int((rm_f & kept_f).sum())
                    pc = pairs.cpu().long(); n_kept_removed = int((kept_v[pc[:, 0]] & kept_v[pc[:, 1]]).sum()) if pairs.numel() else 0
                    cs = collapse_edges(triangles, pairs)
                    if int(rm_f.sum()) != T0 - cs['faces_after']:
                        raise RuntimeError(f'collapse accounting mismatch at {iteration}: predicted {int(rm_f.sum())} faces removed, collapse_edges removed {T0 - cs["faces_after"]}')
                    if ps['n_pairs'] > 0: last_faces_removed = (T0 - cs['faces_after']) / ps['n_pairs']
                    removed_mb = (n_kept_removed * size.b_v + n_kept_faces_removed * size.b_f) / 1e6
                    if ps['n_pairs'] > 0: last_bytes_per_pair = removed_mb * 1e6 / ps['n_pairs']
                    acc.reset(triangles._triangle_indices.shape[0])
                    mode = 'count' if count_driven else ('capped' if cap_bound else 'lambda')
                    ev.update(skipped=False, mode=mode, lam_now=lam_now, shadow_lam=lam_sp, n_lam=n_lam, excess_pairs=round(excess_pairs, 1), cap_frac=round(frac, 4), rank_k=k_rank, removed_mb=round(removed_mb, 4), kept_removed=n_kept_removed, kept_removed_frac=round(n_kept_removed / max(ps['n_pairs'], 1), 4),
                              kept_faces_removed=n_kept_faces_removed, bytes_per_pair_measured=(round(last_bytes_per_pair, 2) if last_bytes_per_pair is not None else None), faces_removed_per_pair=(round(last_faces_removed, 3) if last_faces_removed else None)); ev.update(ps); ev.update(cs)
                    log.write(**ev)
                    print(f"\n[RD prune {iteration}] V {V0}->{cs['vertices_after']} T {T0}->{cs['faces_after']} | {mode}-driven: wanted {wanted:.0f} pairs (per-round plan {desired:.0f}, whole excess {excess_pairs:.0f}), lam-admitted {n_lam} edges, cap {ps['max_pairs']} -> {ps['n_pairs']} collapsed ({removed_mb:.3f} MB exact: {n_kept_removed} kept vertices + {n_kept_faces_removed} kept faces; {(last_bytes_per_pair if last_bytes_per_pair else float('nan')):.1f} B per pair) "
                          f"(flip-rejected {ps['n_flip_rejected']}, passes {ps['passes']}) | lam {lam_now:.2e} (shadow {lam_sp}) | score q10/q50/q90 {ps['score_q10']:.2e}/{ps['score_q50']:.2e}/{ps['score_q90']:.2e} "
                          f"| faces-removed share sel {ps['faces_removed_share_sel']} all {ps['faces_removed_share_all']} | views {n_views}")
                trend.append((iteration, r_meas, removed_mb))
            elif iteration in extra_set:
                probe, _, _ = probe_bytes(triangles, scene, pipe, bg, rd, iteration, dataset.model_path)
                size.update(probe); r_meas = probe['file_bytes'] / 1e6
                r_est, slope_k = extrapolate_probe(trend, iteration, r_meas, int(total_iters_opacity))
                print(f"\n[RD adapt {iteration}] diagnostic probe: {probe['vertices']} V {probe['faces']} F after cleaning -> {r_meas:.3f} MB ({r_meas / rd['target_mb']:.3f} x target), extrapolated to {int(total_iters_opacity)}: {r_est:.3f} MB ({r_est / rd['target_mb']:.3f} x, slope {slope_k:+.3f} MB/1k it) in {probe['seconds_probe']} s | floor now {float(triangles.opacity_floor):.4f} scaling {getattr(triangles, 'scaling', 1)}")
                log.write(event='probe_extra', iteration=iteration, elapsed_s=round(time.time() - t0), probe_mb=round(r_meas, 4), probe_ratio=round(r_meas / rd['target_mb'], 4), probe_est_mb=round(r_est, 4), probe_slope_mb_per_1k=round(slope_k, 4),
                          probe_vertices=probe['vertices'], probe_faces=probe['faces'], probe_kept_frac=probe['kept_frac'], probe_seconds=probe['seconds_probe'], floor_now=float(triangles.opacity_floor), scaling_now=int(getattr(triangles, 'scaling', 1)), **size.state())
                trend.append((iteration, r_meas, 0.0))
            if iteration < opt.iterations:
                triangles.optimizer.step()
                triangles.optimizer.zero_grad(set_to_none=True)

    viewpoint_stack = scene.getTrainCameras().copy()
    triangles.importance_score = torch.zeros((triangles._triangle_indices.shape[0]), dtype=torch.float, device='cuda')
    while viewpoint_stack:
        viewpoint_cam = viewpoint_stack.pop(0)
        render_pkg = render(viewpoint_cam, triangles, pipe, bg)
        importance_score = render_pkg['max_blending'].detach()
        mask = importance_score > triangles.importance_score
        triangles.importance_score[mask] = importance_score[mask]
    mask_importance = (triangles.importance_score <= 0.5).squeeze()
    triangles.prune_triangles(~mask_importance)
    used_vertex_mask = torch.zeros(triangles.vertices.shape[0], dtype=torch.bool, device=triangles.vertices.device)
    if triangles._triangle_indices.numel() > 0:
        used_vertex_mask[triangles._triangle_indices.flatten()] = True
    triangles._prune_vertices(used_vertex_mask)
    scene.save(iteration)
    rhat_final = size.mb(int(triangles.vertices.shape[0]), int(triangles._triangle_indices.shape[0]))
    final_probe, _, _ = probe_bytes(triangles, scene, pipe, bg, rd, iteration, dataset.model_path, check=False); size.probes.append(final_probe)
    probe_final = final_probe['file_bytes'] / 1e6
    growth_capped = bool(prune_set) and last_r_est is not None and last_r_est < rd['target_mb'] and 2 * n_bound > n_densify
    log.write(event='final', growth_capped=growth_capped, probe_a_count=n_probe_a, limiter_bound_intervals=n_bound, densify_intervals=n_densify, last_probe_est_mb=(round(last_r_est, 4) if last_r_est is not None else None), vertices=int(triangles.vertices.shape[0]), triangles=int(triangles._triangle_indices.shape[0]),
              elapsed_s=round(time.time() - t0), lam_final=lam_now, rhat_mb=round(rhat_final, 4), probe_final_mb=round(probe_final, 4), probe_final_ratio=round(probe_final / rd['target_mb'], 4),
              target_mb=rd['target_mb'], **size.state())
    with open(os.path.join(dataset.model_path, 'rd_summary.json'), 'w') as f:
        json.dump(dict(version='adapt-v9b', growth_capped=growth_capped, probe_a_every=rd['probe_a_every'], probe_a_smoke=rd['probe_a_smoke'], probe_a_count=n_probe_a, probes_a=size.probes_a, start_pruning=opt.start_pruning, limiter_bound_intervals=n_bound, densify_intervals=n_densify, last_probe_est_mb=(round(last_r_est, 4) if last_r_est is not None else None), probe_extra_iters=extra_set, probe_scaling=rd['probe_scaling'], sigma_hist=surv.hist, probe_trend=trend, yield_hist=yield_hist, extrapolate_to=int(total_iters_opacity), probe_floor=rd['probe_floor'], target_mb=rd['target_mb'], lam_final=lam_now, rhat_final_mb=round(rhat_final, 4), probe_final_mb=round(probe_final, 4), probes=size.probes, size_model=size.state(),
                       phase_a_overshoot=rd['phase_a_overshoot'], probe_cmd=rd['probe_cmd'], lam=rd['lam'], dd_mode=rd['dd_mode'], dd_norm=rd['dd_norm'], bytes_per_vertex=rd['bytes_per_vertex'], split_schedule=rd['split_schedule'],
                       prune_iters=prune_set, prune_mu=rd['prune_mu'], prune_max_frac=rd['prune_max_frac'], bytes_per_face=rd['bytes_per_face'],
                       vertices=int(triangles.vertices.shape[0]), triangles=int(triangles._triangle_indices.shape[0])), f, indent=1)
    print(f"Training is done; vertices {int(triangles.vertices.shape[0])} triangles {int(triangles._triangle_indices.shape[0])} | adapt-v9b: target {rd['target_mb']} MB, final probe {probe_final:.3f} MB ({probe_final / rd['target_mb']:.3f} x), model {rhat_final:.2f} MB, lam0 {rd['lam']:.2e} -> lam_final {lam_now:.2e}"
          f" | growth-capped {growth_capped} (limiter bound {n_bound} of {n_densify} intervals, last landing estimate {last_r_est}) | phase-A probes {n_probe_a}"
          f"{(' (last b_v %.2f overhead %.3f MB at %s)' % (size.probes_a[-1]['b_v'], size.probes_a[-1]['overhead_mb'], size.probes_a[-1]['iteration'])) if size.probes_a else ''}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='MeshSplatting training with RD-controlled growth', parents=[_pre])
    lp = ModelParams(parser)
    op = OptimizationParams(parser)
    pp = PipelineParams(parser)
    parser.add_argument('--debug_from', type=int, default=-1)
    parser.add_argument('--detect_anomaly', action='store_true', default=False)
    parser.add_argument('--test_iterations', nargs='+', type=int, default=[7_000, 30_000])
    parser.add_argument('--save_iterations', nargs='+', type=int, default=[7_000, 30_000])
    parser.add_argument('--quiet', action='store_true')
    parser.add_argument('--checkpoint_iterations', nargs='+', type=int, default=[])
    parser.add_argument('--start_checkpoint', type=str, default=None)
    parser.add_argument('--scene_name', default='Garden', type=str)
    parser.add_argument('--indoor', action='store_true', default=False)
    parser.add_argument('--lam', type=float, required=True)
    parser.add_argument('--bytes_per_vertex', type=float, default=10.0)
    parser.add_argument('--dd_mode', choices=['error', 'grad', 'importance'], default='error')
    parser.add_argument('--dd_norm', choices=['mpx', 'none'], default='mpx')
    parser.add_argument('--split_schedule', type=str, default=None)
    parser.add_argument('--prune_iters', nargs='*', type=int, default=[12000, 14000, 16000, 18000])
    parser.add_argument('--prune_mu', type=float, default=1.0)
    parser.add_argument('--prune_max_frac', type=float, default=0.15)
    parser.add_argument('--probe_extra_iters', nargs='*', type=int, default=[])
    parser.add_argument('--probe_a_every', type=int, default=1000)
    parser.add_argument('--probe_a_smoke', action='store_true')
    parser.add_argument('--bytes_per_face', type=float, default=2.0)
    parser.add_argument('--allow_any_prune_iter', action='store_true')
    parser.add_argument('--target_mb', type=float, required=True)
    parser.add_argument('--seed', type=int, default=None)
    parser.add_argument('--trim_hold', action='store_true')
    parser.add_argument('--trim_margin', type=float, default=0.0)
    parser.add_argument('--trim_start', type=int, default=0)
    parser.add_argument('--trim_exact', type=int, default=0, choices=[0, 1, 2, 3, 4, 5])
    parser.add_argument('--hold_lambda', action='store_true')
    parser.add_argument('--probe_scaling', type=int, default=4)
    parser.add_argument('--probe_check_scaling', action='store_true')
    parser.add_argument('--sigma_prior', type=float, default=0.5)
    parser.add_argument('--probe_floor', type=float, default=0.9999)
    parser.add_argument('--lam_min', type=float, default=1e-4); parser.add_argument('--lam_max', type=float, default=1e-1)
    parser.add_argument('--overhead_mb', type=float, default=0.6)
    parser.add_argument('--faces_per_vertex', type=float, default=2.5)
    parser.add_argument('--phase_a_overshoot', type=float, default=1.0)
    parser.add_argument('--probe_cmd', type=str, required=True)
    parser.add_argument('--probe_k', type=int, default=4096); parser.add_argument('--probe_r', type=int, default=256)
    parser.add_argument('--probe_xyz', type=str, required=True)
    parser.add_argument('--probe_dc', type=str, default='q7'); parser.add_argument('--probe_dictionary_rounds', type=int, default=2)
    args = parser.parse_args(sys.argv[1:])
    args.save_iterations.append(args.iterations)
    if args.probe_a_every < 0: sys.exit(f'--probe_a_every must be >= 0, got {args.probe_a_every}')
    if args.target_mb <= 0 or not (0 < args.lam_min < args.lam_max) or args.phase_a_overshoot < 1.0 or not (0.5 <= args.probe_floor < 1.0) or args.probe_scaling < 1 or not (0 < args.sigma_prior <= 1):
        sys.exit(f'bad controller settings: target_mb {args.target_mb} lam range [{args.lam_min}, {args.lam_max}] overshoot {args.phase_a_overshoot} probe_floor {args.probe_floor}')
    if not args.probe_xyz.startswith('q') or not args.probe_xyz[1:].isdigit() or not (12 <= int(args.probe_xyz[1:]) <= 18):
        sys.exit(f'--probe_xyz must be q12..q18, got {args.probe_xyz}')
    _probe_script = [t for t in shlex.split(args.probe_cmd) if t.endswith('.py')]
    if not _probe_script or not os.path.isfile(_probe_script[-1]):
        sys.exit(f'--probe_cmd must name an existing probe script: {args.probe_cmd}')
    print('Optimizing ' + args.model_path, '| RD growth+prune adapt-v9b target_mb', args.target_mb, '| hold_lambda (ablation)', args.hold_lambda, 'phase-A probes every', args.probe_a_every, 'overshoot', args.phase_a_overshoot, 'probe', args.probe_cmd, 'lam0', args.lam, 'mode', args.dd_mode, 'norm', args.dd_norm, 'B/v', args.bytes_per_vertex,
          'schedule', args.split_schedule, '| prune', args.prune_iters, 'mu', args.prune_mu, 'max_frac', args.prune_max_frac, 'B/face', args.bytes_per_face)
    if args.split_schedule and not os.path.isfile(args.split_schedule):
        sys.exit(f'split schedule not found: {args.split_schedule}')
    up.lpips_fn = lpips.LPIPS(net='vgg').to(device='cuda')
    safe_state(args.quiet)
    if args.seed is not None:
        import random as _random, numpy as _np
        _random.seed(args.seed); _np.random.seed(args.seed); torch.manual_seed(args.seed); torch.cuda.manual_seed_all(args.seed); print('[RD] reseeded with', args.seed)
    lps, ops, pps = lp.extract(args), op.extract(args), pp.extract(args)
    if args.indoor:
        ops = update_indoor(ops)
    torch.autograd.set_detect_anomaly(args.detect_anomaly)
    training(lps, ops, pps, args.test_iterations, args.start_checkpoint, args.debug_from, args.scene_name,
             rd=dict(trim_hold=args.trim_hold, trim_margin=args.trim_margin, trim_start=args.trim_start, trim_exact=args.trim_exact, hold_lambda=args.hold_lambda, lam=args.lam, bytes_per_vertex=args.bytes_per_vertex, dd_mode=args.dd_mode, dd_norm=args.dd_norm, split_schedule=args.split_schedule,
                     prune_iters=args.prune_iters, prune_mu=args.prune_mu, prune_max_frac=args.prune_max_frac, bytes_per_face=args.bytes_per_face, probe_extra_iters=args.probe_extra_iters, probe_a_every=args.probe_a_every, probe_a_smoke=args.probe_a_smoke,
                     allow_any_prune_iter=args.allow_any_prune_iter, target_mb=args.target_mb, probe_floor=args.probe_floor, probe_scaling=args.probe_scaling, probe_check_scaling=args.probe_check_scaling, sigma_prior=args.sigma_prior,
                     lam_min=args.lam_min, lam_max=args.lam_max, overhead_mb=args.overhead_mb, faces_per_vertex=args.faces_per_vertex, phase_a_overshoot=args.phase_a_overshoot,
                     probe_cmd=args.probe_cmd, probe_k=args.probe_k, probe_r=args.probe_r, probe_xyz=args.probe_xyz, probe_dc=args.probe_dc, probe_dictionary_rounds=args.probe_dictionary_rounds))
