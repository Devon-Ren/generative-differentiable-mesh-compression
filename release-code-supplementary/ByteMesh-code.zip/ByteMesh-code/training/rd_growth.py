import json
import torch
import torch.nn.functional as F

class RDAccumulator:

    def __init__(self, n_tri, mode='error', device='cuda', norm='mpx'):
        assert mode in ('error', 'grad', 'importance'), mode
        assert norm in ('mpx', 'none'), norm
        self.mode = mode
        self.norm = norm
        self.device = device
        self.reset(n_tri)

    def reset(self, n_tri):
        self.err = torch.zeros(n_tri, dtype=torch.float32, device=self.device)
        self.views = 0

    def apply_mask(self, keep_mask):
        if self.err.numel() != keep_mask.numel():
            raise RuntimeError(f'accumulator/triangle mismatch: {self.err.numel()} vs {keep_mask.numel()}')
        self.err = self.err[keep_mask]

    @torch.no_grad()
    def accumulate(self, render_pkg, image, gt_image, triangle_indices, vertex_grad=None):
        n = self.err.numel()
        if self.mode == 'error':
            ids = render_pkg['rend_ids']
            ids = ids.reshape(ids.shape[-2], ids.shape[-1])
            res = (image.detach() - gt_image).abs().mean(0)
            if ids.shape != res.shape:
                ids = F.interpolate(ids[None, None].float(), size=res.shape, mode='nearest')[0, 0]
            ids = ids.reshape(-1).round().long()
            res = res.reshape(-1)
            if self.norm == 'mpx':
                res = res / (res.numel() / 1e6)
            valid = (ids >= 0) & (ids < n)
            self.err.index_add_(0, ids[valid], res[valid])
            self.valid_frac = float(valid.float().mean())
        elif self.mode == 'grad':
            if vertex_grad is None:
                raise RuntimeError('grad mode needs vertex_grad (triangles.vertices.grad before zero_grad)')
            g = vertex_grad.norm(dim=1)
            self.err += g[triangle_indices.long()].sum(1)
        else:
            pass
        self.views += 1

    def distortion(self):
        return self.err / max(self.views, 1)

def rd_select(acc, triangles, lam, bytes_per_split, max_split, size_probs_zero, size_probs_zero_image_space):
    dD = acc.distortion()
    areas = triangles.triangle_areas().squeeze()
    ratio = dD / float(bytes_per_split)
    allowed = (areas >= size_probs_zero) & (triangles.image_size >= size_probs_zero_image_space)
    ratio = torch.where(allowed, ratio, torch.zeros_like(ratio))
    passing = ratio > lam
    n_pass = int(passing.sum())
    if acc.mode == 'importance':
        probs = triangles.importance_score.squeeze().clone()
        probs = torch.where(allowed, probs, torch.zeros_like(probs))
        k = min(max_split, int((probs > 0).sum()))
        idx = triangles._sample_alives(probs=probs, num=k) if k > 0 else torch.zeros(0, dtype=torch.long, device=probs.device)
        n_pass = k
    elif n_pass == 0 or max_split <= 0:
        idx = torch.zeros(0, dtype=torch.long, device=ratio.device)
    elif n_pass <= max_split:
        idx = torch.nonzero(passing, as_tuple=True)[0]
    else:
        idx = torch.topk(ratio, max_split, largest=True, sorted=False).indices
    nz = ratio[allowed]
    q = torch.quantile(nz, torch.tensor([0.5, 0.9, 0.99], device=nz.device)).tolist() if nz.numel() > 1000 else [float('nan')] * 3
    stats = dict(n_tri=int(ratio.numel()), n_pass=n_pass, n_split=int(idx.numel()), max_split=int(max_split),
                 ratio_q50=q[0], ratio_q90=q[1], ratio_q99=q[2], views=acc.views, dD_sum=float(dD.sum()),
                 valid_frac=getattr(acc, 'valid_frac', None))
    return idx, stats

def rd_split(triangles, add_idx, iteration, splitt_large_triangles):
    areas = triangles.triangle_areas().squeeze()
    k = min(int(splitt_large_triangles), areas.numel())
    top_idx = torch.topk(areas, k, largest=True, sorted=False).indices if k > 0 else add_idx[:0]
    add_idx = torch.unique(torch.cat([add_idx.to(top_idx.device), top_idx]), sorted=False)
    if add_idx.numel() == 0:
        return 0
    new = triangles._update_params_fast(add_idx, iteration)
    triangles.densification_postfix(*new)
    mask = torch.ones(triangles._triangle_indices.shape[0], dtype=torch.bool)
    mask[add_idx.cpu()] = False
    triangles.prune_triangles(mask)
    return int(add_idx.numel())

class RDLog:
    def __init__(self, path):
        self.path = path
        self.f = open(path, 'a')

    def write(self, **kw):
        self.f.write(json.dumps(kw) + '\n')
        self.f.flush()
