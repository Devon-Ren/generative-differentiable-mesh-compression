"""One historical error-hierarchy build, independent coarse recovery, shared codec."""
import argparse,gc,csv,hashlib
from pathlib import Path
import numpy as np
import torch
from model import subset
from algorithm import save_json,health
from runtime import load_scene,Evaluator,export_asset
from train_collapse_first import detach_state,assess
from preflight import check_original
from optimize import fit
from sharing_after import convert
from codec_benchmark import unpack

def build(wire,limits):
    from legacy_hierarchy import _native_qem
    cpu=lambda t:t.detach().cpu().numpy()
    sh=np.concatenate([cpu(wire['features_dc']),cpu(wire['features_rest'])],axis=1)
    weights=wire.get('opacity_floor',.999)+(1-wire.get('opacity_floor',.999))*cpu(wire['vertex_weight'].sigmoid())
    features=np.concatenate([sh.reshape(len(sh),-1)*np.sqrt(sh.shape[1]/(4*np.pi))/.1,weights.reshape(-1,1)/.1],axis=1).astype(np.float32)
    return _native_qem.build_error(cpu(wire['triangles_points']),cpu(wire['_triangle_indices']),features,limits,80.,lambda row:print('Historical collapse:',row,flush=True))

def select(raw,error):
    index=max(i for i,e in enumerate(raw['error_limits']) if e<=error)
    return index,raw['levels'][index]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('source','seed-asset','dataset','lab','output'):p.add_argument('--'+key,required=True)
    p.add_argument('--images',default='images_2');p.add_argument('--limits',default='1,2,4')
    p.add_argument('--coarse-error',type=float,default=2.)
    p.add_argument('--independent-steps',type=int,default=800,help='0: convert coarse directly to shared')
    p.add_argument('--shared-steps',type=int,default=400)
    p.add_argument('--geo-lr',type=float,default=.005);p.add_argument('--dc-lr',type=float,default=.002)
    p.add_argument('--bank-lr',type=float,default=.0001);p.add_argument('--residual-lr',type=float,default=.0003)
    p.add_argument('--anchor-weight',type=float,default=.005);p.add_argument('--seed',type=int,default=17)
    p.add_argument('--eval-every',type=int,default=200);p.add_argument('--min-steps',type=int,default=400)
    p.add_argument('--patience',type=int,default=3);p.add_argument('--local-steps',type=int,default=0)
    p.add_argument('--max-flip-fraction',type=float,default=.0001)
    p.add_argument('--train-factor',type=int,default=4);p.add_argument('--eval-factor',type=int,default=4)
    p.add_argument('--dictionary-rounds',type=int,default=2)
    a=p.parse_args();limits=[float(x) for x in a.limits.split(',')]
    if a.coarse_error not in limits or any(x<=0 for x in limits) or limits!=sorted(set(limits)):p.error('Increasing positive limits must include coarse-error')
    if min(a.independent_steps,a.shared_steps)<0:p.error('Steps must be nonnegative')
    if min(a.eval_every,a.min_steps,a.patience,a.dictionary_rounds,a.train_factor,a.eval_factor)<=0:p.error('Positive controls required')
    if not torch.cuda.is_available():p.error('CUDA required')
    out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
    save_json(out/'config.json',vars(a));torch.manual_seed(a.seed);np.random.seed(a.seed)
    from stage2_triangle_rasterization import _C
    if _C.shared_stage2_backward_revision()!=2:raise RuntimeError('Renderer revision 2 required')
    seed=unpack(a.seed_asset)
    if seed.get('app_schema')!=2 or np.asarray(seed.get('app_gain',[])).size:raise ValueError('Seed must contain residual SH dictionaries without gain')
    save_json(out/'provenance.json',dict(hierarchy_cpp_sha256=hashlib.sha256((Path(__file__).parent/'legacy_hierarchy/native_qem.cpp').read_bytes()).hexdigest(),seed_usage='Dictionary banks only; mappings recomputed on coarse mesh'))
    torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False
    train,val,test,ssim,official=load_scene(a,True);evaluate=Evaluator(ssim,a.eval_factor)
    save_json(out/'splits.json',dict(train=[c.image_name for c in train],validation=[c.image_name for c in val],test=[c.image_name for c in test],note='Validation held out from this adaptation; previously seen by original reconstruction'))
    wire=detach_state(torch.load(a.source,map_location='cpu',weights_only=False));wire['opacity_floor']=float(official.opacity_floor)
    forward=check_original(wire,official,val[:3],a.eval_factor);save_json(out/'original-forward-check.json',forward)
    if not forward['passed']:raise RuntimeError('Original forward mismatch')
    del official;gc.collect();torch.cuda.empty_cache()
    rows=[]
    def measure(name,w):
        row=dict(stage=name,vertices=len(w['triangles_points']),faces=len(w['_triangle_indices']),validation=assess(w,evaluate,val))
        rows.append(row);save_json(out/'progress.json',rows);print('MEASURE',name,row['faces'],row['validation']['psnr'],flush=True)
    measure('original',wire)
    original_test=assess(wire,evaluate,test)
    original_faces=len(wire['_triangle_indices']);original_vertices=len(wire['triangles_points'])
    raw=build(wire,limits)
    report={k:v for k,v in raw.items() if k not in ('levels','collapses')}
    report['levels']=[dict(error=e,vertices=len(l['ids']),faces=len(l['faces'])) for e,l in zip(raw['error_limits'],raw['levels'])]
    save_json(out/'hierarchy-report.json',report)
    selected_index,level=select(raw,a.coarse_error)
    coarse=subset(wire,np.asarray(level['ids']),np.asarray(level['faces']))
    np.savez(out/'selected-collapse-map.npz',ids=level['ids'],face_ids=level['face_ids'],faces=level['faces'],collapses=raw['collapses'][:raw['offsets'][selected_index]])
    del wire,raw,level;gc.collect()
    torch.save(coarse,out/'coarse-initial.pt');measure('coarse_initial',coarse)
    if a.independent_steps:coarse=fit(coarse,None,a.independent_steps,train,val,evaluate,ssim,a,out/'independent-fit')
    torch.save(coarse,out/'coarse-independent.pt');measure('coarse_independent',coarse)
    shared=convert(coarse,seed,a.dictionary_rounds);del seed;measure('shared_initial',shared)
    if a.shared_steps:shared=fit(shared,None,a.shared_steps,train,val,evaluate,ssim,a,out/'shared-fit',appearance_only=True)
    torch.save(shared,out/'shared-final.pt');measure('shared_fitted',shared)
    decoded,codec=export_asset(shared,out/'delivery');measure('decoded_delivery',decoded)
    summary=dict(stages=rows,codec=codec,original_test=original_test,
        retained_face_ratio=len(coarse['_triangle_indices'])/original_faces,retained_vertex_ratio=len(coarse['triangles_points'])/original_vertices,
        independent_test=assess(coarse,evaluate,test,png_dir=out/'png-coarse'),
        delivery_test=assess(decoded,evaluate,test,png_dir=out/'png-delivery'),
        geometry=health(coarse['triangles_points'],shared['triangles_points'],coarse['_triangle_indices']),
        scope='Prototype measurements; exports even when quality drops. Single coarse asset, not progressive packets.')
    save_json(out/'coarse-summary.json',summary)
    with (out/'results.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=['stage','split','vertices','faces','psnr','ssim','lpips','file_MB']);writer.writeheader()
        for row in rows:
            writer.writerow(dict(stage=row['stage'],split='validation',vertices=row['vertices'],faces=row['faces'],
                **{k:row['validation'][k] for k in ('psnr','ssim','lpips')},file_MB=codec['file_bytes']/1e6 if row['stage']=='decoded_delivery' else ''))
        for name,key in [('original','original_test'),('coarse_independent','independent_test'),('decoded_delivery','delivery_test')]:
            writer.writerow(dict(stage=name,split='test',vertices=original_vertices if name=='original' else len(coarse['triangles_points']),
                faces=original_faces if name=='original' else len(coarse['_triangle_indices']),
                **{k:summary[key][k] for k in ('psnr','ssim','lpips')},file_MB=codec['file_bytes']/1e6 if name=='decoded_delivery' else ''))
    print('COMPLETE',out/'coarse-summary.json',flush=True)
if __name__=='__main__':main()
