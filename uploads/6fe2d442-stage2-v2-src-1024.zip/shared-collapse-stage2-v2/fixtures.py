"""Small deterministic fixtures; no scene files or upstream imports needed."""
from types import SimpleNamespace
import math
import numpy as np
import torch

def wire_grid(n=6):
    x,y=np.meshgrid(np.linspace(-.8,.8,n),np.linspace(-.7,.7,n))
    v=np.stack((x,y,3+.04*x*y),-1).reshape(-1,3).astype(np.float32)
    f=[]
    for j in range(n-1):
        for i in range(n-1):
            a=j*n+i;f.extend(((a,a+1,a+n),(a+1,a+n+1,a+n)))
    rng=np.random.default_rng(3);nv=len(v)
    return dict(triangles_points=torch.from_numpy(v),features_dc=torch.from_numpy(rng.normal(0,.05,(nv,1,3)).astype(np.float32)),
        _triangle_indices=torch.tensor(f,dtype=torch.int32),vertex_weight=torch.full((nv,1),1.5),sigma=torch.tensor(-.2),active_sh_degree=3,
        app_schema=2,app_bank=rng.normal(0,.025,(2,15,3)).astype(np.float32),app_mapping=(np.arange(nv)%2).astype(np.uint16),
        app_gain=np.empty((0,3),np.float32),app_rows=np.arange(nv,dtype=np.uint32),app_correction=np.empty((0,15,3),np.float32),
        app_residual_bank=rng.normal(0,.01,(3,15,3)).astype(np.float32),app_residual_mapping=(np.arange(nv)%3).astype(np.uint16))

def camera(device='cpu',size=64):
    # Row-vector convention used by the upstream CUDA renderer.
    p=torch.zeros((4,4),device=device);p[0,0]=p[1,1]=1/math.tan(.5)
    p[2,2]=100/(100-.01);p[3,2]=-100*.01/(100-.01);p[2,3]=1
    return SimpleNamespace(image_height=size,image_width=size,FoVx=1.,FoVy=1.,
        world_view_transform=torch.eye(4,device=device),full_proj_transform=p,
        camera_center=torch.zeros(3,device=device))

def reference_pixels(v,colors,c,pixels,opacity=.8,sigma=.8,bg=None):
    """Independent differentiable one-triangle reference, interior pixels only.

    Inradius computed from area/perimeter, not copied CUDA intermediates.
    Sorting/coverage/early-stop are fixed; caller must avoid their boundaries.
    """
    hom=torch.cat((v,torch.ones_like(v[:,:1])),1)@c.full_proj_transform.to(v)
    uv=((hom[:,:2]/(hom[:,3:4]+1e-7)+1)*v.new_tensor([c.image_width,c.image_height])-1)*.5
    a,b,d=uv;edge=torch.roll(uv,-1,0)-uv
    normal=torch.stack((edge[:,1],-edge[:,0]),1);normal=normal/normal.norm(dim=1,keepdim=True)
    mid=uv.mean(0);flip=torch.where(((mid-uv)*normal).sum(1)>0,-1.,1.)
    normal=normal*flip[:,None];dist=((pixels[:,None]-uv)*normal).sum(2)
    if not bool((dist.detach()<0).all()):raise ValueError('Reference sample outside triangle')
    phi=dist.max(1).values
    det=(b-a)[0]*(d-a)[1]-(b-a)[1]*(d-a)[0]
    radius=det.abs()/edge.norm(dim=1).sum()
    alpha=(opacity*(-phi/radius).pow(sigma)).clamp_max(.999)
    bc=torch.linalg.solve(torch.stack((b-a,d-a),1),(pixels-a).T).T
    bary=torch.cat((1-bc.sum(1,keepdim=True),bc),1)
    if bg is None:bg=v.new_tensor([.05,.1,.2])
    return alpha[:,None]*(bary@colors)+(1-alpha[:,None])*bg
