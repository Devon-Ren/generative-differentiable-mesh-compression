#
# The original code is under the following copyright:
# Copyright (C) 2023, Inria
# GRAPHDECO research group, https://team.inria.fr/graphdeco
# All rights reserved.
#
# This software is free for non-commercial, research and evaluation use 
# under the terms of the LICENSE_GS.md file.
#
# For inquiries contact george.drettakis@inria.fr
#
# The modifications of the code are under the following copyright:
# Copyright (C) 2024, University of Liege, KAUST and University of Oxford
# TELIM research group, http://www.telecom.ulg.ac.be/
# IVUL research group, https://ivul.kaust.edu.sa/
# VGG research group, https://www.robots.ox.ac.uk/~vgg/
# All rights reserved.
# The modifications are under the LICENSE.md file.
#
# For inquiries contact jan.held@uliege.be
#

from setuptools import setup
from torch.utils.cpp_extension import CUDAExtension, BuildExtension, CUDA_HOME
import os
import sys

# Explicit -L flags are required for Conda's CUDA target layout; environment
# LIBRARY_PATH alone is insufficient with some Conda compiler wrappers.
cuda_library_dirs = []
if CUDA_HOME:
    for relative in ("targets/x86_64-linux/lib", "lib64", "lib"):
        directory = os.path.join(CUDA_HOME, relative)
        if os.path.isdir(directory):
            cuda_library_dirs.append(directory)
print("Explicit CUDA library directories:", cuda_library_dirs, flush=True)

setup(
    name="stage2_triangle_rasterization",
    packages=['stage2_triangle_rasterization'],
    ext_modules=[
        CUDAExtension(
            name="stage2_triangle_rasterization._C",
            library_dirs=cuda_library_dirs,
            runtime_library_dirs=cuda_library_dirs if sys.platform.startswith("linux") else [],
            sources=[
            "cuda_rasterizer/rasterizer_impl.cu",
            "cuda_rasterizer/forward.cu",
            "cuda_rasterizer/backward.cu",
            "cuda_rasterizer/utils.cu",
            "cuda_rasterizer/adam.cu",
            "rasterize_points.cu",
            "ext.cpp"],
            extra_compile_args={"nvcc": ["-I" + os.path.join(os.path.dirname(os.path.abspath(__file__)), "third_party/glm/"), "--use_fast_math"]})
        ],
    cmdclass={
        'build_ext': BuildExtension
    }
)
