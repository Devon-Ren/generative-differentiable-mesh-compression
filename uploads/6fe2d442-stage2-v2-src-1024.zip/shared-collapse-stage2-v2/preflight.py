"""Scene-level forward equivalence, before any collapse or optimization."""
from types import SimpleNamespace
import torch
from model import SharedMesh,render

@torch.no_grad()
def check_original(wire,official,cameras,factor=4):
    from triangle_renderer import render as upstream_render
    official.scaling=factor
    for value in vars(official).values():
        if isinstance(value,torch.Tensor):value.requires_grad_(False)
    model=SharedMesh(wire)
    if not torch.equal(model.vertices,official.vertices):raise AssertionError('Step-zero vertex coordinates changed')
    torch.testing.assert_close(model.opacity,official.get_vertex_weight,atol=0,rtol=0)
    bg=model.x.new_zeros(3);pipe=SimpleNamespace(debug=False,convert_SHs_python=False,depth_ratio=1.)
    rows=[]
    for c in cameras:
        a=upstream_render(c,official,pipe,bg)['render'].clamp(0,1)
        b=render(c,model,factor)['render'].clamp(0,1);gt=c.original_image[:3].to(b.device)
        psnr=lambda x:float(-10*torch.log10((x-gt).square().mean().clamp_min(1e-12)))
        row=dict(camera=c.image_name,max_pixel_error=float((a-b).abs().max()),mean_pixel_error=float((a-b).abs().mean()),
            original_psnr=psnr(a),new_psnr=psnr(b))
        row['passed']=row['mean_pixel_error']<=2e-6 and row['max_pixel_error']<=1e-3 and abs(row['original_psnr']-row['new_psnr'])<=.01
        rows.append(row);print('Original forward check:',row,flush=True)
    return dict(passed=all(r['passed'] for r in rows),views=rows,opacity_floor=model.opacity_floor,
        formula='floor + (1-floor)*sigmoid(saved_weight)',scope='Same source, cameras, geometry, independent SH and supersampling')
