"""Build portable source ZIP; never include local binaries/checkpoints/caches."""
import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
allowed={'.py','.cpp','.cu','.cuh','.h','.hpp','.inl','.md','.sh','.xml','.txt'}
files=sorted(p for p in root.rglob('*') if p.is_file() and p.suffix in allowed and not any(x in p.parts for x in ('build','__pycache__','.pytest_cache')))
manifest=dict(package='collapse-first-stage2-v2',sha256={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    validation='CPU test report included; CUDA and full Room execution require GPU validation, not run locally')
(root/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
output=root.parent/'meshsplatting-collapse-first-v2.zip'
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for p in files+[root/'MANIFEST.json']:archive.write(p,str(Path(root.name)/p.relative_to(root)))
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    for name,digest in manifest['sha256'].items():assert hashlib.sha256(archive.read(root.name+'/'+name)).hexdigest()==digest
print(output,output.stat().st_size,'bytes;',len(files),'source/report files')
