import os,shlex,subprocess,sys,sysconfig
from pathlib import Path
try:
    import pybind11
    include=pybind11.get_include()
except ImportError:
    import torch
    include=str(Path(torch.__file__).parent/'include')
root=Path(__file__).resolve().parent
out=root/('_stage2_collapse'+sysconfig.get_config_var('EXT_SUFFIX'))
cmd=shlex.split(os.environ.get('CXX','c++'))+['-O3','-std=c++17','-shared','-fPIC','-I'+include,'-I'+sysconfig.get_path('include'),str(root/'native_qem.cpp'),'-o',str(out)]
if sys.platform=='darwin':cmd+=['-undefined','dynamic_lookup']
subprocess.run(cmd,check=True);print('CPU builder:',out)
