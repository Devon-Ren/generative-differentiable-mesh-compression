"""stage2-v2: neighbour-context arithmetic coding of the shared-SH index arrays (codec/index_ctx.cpp).

Replaces the zstd-coded app_mapping (and app_residual_mapping when the residual covers every vertex) by two
context-coded streams.  The decoder rebuilds the context from the decoded faces, so this runs AFTER topology
decoding and never transmits neighbour tables.  Fields added to the wire:
  ctx_schema=1, ctx_mapping (uint8), ctx_mapping_k, ctx_mapping_u32 (0: uint16 array, 1: uint32),
  ctx_residual (uint8), ctx_residual_k, ctx_residual_u32   (residual fields only when coded)
"""
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import numpy as np
import local_codec as lc

FIELDS=('ctx_schema','ctx_mapping','ctx_mapping_k','ctx_mapping_u32','ctx_residual','ctx_residual_k','ctx_residual_u32')

def native(cache):
    cache=Path(cache);cache.mkdir(parents=True,exist_ok=True)
    root=Path(__file__).parent;exe=cache/('ctx-'+lc.digest(root/'index_ctx.cpp')[:12]+'-'+lc.digest(root/'native.cpp')[:12])
    if not exe.exists():
        compiler=shlex.split(os.environ.get('CXX','')) or [shutil.which('c++') or 'g++']
        temp=exe.with_suffix('.building');subprocess.run(compiler+['-O3','-std=c++17',str(root/'index_ctx.cpp'),'-o',str(temp)],check=True);temp.replace(exe)
    return exe

def _faces_file(faces,folder,name):
    f=np.asarray(faces);path=Path(folder)/name
    if f.ndim!=2 or f.shape[1]!=3 or f.min()<0:raise ValueError('Expected Nx3 nonnegative faces')
    f.astype('<u4').tofile(path);return path

def _code(exe,command,faces_path,n,src,K,dst):
    lc.call(exe,command,faces_path,n,src,int(K),dst)

def full_coverage(wire):
    rows=np.asarray(wire.get('app_rows',()));n=len(np.asarray(wire['app_mapping']))
    return len(rows)==n and np.array_equal(rows,np.arange(n))

def encode(wire,faces,folder,exe):
    """wire: topology-encoded wire (vertex order = delivered order); faces: int faces in that order."""
    folder=Path(folder);n=len(np.asarray(wire['app_mapping']));fp=_faces_file(faces,folder,'ctx-faces.bin')
    result=dict(wire);result['ctx_schema']=1
    jobs=[('app_mapping','ctx_mapping',len(wire['app_bank']))]
    if wire.get('app_schema')==2 and full_coverage(wire) and len(wire['app_residual_mapping'])==n:
        jobs.append(('app_residual_mapping','ctx_residual',len(wire['app_residual_bank'])))
    for key,out,K in jobs:
        a=np.asarray(wire[key]);src=folder/(out+'-codes.bin');dst=folder/(out+'-stream.bin')
        if a.ndim!=1 or len(a)!=n or a.dtype.kind!='u':raise ValueError(key)
        a.astype('<u4').tofile(src);_code(exe,'encode',fp,n,src,K,dst)
        result.pop(key);result[out]=np.fromfile(dst,np.uint8);result[out+'_k']=int(K);result[out+'_u32']=int(a.dtype.itemsize==4)
    return result

def decode(wire,faces,folder,exe):
    if wire.get('ctx_schema')!=1:raise ValueError('ctx schema')
    folder=Path(folder);n=len(wire['triangles_points']);fp=_faces_file(faces,folder,'ctx-dec-faces.bin')
    result={k:v for k,v in wire.items() if not k.startswith('ctx_')}
    for key,out in (('app_mapping','ctx_mapping'),('app_residual_mapping','ctx_residual')):
        if out not in wire:continue
        src=folder/(out+'-dec-stream.bin');dst=folder/(out+'-dec-codes.bin');np.asarray(wire[out],np.uint8).tofile(src)
        _code(exe,'decode',fp,n,src,wire[out+'_k'],dst)
        a=np.fromfile(dst,np.uint32)
        if len(a)!=n:raise ValueError('decoded index count')
        result[key]=a.astype(np.uint32 if wire[out+'_u32'] else np.uint16)
    return result
