// Neighbour-context coder for the shared-SH index arrays (app_mapping / app_residual_mapping), stage2-v2.
// Reuses the adaptive binary arithmetic coder of native.cpp (same trick as edge.cpp).  Decodable from the
// DELIVERED mesh alone: both sides rebuild, from the decoded faces, each vertex's distinct codes of
// earlier-index neighbours (ascending neighbour index, at most 32), so topology must be decoded first.
//   index_ctx encode faces.bin vertex_count codes.bin K out.bin     codes: uint32[vertex_count]
//   index_ctx decode faces.bin vertex_count in.bin K out.bin        writes uint32[vertex_count]
// Per vertex: m = #candidates.  m>0: hit bit (context m); hit -> 5-bit slot via prefix tree (context m);
// miss or m==0 -> raw code via an adaptive prefix tree over ceil(log2 K) bits (order-0 model of the codes).
#define main xyz_program_main
#include "native.cpp"
#undef main
static const int MAXC=32;
struct Model{int nbits;std::vector<Count> hit,slot,raw;
 Model(U K):nbits(0){while((U(1)<<nbits)<K)nbits++;hit.resize(MAXC+1);slot.resize((MAXC+1)*64);raw.resize(size_t(1)<<(nbits+1));}};
// CSR of earlier neighbours (u<v), ascending, built from the oriented face list; degenerate edges ignored.
static void earlier(const std::vector<U>&f,size_t n,std::vector<int64_t>&ptr,std::vector<U>&dst){
 std::vector<uint64_t> e;e.reserve(f.size()*2);
 for(size_t i=0;i+2<f.size()+0;i+=3){U t[3]={f[i],f[i+1],f[i+2]};
  for(int k=0;k<3;k++){U a=t[k],b=t[(k+1)%3];if(a==b)continue;if(a>=n||b>=n)throw std::runtime_error("face index range");
   U lo=std::min(a,b),hi=std::max(a,b);e.push_back((uint64_t(hi)<<32)|lo);}}
 std::sort(e.begin(),e.end());e.erase(std::unique(e.begin(),e.end()),e.end());
 ptr.assign(n+1,0);for(uint64_t x:e)ptr[(x>>32)+1]++;for(size_t v=0;v<n;v++)ptr[v+1]+=ptr[v];
 dst.resize(e.size());for(uint64_t x:e){U v=U(x>>32);dst[ptr[v]++]=U(x&0xffffffffu);}
 for(size_t v=n;v>0;v--)ptr[v]=ptr[v-1];ptr[0]=0;}
static int candidates(size_t v,const std::vector<int64_t>&ptr,const std::vector<U>&dst,const std::vector<U>&code,U*cand){int m=0;
 for(int64_t j=ptr[v];j<ptr[v+1]&&m<MAXC;j++){U c=code[dst[j]];bool seen=false;for(int k=0;k<m;k++)if(cand[k]==c){seen=true;break;}if(!seen)cand[m++]=c;}
 return m;}
template<class F> static void prefix(int nbits,std::vector<Count>&c,size_t base,U&x,F&&bit){int p=1;U v=0;for(int b=nbits-1;b>=0;b--){int k=bit(c[base+p],(x>>b)&1);v=(v<<1)|k;p=p*2+k;}x=v;}
int main(int argc,char**argv){try{
 if(argc!=7)throw std::runtime_error("encode/decode faces.bin vertex_count codes_or_stream.bin K out.bin");
 bool encoding=std::string(argv[1])=="encode";if(!encoding&&std::string(argv[1])!="decode")throw std::runtime_error("command");
 size_t n=std::stoull(argv[3]);U K=U(std::stoul(argv[5]));if(K<1)throw std::runtime_error("K");
 auto f=read<U>(argv[2]);if(f.size()%3)throw std::runtime_error("faces");
 std::vector<int64_t> ptr;std::vector<U> dst;earlier(f,n,ptr,dst);Model M(K);U cand[MAXC];
 if(encoding){auto code=read<U>(argv[4]);if(code.size()!=n)throw std::runtime_error("code count");Encoder enc;
  auto bit=[&](Count&ct,int b){enc.code(b,ct);return b;};
  for(size_t v=0;v<n;v++){if(code[v]>=K)throw std::runtime_error("code out of range");
   int m=candidates(v,ptr,dst,code,cand);int s=-1;for(int k=0;k<m;k++)if(cand[k]==code[v]){s=k;break;}
   if(m>0){enc.code(s>=0,M.hit[m]);if(s>=0){U x=U(s);prefix(5,M.slot,size_t(m)*64,x,bit);continue;}}
   U x=code[v];prefix(M.nbits,M.raw,0,x,bit);}
  enc.finish();write(argv[6],enc.out.v);
 }else{auto bytes=read<uint8_t>(argv[4]);Decoder dec(bytes);std::vector<U> code(n);
  auto bit=[&](Count&ct,int){return dec.code(ct);};
  for(size_t v=0;v<n;v++){int m=candidates(v,ptr,dst,code,cand);
   if(m>0&&dec.code(M.hit[m])){U x=0;prefix(5,M.slot,size_t(m)*64,x,bit);if(int(x)>=m)throw std::runtime_error("slot out of range");code[v]=cand[x];continue;}
   U x=0;prefix(M.nbits,M.raw,0,x,bit);if(x>=K)throw std::runtime_error("decoded code out of range");code[v]=x;}
  write(argv[6],code);}
 return 0;}catch(const std::exception&e){std::cerr<<"index_ctx: "<<e.what()<<"\n";return 1;}}
