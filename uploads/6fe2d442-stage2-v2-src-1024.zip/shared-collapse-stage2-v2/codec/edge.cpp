// Trusted-input research codec: directed recent-edge cache + new/delta vertex.
// Reuses the tested binary arithmetic coder, not the XYZ command entry point.
#define main xyz_program_main
#include "native.cpp"
#undef main
#include <unordered_map>
struct Cache {
 std::array<std::array<U,2>,64> e{}; size_t count=0;
 std::unordered_map<uint64_t,size_t> latest;
 static uint64_t key(U a,U b){return (uint64_t(a)<<32)|b;}
 void push(U a,U b){size_t slot=count%64;
  if(count>=64){auto old=e[slot];auto it=latest.find(key(old[0],old[1]));if(it!=latest.end()&&it->second==count-64)latest.erase(it);}
  e[slot]={a,b};latest[key(a,b)]=count++;
 }
 int find(U a,U b){auto it=latest.find(key(a,b));return it==latest.end()?-1:int(it->second%64);}
 void triangle(U a,U b,U c){push(a,b);push(b,c);push(c,a);}
};
// Logical byte categories condition arithmetic probabilities; prefix tree codes
// each byte without transmitting frequency tables. Zstd alternative uses bytes.
struct Writer {bool arithmetic;Encoder enc;std::vector<Count> counts=std::vector<Count>(5*256);std::vector<uint8_t> bytes;
 void byte(U x,int cat){if(!arithmetic){bytes.push_back(uint8_t(x));return;}int prefix=1;for(int b=7;b>=0;b--){int bit=(x>>b)&1;enc.code(bit,counts[cat*256+prefix]);prefix=prefix*2+bit;}}
 void var(uint64_t x,int cat){do{U b=U(x&127);x>>=7;byte(b|(x?128:0),cat);}while(x);}
 std::vector<uint8_t> finish(){if(arithmetic){enc.finish();return enc.out.v;}return bytes;}
};
struct Reader {bool arithmetic;const std::vector<uint8_t>&bytes;size_t at=0;Decoder dec;std::vector<Count> counts=std::vector<Count>(5*256);
 Reader(bool a,const std::vector<uint8_t>&b):arithmetic(a),bytes(b),dec(b){}
 U byte(int cat){if(!arithmetic){if(at>=bytes.size())throw std::runtime_error("truncated edge stream");return bytes[at++];}U x=0;int prefix=1;for(int b=7;b>=0;b--){int bit=dec.code(counts[cat*256+prefix]);x=(x<<1)|bit;prefix=prefix*2+bit;}return x;}
 uint64_t var(int cat){uint64_t x=0;for(int i=0;i<5;i++){U b=byte(cat);x|=uint64_t(b&127)<<(7*i);if(!(b&128))return x;}throw std::runtime_error("oversized varint");}
};
int main(int argc,char**argv){try{
 if(argc!=7)throw std::runtime_error("encode/decode input output vertex_count face_count arithmetic");
 bool encoding=std::string(argv[1])=="encode";if(!encoding&&std::string(argv[1])!="decode")throw std::runtime_error("command");
 size_t n=std::stoull(argv[4]),nf=std::stoull(argv[5]);bool ac=std::stoi(argv[6]);
 if(n>INT32_MAX)throw std::runtime_error("index range");
 Cache cache;U next=0,last=0;size_t hits=0,newids=0;
 if(encoding){auto f=read<U>(argv[2]);if(f.size()!=nf*3)throw std::runtime_error("face count");Writer w{ac};
  auto vertex=[&](U v,int cat){if(v>=n)throw std::runtime_error("vertex range");if(v==next){w.var(0,cat);next++;newids++;}else{w.var(uint64_t(zig(int64_t(v)-last))+1,cat);}last=v;};
  for(size_t i=0;i<nf;i++){U a=f[i*3],b=f[i*3+1],c=f[i*3+2];int token=-1;
   // First matching cyclic edge; winding never reversed.
   for(int j=0;j<3;j++){U x=f[i*3+j],y=f[i*3+(j+1)%3];int s=cache.find(x,y);bool reverse=false;if(s<0){s=cache.find(y,x);reverse=true;}
    if(s>=0){token=s*2+reverse;a=x;b=y;c=f[i*3+(j+2)%3];break;}}
   w.byte(token<0?0:1,0);if(token<0){vertex(a,2);vertex(b,3);vertex(c,4);}else{hits++;w.byte(token,1);vertex(c,4);}cache.triangle(a,b,c);
  }write(argv[3],w.finish());std::cout<<"edge hits "<<hits<<" / "<<nf<<", implicit new IDs "<<newids<<"\n";
 }else{auto bytes=read<uint8_t>(argv[2]);Reader r(ac,bytes);std::vector<U>f(nf*3);
  auto vertex=[&](int cat){uint64_t v=r.var(cat);int64_t x;if(v==0)x=next++;else{if(v-1>UINT32_MAX)throw std::runtime_error("delta range");x=int64_t(last)+unzig(U(v-1));}if(x<0||uint64_t(x)>=n)throw std::runtime_error("decoded vertex range");last=U(x);return U(x);};
  for(size_t i=0;i<nf;i++){U tag=r.byte(0),a,b,c;if(tag==0){a=vertex(2);b=vertex(3);c=vertex(4);}else if(tag==1){U token=r.byte(1),slot=token/2;if(token>127||slot>=std::min<size_t>(cache.count,64))throw std::runtime_error("edge slot");a=cache.e[slot][0];b=cache.e[slot][1];if(token&1)std::swap(a,b);c=vertex(4);}else throw std::runtime_error("edge tag");f[i*3]=a;f[i*3+1]=b;f[i*3+2]=c;cache.triangle(a,b,c);}
  if(!ac&&r.at!=bytes.size())throw std::runtime_error("trailing edge bytes");write(argv[3],f);
 }return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
