"""Trusted local checkpoint benchmark. No quantization, reordering or retraining.

All saved fields are retained, including auxiliary fields. The standalone packet
contains JSON schema metadata and binary compressed arrays, not JSON float lists.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import time
import numpy as np
import torch
import zstandard as zstd
import meshoptimizer as meshopt

MAGIC = b'MSLB001\0'
METHODS = ('zstd', 'shuffle-zstd', 'meshopt-zstd')
CHUNK = 4 * 1024 * 1024

def category(key):
    return {'triangles_points':'positions', '_triangle_indices':'connectivity',
            'features_dc':'SH', 'features_rest':'SH', 'vertex_weight':'weights',
            'sigma':'render_metadata', 'active_sh_degree':'render_metadata'}.get(key, 'auxiliary')

def array_of(value):
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().contiguous().numpy(), 'torch'
    if isinstance(value, np.ndarray):
        return np.ascontiguousarray(value), 'numpy'
    if type(value) in (int, float, bool) or value is None:
        return None, 'scalar'
    raise TypeError(f'Unsupported saved field type: {type(value)}')

def encode_block(a, key, method):
    if method == 'auto':
        # Existing decoder records per-block transform, so no guessing at decode.
        candidates=[encode_block(a,key,m) for m in ('zstd','shuffle-zstd')]
        return min(candidates,key=lambda item:len(item[0]))
    raw = a.tobytes()
    mode = 'raw'
    payload = raw
    if method == 'meshopt-zstd' and key == '_triangle_indices' and a.size:
        if a.min() < 0 or a.max() >= 2**32:
            raise ValueError('Index outside uint32 range')
        payload = meshopt.encode_index_sequence(a.astype(np.uint32).reshape(-1))
        mode = 'index-sequence'
    elif method == 'meshopt-zstd' and key == 'triangles_points' and a.size:
        if a.dtype != np.float32 or a.shape[1:] != (3,):
            raise ValueError('Expected float32 Nx3 positions')
        payload = meshopt.encode_vertex_buffer(a, len(a), 12)
        mode = 'vertex-buffer'
    elif method != 'zstd' and a.dtype.itemsize > 1:
        payload = a.view(np.uint8).reshape(-1, a.dtype.itemsize).T.copy().tobytes()
        mode = 'shuffle'
    encoded = zstd.ZstdCompressor(level=9).compress(payload)
    # Same raw fallback for all baselines; codec choice is transmitted.
    if len(encoded) >= len(raw):
        return raw, 'raw', False
    return encoded, mode, True

def pack(state, path, method):
    fields = []
    start = time.perf_counter()
    # Payload is streamed to disk to avoid keeping several full assets in RAM.
    payload_path = path.with_suffix('.payload.tmp')
    with payload_path.open('xb') as f:
        for key, value in state.items():
            a, kind = array_of(value)
            field = dict(name=key, kind=kind, category=category(key))
            if kind == 'scalar':
                field['value'] = value
            else:
                if a.dtype.hasobject: raise TypeError('Object arrays not supported')
                shape = list(a.shape)
                a = np.ascontiguousarray(a)
                field.update(dtype=a.dtype.str, shape=shape, blocks=[], raw_bytes=a.nbytes)
                rows = a.reshape((a.shape[0], -1)) if a.ndim and a.shape[0] else a.reshape(1, -1)
                stride = max(1, rows.shape[1] * a.dtype.itemsize)
                step = max(1, CHUNK // stride)
                for offset in range(0, len(rows), step):
                    block = rows[offset:offset+step].copy()
                    data, mode, compressed = encode_block(block, key, method)
                    field['blocks'].append(dict(offset=f.tell(), size=len(data), rows=len(block),
                        cols=block.shape[1], mode=mode, compressed=compressed,
                        sha256=hashlib.sha256(block.tobytes()).hexdigest()))
                    f.write(data)
                field['payload_bytes'] = sum(b['size'] for b in field['blocks'])
            fields.append(field)
    header = json.dumps(dict(method=method, fields=fields), allow_nan=False, separators=(',', ':')).encode()
    with path.open('xb') as out, payload_path.open('rb') as payload:
        out.write(MAGIC + struct.pack('<Q', len(header)) + header)
        while data := payload.read(CHUNK): out.write(data)
    payload_path.unlink()
    return dict(method=method, file_bytes=path.stat().st_size, header_bytes=16+len(header),
                encode_seconds=time.perf_counter()-start, fields=fields)

def unpack(path):
    state = {}
    with Path(path).open('rb') as f:
        if f.read(8) != MAGIC: raise ValueError('Invalid magic')
        length = struct.unpack('<Q', f.read(8))[0]
        if length > 64*1024**2: raise ValueError('Header too large')
        meta = json.loads(f.read(length)); base = f.tell()
        for field in meta['fields']:
            if field['kind'] == 'scalar':
                state[field['name']] = field['value']; continue
            dtype = np.dtype(field['dtype'])
            if dtype.hasobject: raise ValueError('Unsafe dtype')
            parts = []
            for b in field['blocks']:
                f.seek(base+b['offset']); data = f.read(b['size'])
                if len(data) != b['size']: raise ValueError('Truncated payload')
                if b['compressed']: data = zstd.ZstdDecompressor().decompress(data)
                if b['mode'] == 'shuffle':
                    data = np.frombuffer(data,np.uint8).reshape(dtype.itemsize,-1).T.copy().tobytes()
                elif b['mode'] == 'index-sequence':
                    data = meshopt.decode_index_sequence(b['rows']*b['cols'],4,data).astype(dtype).tobytes()
                elif b['mode'] == 'vertex-buffer':
                    data = meshopt.decode_vertex_buffer(b['rows'],12,data).tobytes()
                elif b['mode'] != 'raw': raise ValueError('Unknown transform')
                if hashlib.sha256(data).hexdigest() != b['sha256']: raise ValueError('Checksum mismatch')
                parts.append(np.frombuffer(data,dtype).copy())
            a = np.concatenate(parts).reshape(field['shape'])
            state[field['name']] = torch.from_numpy(a) if field['kind']=='torch' else a
    return state

def equal(a,b):
    if list(a) != list(b): raise AssertionError('Fields differ')
    for key in a:
        x,k = array_of(a[key]); y,j = array_of(b[key])
        assert k==j,key
        if k=='scalar': assert type(a[key])==type(b[key]) and a[key]==b[key],key
        else: assert x.shape==y.shape and x.dtype==y.dtype and x.tobytes()==y.tobytes(),key

def main():
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
    b=sub.add_parser('benchmark'); b.add_argument('checkpoint'); b.add_argument('output')
    d=sub.add_parser('decode'); d.add_argument('packet'); d.add_argument('checkpoint')
    a=p.parse_args()
    if a.cmd=='decode':
        target=Path(a.checkpoint)
        if target.exists(): raise FileExistsError(target)
        state=unpack(a.packet); target.parent.mkdir(parents=True,exist_ok=True); torch.save(state,target)
        print('Decoded checkpoint:',target); return
    output=Path(a.output); output.mkdir(parents=True,exist_ok=False)
    # Only run on your own trusted training checkpoint; not arbitrary downloads.
    state=torch.load(a.checkpoint,map_location='cpu',weights_only=False)
    raw=sum(array_of(v)[0].nbytes for v in state.values() if array_of(v)[0] is not None)
    report=dict(source=str(Path(a.checkpoint).resolve()),source_pt_bytes=Path(a.checkpoint).stat().st_size,
        raw_array_bytes=raw, scope='All saved fields, original ordering, no quantization; not PT-container-byte identity',methods=[])
    for method in METHODS:
        path=output/(method+'.mslb'); result=pack(state,path,method)
        start=time.perf_counter(); restored=unpack(path); result['decode_seconds']=time.perf_counter()-start
        equal(state,restored); del restored
        result.update(bit_exact=True,ratio_vs_raw_arrays=raw/result['file_bytes'],
                      ratio_vs_pt=report['source_pt_bytes']/result['file_bytes'])
        report['methods'].append(result)
        (output/'report.json').write_text(json.dumps(report,indent=2))
        print(method,'MB',round(result['file_bytes']/1e6,3),'raw ratio',round(result['ratio_vs_raw_arrays'],3),'BIT EXACT PASS',flush=True)

if __name__=='__main__': main()
