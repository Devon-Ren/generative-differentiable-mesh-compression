"""Semantic-equivalent reordering, no source-order permutation in the packet.

Only trusted, stripped delivery assets with explicitly supported fields accepted.
Source permutations exist only transiently for encoder-side semantic auditing.
"""
import argparse
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import tempfile
import time
import numpy as np
import torch
import meshoptimizer as mo
from codec_benchmark import pack, unpack, equal
import local_codec as lc
import index_context as ic

VERTEX=('triangles_points','features_dc','vertex_weight','app_mapping','app_gain')
SPARSE=('app_correction','app_residual_mapping')
FIXED={'sigma','active_sh_degree','opacity_floor','app_schema','app_bank','app_residual_bank','delivery_schema','vertex_weight_const','vertex_weight_cols'}
TOPOLOGIES=('raw','meshopt','edge-zstd','edge-arithmetic')

def take(a,p):
    return a[torch.from_numpy(p.astype(np.int64))].contiguous() if isinstance(a,torch.Tensor) else np.ascontiguousarray(a[p])

def validate(s):
    n=len(s['triangles_points']);f=s['_triangle_indices']
    allowed=set(VERTEX)|set(SPARSE)|FIXED|{'app_rows','_triangle_indices'}
    allowed|={'quant_'+field+'_'+k for field in ('triangles_points','features_dc') for k in ('bits','kind','low','scale')}
    if set(s)-allowed:raise ValueError('Unclassified fields; refusing silent attribute loss: '+str(set(s)-allowed))
    if s.get('delivery_schema')!=1 or s.get('app_schema') not in (1,2):raise ValueError('Unsupported schema')
    if not isinstance(f,torch.Tensor) or f.dtype!=torch.int32 or f.ndim!=2 or f.shape[1]!=3 or not len(f):raise ValueError('Expected nonempty int32 faces')
    if f.min()<0 or f.max()>=n:raise ValueError('Invalid faces')
    for k in VERTEX:
        if k in s and np.prod(s[k].shape) and len(s[k])!=n:raise ValueError('Vertex field '+k)
    rows=np.asarray(s['app_rows'])
    if rows.ndim!=1 or (len(rows) and (rows.max()>=n or np.any(rows[1:]<=rows[:-1]))):raise ValueError('Sparse rows')
    key='app_residual_mapping' if s['app_schema']==2 else 'app_correction'
    if len(s[key])!=len(rows):raise ValueError('Sparse attribute count')
    return n

def reorder(s,order):
    n=validate(s);f=s['_triangle_indices'].numpy().astype(np.uint32).reshape(-1)
    if order in ('cache-fetch','strip-fetch'):
        dst=np.empty_like(f);fun=mo.optimize_vertex_cache if order=='cache-fetch' else mo.optimize_vertex_cache_strip
        fun(dst,f,len(f),n);f=dst
    elif order not in ('original','fetch'):raise ValueError(order)
    if order=='original':p=np.arange(n,dtype=np.int64);inv=p.copy()
    else:
        inv=np.full(n,0xffffffff,np.uint32);used=int(mo.optimize_vertex_fetch_remap(inv,f,len(f),n))
        missing=inv==0xffffffff;inv[missing]=np.arange(used,n,dtype=np.uint32)
        if int(missing.sum())!=n-used or not np.array_equal(np.sort(inv),np.arange(n,dtype=np.uint32)):raise AssertionError('Not a permutation')
        p=np.argsort(inv).astype(np.int64)
    result=dict(s)
    for k in VERTEX:
        if k in s and np.prod(s[k].shape):result[k]=take(s[k],p)
    rows=inv[np.asarray(s['app_rows']).astype(np.int64)];idx=np.argsort(rows)
    result['app_rows']=rows[idx].astype(s['app_rows'].dtype)
    for k in SPARSE:
        if k in s and len(s[k]):result[k]=take(s[k],idx)
    result['_triangle_indices']=torch.from_numpy(inv[f].reshape(-1,3).astype(np.int32))
    return result,p

def cyclic(f):
    # Lexicographically minimal CYCLIC rotation, preserving orientation and
    # multiplicity even for repeated IDs, degenerate and duplicate triangles.
    a=np.asarray(f).copy()
    for r in (1,2):
        b=np.roll(f,r,axis=1)
        smaller=(b[:,0]<a[:,0])|((b[:,0]==a[:,0])&((b[:,1]<a[:,1])|((b[:,1]==a[:,1])&(b[:,2]<a[:,2]))))
        a[smaller]=b[smaller]
    return a

def sorted_faces(f):
    a=cyclic(f);return a[np.lexsort((a[:,2],a[:,1],a[:,0]))]

def semantic_audit(source,target,p):
    n=validate(target)
    if set(source)!=set(target) or len(p)!=n or not np.array_equal(np.sort(p),np.arange(n)):raise AssertionError('Fields/permutation')
    inverse=np.argsort(p)
    for k in VERTEX:
        if k in source:
            equal({k:source[k]},{k:take(target[k],inverse) if np.prod(target[k].shape) else target[k]})
    mapped=p[np.asarray(target['app_rows']).astype(np.int64)];idx=np.argsort(mapped)
    equal({'rows':source['app_rows']},{'rows':mapped[idx].astype(source['app_rows'].dtype)})
    for k in SPARSE:
        if k in source:equal({k:source[k]},{k:take(target[k],idx) if len(target[k]) else target[k]})
    special=set(VERTEX)|set(SPARSE)|{'app_rows','_triangle_indices'}
    equal({k:v for k,v in source.items() if k not in special},{k:v for k,v in target.items() if k not in special})
    a=sorted_faces(source['_triangle_indices'].numpy())
    b=sorted_faces(p[target['_triangle_indices'].numpy()].astype(np.int32))
    if not np.array_equal(a,b):raise AssertionError('Oriented face multiset changed')
    return dict(same_geometry=True,same_oriented_topology_with_multiplicity=True,
                same_all_attributes=True,permutation_transmitted=False,rendering_verified=False)

def edge_native(cache):
    cache=Path(cache);cache.mkdir(parents=True,exist_ok=True)
    root=Path(__file__).parent;exe=cache/('edge-'+lc.digest(root/'edge.cpp')[:12]+'-'+lc.digest(root/'native.cpp')[:12])
    if not exe.exists():
        compiler=shlex.split(os.environ.get('CXX','')) or [shutil.which('c++') or 'g++']
        temp=exe.with_suffix('.building');subprocess.run(compiler+['-O3','-std=c++17',str(root/'edge.cpp'),'-o',str(temp)],check=True);temp.replace(exe)
    return exe

def encode(s,topo,entropy,exe,edge,folder,pred,ctx=None):
    # stage2-v2: ctx = index_context.native(...) codes app_mapping/app_residual_mapping with neighbour context after topology.
    # FP32 fallback retains XYZ directly; integer XYZ uses causal prediction.
    xyz_mode=2 if np.asarray(s['triangles_points']).dtype.kind=='u' else 0
    wire=lc.encode(s,False,xyz_mode,entropy,exe,folder,pred)
    wire.update(top_schema=1,top_codec=TOPOLOGIES.index(topo),top_n=len(s['triangles_points']),top_f=len(s['_triangle_indices']))
    if topo=='raw':return ic.encode(wire,s['_triangle_indices'].numpy(),folder,ctx) if ctx is not None else wire
    f=s['_triangle_indices'].numpy().astype(np.uint32)
    if topo=='meshopt':data=mo.encode_index_buffer(f.reshape(-1),f.size,len(s['triangles_points']))
    elif topo in ('edge-zstd','edge-arithmetic'):
        src=folder/'edge-input.bin';dst=folder/'edge-output.bin';f.tofile(src)
        lc.call(edge,'encode',src,dst,len(s['triangles_points']),len(f),int(topo=='edge-arithmetic'));data=dst.read_bytes()
    else:raise ValueError(topo)
    wire.pop('_triangle_indices');wire['top_stream']=np.frombuffer(data,np.uint8).copy()
    if ctx is not None:wire=ic.encode(wire,s['_triangle_indices'].numpy(),folder,ctx)
    return wire

def decode(w,exe,edge,folder,ctx=None):
    if w.get('top_schema')!=1:raise ValueError('Topology schema')
    if w['top_codec'] not in range(len(TOPOLOGIES)):raise ValueError('Topology codec')
    topo=TOPOLOGIES[w['top_codec']];s={k:v for k,v in w.items() if not k.startswith('top_')}
    if topo=='meshopt':f=mo.decode_index_buffer(w['top_f']*3,4,w['top_stream'].tobytes()).reshape(-1,3)
    elif topo in ('edge-zstd','edge-arithmetic'):
        src=folder/'edge-dec-input.bin';dst=folder/'edge-dec-output.bin';w['top_stream'].tofile(src)
        lc.call(edge,'decode',src,dst,w['top_n'],w['top_f'],int(topo=='edge-arithmetic'));f=np.fromfile(dst,np.uint32).reshape(-1,3)
    elif topo!='raw':raise ValueError(topo)
    if topo!='raw':s['_triangle_indices']=torch.from_numpy(f.astype(np.int32))
    result=lc.decode(s,exe,folder)
    if 'ctx_schema' in result:
        if ctx is None:raise ValueError('Asset uses context-coded indices; index_context native required')
        result=ic.decode(result,result['_triangle_indices'].numpy(),folder,ctx)
    return result

def read_asset(path,cache,folder):
    w=unpack(path)
    if 'top_schema' in w:return decode(w,lc.native(cache),edge_native(cache),folder,ic.native(cache))
    if 'local_schema' in w:return lc.decode(w,lc.native(cache),folder)
    return w

def main():
    p=argparse.ArgumentParser();p.add_argument('--asset',required=True);p.add_argument('--output',required=True);p.add_argument('--resume',action='store_true')
    a=p.parse_args();out=Path(a.output).resolve();root=Path(__file__).parent
    fp=dict(input=str(Path(a.asset).resolve()),sha256=lc.digest(a.asset),code={k:lc.digest(root/k) for k in ('topology.py','edge.cpp','native.cpp','local_codec.py','codec_benchmark.py')})
    if out.exists():
        if not a.resume or json.loads((out/'experiment.json').read_text())!=fp:raise ValueError('New output directory or identical --resume required')
    else:out.mkdir(parents=True);lc.save(out/'experiment.json',fp)
    exe=lc.native(out/'native');edge=edge_native(out/'native');results=[]
    source=unpack(a.asset);validate(source)
    for order in ('original','fetch','cache-fetch','strip-fetch'):
        start=time.perf_counter();s,perm=reorder(source,order);audit=semantic_audit(source,s,perm);order_seconds=time.perf_counter()-start
        with tempfile.TemporaryDirectory(dir=out) as temp:
            temp=Path(temp);pred=lc.graph(exe,s,temp)
            for topo in ('raw','meshopt','edge-zstd','edge-arithmetic'):
                for entropy in (0,1):
                    name=order+'_'+topo+('_xyz-ac' if entropy else '_xyz-zstd');done=out/(name+'.json')
                    if done.exists():
                        row=json.loads(done.read_text())
                        if lc.digest(row['asset'])!=row['sha256']:raise ValueError('Changed completed packet')
                    else:
                        print('START',name,flush=True);start=time.perf_counter()
                        w=encode(s,topo,entropy,exe,edge,temp,pred)
                        attempt=Path(tempfile.mkdtemp(prefix=name+'-',dir=out));path=attempt/'asset.mslb';info=pack(w,path,'auto');del w
                        enc=time.perf_counter()-start;start=time.perf_counter()
                        with tempfile.TemporaryDirectory(dir=out) as d:
                            recovered=decode(unpack(path),exe,edge,Path(d))
                            # All attributes byte-exact in NEW order; face row order
                            # exact up to cyclic rotations. No equality by coordinates.
                            if set(s)!=set(recovered):raise AssertionError('Decoded fields differ')
                            equal({k:v for k,v in s.items() if k!='_triangle_indices'}, {k:recovered[k] for k in s if k!='_triangle_indices'})
                            if not np.array_equal(cyclic(s['_triangle_indices'].numpy()),cyclic(recovered['_triangle_indices'].numpy())):raise AssertionError('Face roundtrip')
                            del recovered
                        dec=time.perf_counter()-start
                        payload={f['name']:f.get('payload_bytes',0) for f in info['fields']}
                        row=dict(name=name,order=order,topology=topo,xyz_entropy=entropy,asset=str(path),sha256=lc.digest(path),file_bytes=path.stat().st_size,
                            payload_bytes=payload,topology_bytes=payload.get('top_stream',payload.get('_triangle_indices',0)),xyz_bytes=payload['local_residual'],
                            mapping_bytes=sum(payload.get(k,0) for k in ('app_mapping','app_rows','app_residual_mapping')),
                            topology_payload_bits_per_face=8*payload.get('top_stream',payload.get('_triangle_indices',0))/len(s['_triangle_indices']),
                            xyz_payload_bits_per_vertex=8*payload['local_residual']/len(s['triangles_points']),
                            reorder_audit_seconds=order_seconds,encode_seconds_excluding_reorder_graph=enc,decode_and_exact_audit_seconds=dec,
                            semantic_audit=audit,decoded_reordered_attributes_bit_exact=True,decoded_oriented_faces_exact=True)
                        lc.save(done,row);print('DONE',name,path.stat().st_size/1e6,'MB; semantic PASS, GPU pending',flush=True)
                    results.append(row);lc.save(out/'progress.json',dict(completed=len(results),total=32,results=results))
    winner=min(results,key=lambda r:r['file_bytes'])
    baseline=next(r for r in results if r['name']=='original_raw_xyz-ac')
    lc.save(out/'topology-summary.json',dict(input_asset=a.asset,input_bytes=Path(a.asset).stat().st_size,vertices=len(source['triangles_points']),faces=len(source['_triangle_indices']),
        smallest_semantic_candidate=winner['name'],same_package_baseline_bytes=baseline['file_bytes'],
        best_saving_vs_same_package_baseline_percent=100*(1-winner['file_bytes']/baseline['file_bytes']),
        render_acceptance='PENDING: run render_check.py; no same-render claim from CPU alone',results=results))
    print('COMPLETE',out/'topology-summary.json',flush=True)

if __name__=='__main__':main()
