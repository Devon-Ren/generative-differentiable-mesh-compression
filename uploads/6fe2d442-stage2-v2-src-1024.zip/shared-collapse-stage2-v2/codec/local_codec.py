"""CPU-only exact recompression of a trusted quantized delivery asset."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import numpy as np
import torch
import meshoptimizer as meshopt
from codec_benchmark import pack,unpack,equal

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for data in iter(lambda:f.read(8*1024*1024),b''):h.update(data)
    return h.hexdigest()

def save(path,value):
    path=Path(path);temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2));temp.replace(path)

def native(cache):
    if sys.byteorder!='little':raise RuntimeError('Version 1 requires a little-endian host')
    cache=Path(cache);cache.mkdir(parents=True,exist_ok=True);source=Path(__file__).with_name('native.cpp')
    exe=cache/('local-'+digest(source)[:16])
    if not exe.exists():
        compiler=shlex.split(os.environ.get('CXX','')) or [shutil.which('c++') or shutil.which('g++') or 'c++']
        tmp=cache/(exe.name+'.building')
        subprocess.run(compiler+['-std=c++17','-O3',str(source),'-o',str(tmp)],check=True)
        tmp.replace(exe)
    return exe

def call(exe,*args):subprocess.run([str(exe),*map(str,args)],check=True)

def topo_encode(faces):
    a=faces.numpy()
    if a.dtype!=np.int32 or a.ndim!=2 or a.shape[1]!=3 or (a.size and a.min()<0):raise ValueError('Expected int32 triangle tensor')
    blob=meshopt.encode_index_buffer(a.astype(np.uint32).reshape(-1),a.size,int(a.max())+1)
    b=meshopt.decode_index_buffer(a.size,4,blob).reshape(-1,3).astype(np.int32)
    rotation=np.full(len(a),255,np.uint8)
    for r in range(3):
        match=(rotation==255)&np.all(np.roll(b,r,axis=1)==a,axis=1);rotation[match]=r
    if np.any(rotation==255):raise ValueError('Triangle codec changed face order or winding')
    return np.frombuffer(blob,np.uint8).copy(),rotation

def topo_decode(blob,rotation,count):
    if rotation.shape!=(count,) or np.any(rotation>2):raise ValueError('Bad rotations')
    b=meshopt.decode_index_buffer(count*3,4,blob.tobytes()).reshape(-1,3).astype(np.int32)
    out=b.copy()
    for r in (1,2):
        mask=rotation==r;out[mask]=np.roll(b[mask],r,axis=1)
    return torch.from_numpy(out)

def graph(exe,state,folder):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    f=folder/'faces.bin';p=folder/'predictors.bin'
    state['_triangle_indices'].numpy().astype('<i4',copy=False).tofile(f)
    call(exe,'build',f,len(state['triangles_points']),p)
    return p

def encode(state,topology,mode,entropy,exe,folder,predictors):
    result=dict(state)
    result.update(local_schema=1,local_topology=int(topology),local_xyz=mode,local_entropy=entropy)
    if topology:
        b,r=topo_encode(state['_triangle_indices'])
        result.pop('_triangle_indices');result.update(local_faces=b,local_rotations=r,local_face_count=len(r))
    if mode:
        q=np.asarray(state['triangles_points'])
        if q.dtype.kind!='u' or q.ndim!=2 or q.shape[1]!=3 or q.max()>0xffffff:raise ValueError('Expected <=24-bit integer XYZ')
        qpath=folder/'q.bin';rpath=folder/'residual.bin';q.astype('<u4').tofile(qpath)
        call(exe,'encode',predictors,qpath,rpath,mode,len(q),entropy)
        result.pop('triangles_points')
        result.update(local_vertex_count=len(q),local_xyz_itemsize=q.dtype.itemsize,
                      local_residual=np.fromfile(rpath,np.uint8 if entropy else np.uint32))
    return result

def decode(state,exe,folder):
    if state['local_schema']!=1:raise ValueError('Unknown schema')
    result={k:v for k,v in state.items() if not k.startswith('local_')}
    if state['local_topology']:
        result['_triangle_indices']=topo_decode(state['local_faces'],state['local_rotations'],state['local_face_count'])
    mode=state['local_xyz']
    if mode:
        n=state['local_vertex_count'];itemsize=state['local_xyz_itemsize']
        if itemsize not in (2,4):raise ValueError('Bad XYZ dtype')
        # Build causality again from the DECODED topology, without encoder tables.
        f=folder/'decode-faces.bin';p=folder/'decode-predictors.bin'
        result['_triangle_indices'].numpy().astype('<i4',copy=False).tofile(f)
        call(exe,'build',f,n,p)
        r=folder/'decode-residual.bin';q=folder/'decode-q.bin';state['local_residual'].tofile(r)
        call(exe,'decode',p,r,q,mode,n,state['local_entropy'])
        recovered=np.fromfile(q,np.uint32).reshape(n,3)
        if itemsize==2 and recovered.max()>65535:raise ValueError('XYZ overflow')
        result['triangles_points']=recovered.astype(np.uint16 if itemsize==2 else np.uint32)
    return result

def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True)
    b=sub.add_parser('benchmark');b.add_argument('--asset',required=True);b.add_argument('--output',required=True);b.add_argument('--resume',action='store_true')
    d=sub.add_parser('decode');d.add_argument('--asset',required=True);d.add_argument('--output',required=True)
    a=p.parse_args();out=Path(a.output).resolve()
    if a.command=='decode':
        if out.exists():raise FileExistsError(out)
        out.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=out.parent) as temp:
            exe=native(Path(temp)/'native');restored=decode(unpack(a.asset),exe,Path(temp))
            pack(restored,out,'auto')
        print('Decoded original quantized delivery arrays:',out);return
    fingerprint=dict(input_sha256=digest(a.asset),source=str(Path(a.asset).resolve()),
        code={n:digest(Path(__file__).with_name(n)) for n in ('local_codec.py','native.cpp','codec_benchmark.py')})
    if out.exists():
        if not a.resume or json.loads((out/'experiment.json').read_text())!=fingerprint:raise ValueError('Use new output or identical --resume')
    else:out.mkdir(parents=True);save(out/'experiment.json',fingerprint)
    exe=native(out/'native');source=unpack(a.asset)
    if 'local_schema' in source:raise ValueError('Input must be the original selected quantized delivery')
    q=source['triangles_points']
    if not isinstance(q,np.ndarray) or q.dtype.kind!='u':raise ValueError('Input needs quantized integer XYZ')
    plans=[('baseline-auto',0,0,0),('triangle-codec',1,0,0)]
    for entropy in (0,1):
        for mode,label in [(1,'previous'),(2,'neighbor'),(3,'parallelogram')]:
            plans.append((label+('-arithmetic' if entropy else '-zstd'),0,mode,entropy))
    for entropy in (0,1):
        for mode,label in [(1,'previous'),(2,'neighbor'),(3,'parallelogram')]:
            plans.append(('triangle-'+label+('-arithmetic' if entropy else '-zstd'),1,mode,entropy))
    results=[]
    with tempfile.TemporaryDirectory(prefix='encoder-',dir=out) as temp:
        temp=Path(temp);start=time.perf_counter();predictors=graph(exe,source,temp)
        graph_seconds=time.perf_counter()-start
        pp=np.fromfile(predictors,np.int32).reshape(-1,4)
        stats=dict(vertices=len(q),faces=len(source['_triangle_indices']),neighbor_vertices=int((pp[:,0]>=0).sum()),
                   parallelogram_vertices=int((pp[:,1]>=0).sum()),graph_seconds=graph_seconds)
        del pp;save(out/'predictor-stats.json',stats)
        for name,topo,mode,entropy in plans:
            done=out/(name+'.json')
            if done.exists():
                row=json.loads(done.read_text())
                if digest(row['asset'])!=row['sha256']:raise ValueError('Completed packet changed')
                results.append(row);continue
            print('START',name,flush=True)
            start=time.perf_counter();encoded=encode(source,topo,mode,entropy,exe,temp,predictors)
            attempt=Path(tempfile.mkdtemp(prefix=name+'-',dir=out));path=attempt/'asset.mslb'
            info=pack(encoded,path,'auto');encode_seconds=time.perf_counter()-start
            del encoded
            start=time.perf_counter()
            with tempfile.TemporaryDirectory(prefix='decode-',dir=out) as decdir:
                restored=decode(unpack(path),exe,Path(decdir))
                equal(source,{k:restored[k] for k in source})
                if set(restored)!=set(source):raise AssertionError('Extra decoded fields')
            decode_seconds=time.perf_counter()-start;del restored
            row=dict(name=name,asset=str(path),sha256=digest(path),file_bytes=path.stat().st_size,
                saving_vs_input_percent=100*(1-path.stat().st_size/Path(a.asset).stat().st_size),
                encode_seconds_excluding_graph=encode_seconds,decode_seconds_including_graph=decode_seconds,
                exact_all_quantized_asset_fields=True,topology_codec=bool(topo),predictor=mode,arithmetic=bool(entropy),
                payload_bytes={f['name']:f.get('payload_bytes',0) for f in info['fields']})
            fields=row['payload_bytes']
            row['topology_payload_bytes']=sum(fields.get(k,0) for k in ('_triangle_indices','local_faces','local_rotations'))
            row['xyz_payload_bytes']=sum(fields.get(k,0) for k in ('triangles_points','local_residual'))
            row['topology_payload_bits_per_face']=row['topology_payload_bytes']*8/len(source['_triangle_indices'])
            row['xyz_payload_bits_per_vertex']=row['xyz_payload_bytes']*8/len(q)
            save(done,row);results.append(row)
            save(out/'progress.json',dict(completed=len(results),total=len(plans),results=results))
            print('DONE',name,'MB',row['file_bytes']/1e6,'EXACT PASS',flush=True)
    best=min(results,key=lambda r:r['file_bytes'])
    winner=best['name'] if best['file_bytes']<Path(a.asset).stat().st_size else 'input-asset'
    save(out/'local-codec-summary.json',dict(input_bytes=Path(a.asset).stat().st_size,input_asset=a.asset,
        selected=winner,predictor_stats=stats,results=results,
        scope='Exact relative to the selected quantized asset, including face/corner/vertex order and all SH fields. No new quantization or rendering.',
        arithmetic_context='axis, predictor kind, bit position, previous residual magnitude bucket; adaptive binary counts. Outer Zstd/raw fallback also counted.',
        temporary_graph_not_transmitted=True))
    print('COMPLETE:',out/'local-codec-summary.json',flush=True)

if __name__=='__main__':main()
