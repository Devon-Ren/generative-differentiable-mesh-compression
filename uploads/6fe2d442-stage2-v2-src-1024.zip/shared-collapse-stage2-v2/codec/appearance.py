"""Directional codebook prototype: geometry/DC stay fixed; assignments are discrete."""
import numpy as np
import torch
from torch import nn

def unit_bank(bank):
    # Clamp BEFORE sqrt: sqrt(0)'s infinite derivative can produce 0*inf=NaN
    # even when a later clamp makes the forward denominator nonzero.
    return bank / bank.square().sum(1,keepdim=True).clamp_min(1e-16).sqrt()

@torch.no_grad()
def assign(x, bank, gain=False, rows=4096, codes=256):
    """Exact blocked nearest code, uniform-sphere SH L2 proxy, never N x K stored.

    Gain minimizes per-channel least squares; a zero code predicts zero.
    Source/centres have shape N/K x 15 x 3; lower code wins exact ties.
    """
    n=len(x); mapping=torch.empty(n,dtype=torch.long,device=x.device)
    gains=torch.ones(n,3,device=x.device,dtype=x.dtype) if gain else None
    bank=unit_bank(bank) if gain else bank
    for begin in range(0,n,rows):
        chunk=x[begin:begin+rows]; best=torch.full((len(chunk),),float('inf'),device=x.device)
        ids=torch.zeros(len(chunk),dtype=torch.long,device=x.device)
        norm=chunk.square().sum((1,2))
        for offset in range(0,len(bank),codes):
            b=bank[offset:offset+codes]
            if gain:
                dot=torch.einsum('nfc,kfc->nkc',chunk,b)
                dist=norm[:,None]-(dot.square()/b.square().sum(1).clamp_min(1e-16)[None]).sum(2)
            else:
                dist=norm[:,None]+b.square().sum((1,2))[None]-2*(chunk.flatten(1)@b.flatten(1).T)
            value,index=dist.min(1); better=value<best
            best=torch.where(better,value,best);ids=torch.where(better,index+offset,ids)
        mapping[begin:begin+len(chunk)]=ids
        if gain:
            b=bank[ids];gains[begin:begin+len(chunk)]=(chunk*b).sum(1)/b.square().sum(1).clamp_min(1e-16)
    return mapping,gains

@torch.no_grad()
def initialize(source,k,gain=False,samples=65536,rounds=8,seed=7):
    if not 1<=k<=min(len(source),samples):raise ValueError('K exceeds sample count')
    generator=torch.Generator(device=source.device).manual_seed(seed)
    # Random subset without an N x K allocation.
    idx=torch.randperm(len(source),device=source.device,generator=generator)[:samples]
    x=source[idx];bank=x[torch.randperm(len(x),device=x.device,generator=generator)[:k]].clone()
    for iteration in range(rounds):
        if gain:bank=unit_bank(bank)
        z,g=assign(x,bank,gain)
        sums=torch.zeros_like(bank)
        if gain:
            sums.index_add_(0,z,x*g[:,None,:])
            den=torch.zeros(k,3,device=x.device);den.index_add_(0,z,g.square())
            update=sums/den[:,None].clamp_min(1e-12)
        else:
            sums.index_add_(0,z,x);den=torch.bincount(z,minlength=k)
            update=sums/den[:,None,None].clamp_min(1)
        used=torch.bincount(z,minlength=k)>0
        bank[used]=update[used]
        print('Dictionary initialization',iteration+1,'used',int(used.sum()),'/',k,flush=True)
    if gain:bank=unit_bank(bank)
    z,g=assign(source,bank,gain)
    return Directional(bank,z,g)

def old_partition(vertices,faces,dc):
    """Same 0.01 spatial / 0.25 DC / connected-component / 64-ID grouping as baseline."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    scale=np.linalg.norm(np.ptp(vertices.astype(np.float64),axis=0))
    if scale<=0:raise ValueError('Empty spatial extent')
    keys=np.column_stack((np.floor((vertices-vertices.min(0))/(scale*.01)),np.floor(dc.reshape(-1,3)/.25))).astype(np.int64)
    _,bucket=np.unique(keys,axis=0,return_inverse=True)
    a=faces[:,[0,1,2]].reshape(-1);b=faces[:,[1,2,0]].reshape(-1);keep=bucket[a]==bucket[b]
    graph=coo_matrix((np.ones(int(keep.sum()),np.uint8),(a[keep],b[keep])),shape=(len(vertices),len(vertices))).tocsr()
    _,labels=connected_components(graph,directed=False)
    order=np.argsort(labels,kind='stable');starts=np.r_[0,np.flatnonzero(np.diff(labels[order]))+1]
    ranks=np.arange(len(vertices))-np.repeat(starts,np.diff(np.r_[starts,len(vertices)]))
    _,group=np.unique(np.column_stack((labels[order],ranks//64)),axis=0,return_inverse=True)
    mapping=np.empty(len(vertices),np.int64);mapping[order]=group
    return mapping

@torch.no_grad()
def initialize_old(source,vertices,faces,dc):
    z=torch.as_tensor(old_partition(vertices,faces,dc),device=source.device)
    bank=torch.zeros(int(z.max())+1,15,3,device=source.device)
    bank.index_add_(0,z,source);bank/=torch.bincount(z)[:,None,None]
    residual=source-bank[z];scores=residual.square().mean((1,2)).sqrt()
    eligible=torch.nonzero(scores>.03).flatten()
    chosen=eligible[torch.argsort(scores[eligible],descending=True,stable=True)[:int(len(source)*.1)]].sort().values
    return Directional(bank,z,None,chosen,residual[chosen])

class Directional(nn.Module):
    def __init__(self,bank,mapping,gains=None,rows=None,correction=None):
        super().__init__();self.bank=nn.Parameter(bank.clone())
        self.register_buffer('mapping',mapping.long().clone())
        self.gains=nn.Parameter(gains.clone()) if gains is not None else None
        rows=torch.empty(0,dtype=torch.long,device=bank.device) if rows is None else rows
        self.register_buffer('rows',rows.clone())
        correction=torch.empty(0,15,3,device=bank.device) if correction is None else correction
        self.correction=nn.Parameter(correction.clone())

    def materialize(self,ids=None):
        bank=unit_bank(self.bank) if self.gains is not None else self.bank
        if ids is None:
            result=bank[self.mapping]
            if self.gains is not None:result=result*self.gains[:,None,:]
            if len(self.rows):result=result.index_add(0,self.rows,self.correction)
            return result
        result=bank[self.mapping[ids]]
        if self.gains is not None:result=result*self.gains[ids,None,:]
        if len(self.rows):
            pos=torch.searchsorted(self.rows,ids);safe=pos.clamp_max(len(self.rows)-1)
            result=result+torch.where((self.rows[safe]==ids)[:,None,None],self.correction[safe],0.)
        return result

    @torch.no_grad()
    def reassign(self,source,anchor):
        # After image fitting, do not force all vertices back to the source proxy.
        # Compare old/new labels against a blended previous representation target.
        z=torch.empty_like(self.mapping);g=torch.empty_like(self.gains) if self.gains is not None else None
        for start in range(0,len(source),4096):
            ids=torch.arange(start,min(start+4096,len(source)),device=source.device)
            target=(1-anchor)*self.materialize(ids)+anchor*source[ids]
            zz,gg=assign(target,self.bank,self.gains is not None)
            z[ids]=zz
            if g is not None:g[ids]=gg
        self.mapping.copy_(z)
        if g is not None:self.gains.copy_(g)

    @torch.no_grad()
    def wire(self):
        bank=unit_bank(self.bank) if self.gains is not None else self.bank
        used,mapping=torch.unique(self.mapping,sorted=True,return_inverse=True)
        dtype=np.uint16 if len(used)<=65536 else np.uint32
        return dict(app_bank=bank[used].cpu().numpy(),app_mapping=mapping.cpu().numpy().astype(dtype),
            app_gain=(self.gains.detach().cpu().numpy() if self.gains is not None else np.empty((0,3),np.float32)),
            app_rows=self.rows.cpu().numpy().astype(np.uint32),app_correction=self.correction.detach().cpu().numpy(),
            app_schema=1)

def expand_wire(wire):
    if wire['app_schema']==2:
        base=dict(wire);base['app_schema']=1
        base['app_rows']=np.empty(0,np.uint32);base['app_correction']=np.empty((0,15,3),np.float32)
        a=expand_wire(base)
        rows=np.asarray(wire['app_rows']).astype(np.int64)
        bank=np.asarray(wire['app_residual_bank']);ids=np.asarray(wire['app_residual_mapping']).astype(np.int64)
        if bank.ndim!=3 or bank.shape[1:]!=(15,3) or ids.shape!=rows.shape or rows.ndim!=1:raise ValueError('Bad residual shape')
        if len(rows) and (rows.min()<0 or rows.max()>=len(a) or np.any(np.diff(rows)<=0) or ids.min()<0 or ids.max()>=len(bank)):raise ValueError('Bad residual index')
        a[rows]+=bank[ids]
        if not np.isfinite(a).all():raise ValueError('Nonfinite residual appearance')
        return a
    bank=np.asarray(wire['app_bank']);mapping=np.asarray(wire['app_mapping']).astype(np.int64)
    if wire['app_schema']!=1 or bank.shape[1:]!=(15,3) or mapping.ndim!=1:raise ValueError('Bad appearance schema')
    if len(mapping) and (mapping.min()<0 or mapping.max()>=len(bank)):raise ValueError('Invalid code index')
    a=bank[mapping].copy();g=np.asarray(wire['app_gain'])
    if g.size:
        if g.shape!=(len(a),3):raise ValueError('Invalid gain shape')
        a*=g[:,None,:]
    rows=np.asarray(wire['app_rows']).astype(np.int64);corr=np.asarray(wire['app_correction'])
    if corr.shape!=(len(rows),15,3) or (len(rows) and (rows.min()<0 or rows.max()>=len(a) or np.any(np.diff(rows)<=0))):raise ValueError('Invalid exception rows')
    a[rows]+=corr
    if not np.isfinite(a).all():raise ValueError('Nonfinite appearance')
    return a

class ResidualDirectional(Directional):
    """Frozen primary dictionary + trainable shared residual; no per-vertex gains."""
    def __init__(self,base,rows,bank,mapping):
        super().__init__(base.bank.detach(),base.mapping,rows=rows)
        self.bank.requires_grad_(False)
        self.correction=nn.Parameter(bank.clone())
        self.register_buffer('residual_mapping',mapping.long().clone())

    def materialize(self,ids=None):
        if ids is None:
            return self.bank[self.mapping].index_add(0,self.rows,self.correction[self.residual_mapping])
        result=self.bank[self.mapping[ids]]
        if len(self.rows):
            pos=torch.searchsorted(self.rows,ids).clamp_max(len(self.rows)-1)
            result=result+torch.where((self.rows[pos]==ids)[:,None,None],self.correction[self.residual_mapping[pos]],0.)
        return result

    @torch.no_grad()
    def reassign(self,source,anchor):
        target=(1-anchor)*self.materialize(self.rows)+anchor*source[self.rows]-self.bank[self.mapping[self.rows]]
        ids,_=assign(target,self.correction)
        self.residual_mapping.copy_(ids)

    @torch.no_grad()
    def wire(self):
        used,z=torch.unique(self.mapping,sorted=True,return_inverse=True)
        ru,rz=torch.unique(self.residual_mapping,sorted=True,return_inverse=True)
        return dict(app_schema=2,app_bank=self.bank[used].cpu().numpy(),
            app_mapping=z.cpu().numpy().astype(np.uint16 if len(used)<=65536 else np.uint32),
            app_gain=np.empty((0,3),np.float32),app_rows=self.rows.cpu().numpy().astype(np.uint32),
            app_correction=np.empty((0,15,3),np.float32),
            app_residual_bank=self.correction[ru].cpu().numpy(),
            app_residual_mapping=rz.cpu().numpy().astype(np.uint16 if len(ru)<=65536 else np.uint32))

@torch.no_grad()
def initialize_residual(source,base,k=256,fraction=.25,samples=65536,rounds=8,seed=7):
    if not 0<fraction<=1:raise ValueError('Invalid residual fraction')
    residual=source-base.materialize()
    scores=residual.square().mean((1,2))
    rows=torch.argsort(scores,descending=True,stable=True)[:max(1,int(len(source)*fraction))].sort().values
    model=initialize(residual[rows],k,False,samples,rounds,seed)
    return ResidualDirectional(base,rows,model.bank.detach(),model.mapping)
