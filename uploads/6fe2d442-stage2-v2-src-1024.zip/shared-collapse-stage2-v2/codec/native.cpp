#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using U=uint32_t; using I=int32_t;
template<class T> std::vector<T> read(const std::string&p){std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error("open "+p);auto s=f.tellg();if(s<0||size_t(s)%sizeof(T))throw std::runtime_error("bad file length");std::vector<T>a(size_t(s)/sizeof(T));f.seekg(0);f.read((char*)a.data(),s);return a;}
template<class T> void write(const std::string&p,const std::vector<T>&a){std::ofstream f(p,std::ios::binary);f.write((char*)a.data(),a.size()*sizeof(T));if(!f)throw std::runtime_error("write "+p);}
struct Edge{I b,c,a;bool operator<(const Edge&o)const{return std::array<I,3>{b,c,a}<std::array<I,3>{o.b,o.c,o.a};}};
void build(const std::string&fpath,size_t n,const std::string&out){
 auto f=read<I>(fpath);if(f.size()%3)throw std::runtime_error("faces");
 std::vector<I>p(n*4,-1);std::vector<Edge>edges;edges.reserve(f.size());
 for(size_t j=0;j<f.size();j+=3)for(int k=0;k<3;k++){
  I b=f[j+k],c=f[j+(k+1)%3],a=f[j+(k+2)%3];
  if(b<0||c<0||a<0||size_t(std::max({a,b,c}))>=n)throw std::runtime_error("index range");
  if(b==c)continue;if(b>c)std::swap(b,c);
  I &v=p[size_t(c)*4];if(v<0||b<v)v=b;
  edges.push_back({b,c,a});
 }
 std::sort(edges.begin(),edges.end());
 for(size_t j=0;j<edges.size();){size_t end=j+1;while(end<edges.size()&&edges[end].b==edges[j].b&&edges[end].c==edges[j].c)end++;
  I b=edges[j].b,c=edges[j].c,a=-1;
  for(size_t k=j;k<end;k++)if(edges[k].a!=b&&edges[k].a!=c){a=edges[k].a;break;}
  if(a<0){j=end;continue;}
  for(size_t k=j;k<end;k++){I d=edges[k].a;if(d<=c||a>=d||a==b||a==c)continue;
   I* old=&p[size_t(d)*4+1];std::array<I,3>candidate{a,b,c};
   if(old[0]<0||candidate<std::array<I,3>{old[0],old[1],old[2]})std::copy(candidate.begin(),candidate.end(),old);
  }j=end;
 }
 write(out,p);
}
int kind(size_t i,int mode,const std::vector<I>&p){if(mode==3&&p[i*4+1]>=0)return 3;if(mode>=2&&p[i*4]>=0)return 2;return i?1:0;}
int64_t pred(size_t i,int axis,int type,const std::vector<I>&p,const std::vector<U>&q){
 if(type==0)return 0;if(type==1)return q[(i-1)*3+axis];if(type==2)return q[size_t(p[i*4])*3+axis];
 return int64_t(q[size_t(p[i*4+2])*3+axis])+q[size_t(p[i*4+3])*3+axis]-q[size_t(p[i*4+1])*3+axis];
}
U zig(int64_t v){if(v < -INT32_MAX || v>INT32_MAX)throw std::runtime_error("residual range");return v>=0?U(v*2):U(-v*2-1);}
int64_t unzig(U v){return (v&1)?-int64_t(v/2)-1:int64_t(v/2);}
struct BitsOut{std::vector<uint8_t>v;uint8_t byte=0;int used=0;void put(int b){byte=uint8_t((byte<<1)|b);if(++used==8){v.push_back(byte);byte=0;used=0;}}void finish(){if(used)v.push_back(uint8_t(byte<<(8-used)));}};
struct BitsIn{const std::vector<uint8_t>&v;size_t bit=0;int get(){size_t j=bit++;return j/8<v.size()?((v[j/8]>>(7-j%8))&1):0;}};
struct Count{U zero=1,one=1;void update(int b){(b?one:zero)++;if(zero+one>=32768){zero=(zero+1)/2;one=(one+1)/2;}}};
struct Encoder{U lo=0,hi=~U(0);size_t pending=0;BitsOut out;
 void emit(int b){out.put(b);while(pending){out.put(1-b);pending--;}}
 void code(int b,Count&c){uint64_t range=uint64_t(hi)-lo+1;U mid=U(uint64_t(lo)+range*c.zero/(c.zero+c.one)-1);if(b)lo=mid+1;else hi=mid;
  for(;;){if(hi<0x80000000u)emit(0);else if(lo>=0x80000000u){emit(1);lo-=0x80000000u;hi-=0x80000000u;}else if(lo>=0x40000000u&&hi<0xc0000000u){pending++;lo-=0x40000000u;hi-=0x40000000u;}else break;lo<<=1;hi=(hi<<1)|1;}c.update(b);
 }
 void finish(){pending++;emit(lo<0x40000000u?0:1);out.finish();}
};
struct Decoder{U lo=0,hi=~U(0),value=0;BitsIn in;Decoder(const std::vector<uint8_t>&v):in{v}{for(int i=0;i<32;i++)value=(value<<1)|in.get();}
 int code(Count&c){uint64_t range=uint64_t(hi)-lo+1;U mid=U(uint64_t(lo)+range*c.zero/(c.zero+c.one)-1);int b=value>mid;if(b)lo=mid+1;else hi=mid;
  for(;;){if(hi<0x80000000u){}else if(lo>=0x80000000u){value-=0x80000000u;lo-=0x80000000u;hi-=0x80000000u;}else if(lo>=0x40000000u&&hi<0xc0000000u){value-=0x40000000u;lo-=0x40000000u;hi-=0x40000000u;}else break;lo<<=1;hi=(hi<<1)|1;value=(value<<1)|in.get();}c.update(b);return b;
 }
};
int bucket(U v){return v<=1?0:v<=15?1:v<=255?2:3;}
int main(int argc,char**argv){try{
 if(argc<2)throw std::runtime_error("arguments");
 std::string cmd=argv[1];if(cmd=="build"){if(argc!=5)throw std::runtime_error("build arguments");build(argv[2],std::stoull(argv[3]),argv[4]);return 0;}
 // encode/decode predictor-file input output mode n entropy(0=zstd-preprocess,1=arithmetic)
 if(argc!=8)throw std::runtime_error("arguments");int mode=std::stoi(argv[5]);size_t n=std::stoull(argv[6]);int entropy=std::stoi(argv[7]);
 auto p=read<I>(argv[2]);if(p.size()!=n*4||mode<1||mode>3)throw std::runtime_error("predictor shape/mode");
 std::vector<Count>counts(4*3*4*32);std::array<U,3>last{0,0,0};
 auto context=[&](int k,int ax,int bit){return ((k*3+ax)*4+bucket(last[ax]))*32+bit;};
 if(cmd=="encode"){
  auto q=read<U>(argv[3]);if(q.size()!=n*3)throw std::runtime_error("q shape");std::vector<U>r;Encoder enc;
  if(!entropy)r.resize(n*3);
  for(size_t i=0;i<n;i++){int k=kind(i,mode,p);for(int ax=0;ax<3;ax++){U v=zig(int64_t(q[i*3+ax])-pred(i,ax,k,p,q));
   if(entropy){for(int b=31;b>=0;b--)enc.code((v>>b)&1,counts[context(k,ax,b)]);}else r[i*3+ax]=v;last[ax]=v;
  }}
  if(entropy){enc.finish();write(argv[4],enc.out.v);}else write(argv[4],r);
 }else if(cmd=="decode"){
  auto bytes=read<uint8_t>(argv[3]);Decoder dec(bytes);std::vector<U>r;if(!entropy){r=read<U>(argv[3]);if(r.size()!=n*3)throw std::runtime_error("r shape");}
  std::vector<U>q(n*3);
  for(size_t i=0;i<n;i++){int k=kind(i,mode,p);for(int ax=0;ax<3;ax++){U v=0;if(entropy){for(int b=31;b>=0;b--)v=(v<<1)|dec.code(counts[context(k,ax,b)]);}else v=r[i*3+ax];
    int64_t x=pred(i,ax,k,p,q)+unzig(v);if(x<0||x>0xffffff)throw std::runtime_error("decoded q range");q[i*3+ax]=U(x);last[ax]=v;
  }}write(argv[4],q);
 }else throw std::runtime_error("unknown command");return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
