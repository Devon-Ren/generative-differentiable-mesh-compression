import copy
from types import SimpleNamespace
import numpy as np
import pytest
import torch
from fixtures import wire_grid,camera,reference_pixels
from model import SharedMesh,subset
from sh_utils import eval_sh
from algorithm import simplify,health,acceptable

def test_continuous_shared_chain_gradcheck():
    torch.manual_seed(7)
    v=torch.tensor([[-.8,-.6,3.],[.9,-.4,3.2],[.1,.8,2.8]],dtype=torch.double,requires_grad=True)
    dc=(torch.randn(3,1,3,dtype=torch.double)*.03).requires_grad_()
    bank=(torch.randn(2,15,3,dtype=torch.double)*.02).requires_grad_()
    residual=(torch.randn(2,15,3,dtype=torch.double)*.01).requires_grad_()
    z=torch.tensor([0,1,0]);u=torch.tensor([0,0,1]);c=camera();px=v.new_tensor([[30,29],[32,31]])
    def function(v,dc,b,r):
        direction=v/v.norm(dim=1,keepdim=True)
        color=(eval_sh(3,torch.cat((dc,b[z]+r[u]),1).transpose(1,2),direction)+.5).clamp_min(0)
        return reference_pixels(v,color,c,px)
    assert torch.autograd.gradcheck(function,(v,dc,bank,residual),eps=1e-6,atol=2e-5,rtol=1e-3,fast_mode=True)

def test_gather_is_scatter_sum_backward():
    bank=torch.zeros(2,2,requires_grad=True);idx=torch.tensor([1,0,1,1]);w=torch.arange(8.).reshape(4,2)
    (bank[idx]*w).sum().backward();expected=torch.zeros_like(bank).index_add(0,idx,w)
    torch.testing.assert_close(bank.grad,expected)

def test_model_roundtrip_and_local_mask():
    w=wire_grid();m=SharedMesh(w,'cpu');n=SharedMesh(m.wire(),'cpu')
    torch.testing.assert_close(m.colors(torch.zeros(3)),n.colors(torch.zeros(3)))
    m.active=torch.zeros(len(m.x));m.active[0]=1
    m.colors(torch.zeros(3)).sum().backward()
    assert m.x.grad[1:].abs().sum()==0 and m.dc.grad[1:].abs().sum()==0
    assert m.x.grad[0].abs().sum()>0 and m.dc.grad[0].abs().sum()>0

def test_collapse_and_attribute_transfer():
    w=wire_grid(8);candidate,mask,r=simplify(w,np.ones(64),8.,.2)
    assert 0<r['faces']<r['input_faces'] and r['merges']>0
    assert candidate['_triangle_indices'].max()<r['vertices']
    assert len(mask)==r['vertices'] and mask.any()
    assert health(candidate['triangles_points'],candidate['triangles_points'],candidate['_triangle_indices'])['new_zero_area_faces']==0
    assert torch.isfinite(SharedMesh(candidate,'cpu').colors(torch.zeros(3))).all()

def test_error_limit_stops_collapse():
    w=wire_grid();_,_,r=simplify(w,np.ones(36),1e-10,.2)
    assert r['merges']==0

def test_fixed_reference_and_camera_identity():
    a=SimpleNamespace(max_psnr_drop=.25,max_ssim_drop=.008,max_lpips_increase=.015,max_view_drop=1.)
    fixed=dict(psnr=28.,ssim=.88,lpips=.3,per_view=[dict(camera='a',psnr=28.)])
    assert acceptable(fixed,fixed,a)
    bad=copy.deepcopy(fixed);bad['psnr']=27.7
    assert not acceptable(bad,fixed,a)
    bad['per_view'][0]['camera']='b'
    with pytest.raises(ValueError):acceptable(bad,fixed,a)

def test_real_encoder_roundtrip(tmp_path):
    from runtime import export_asset
    from delivery import prepare,restore
    from appearance import expand_wire
    w=wire_grid();decoded,report=export_asset(w,tmp_path/'delivery')
    assert report['file_bytes']>0 and report['semantic_audit']['same_all_attributes']
    assert report['quantization_geometry']['new_zero_area_faces']==0
    assert expand_wire(decoded).shape==(36,15,3)
    assert torch.isfinite(SharedMesh(decoded,'cpu').colors(torch.zeros(3))).all()

def test_seed_exact_source_order():
    from train_stage2 import initial_wire
    from delivery import prepare
    w=wire_grid();seed=prepare(w,'q18','q8',True)
    result=initial_wire(w,seed);torch.testing.assert_close(result['triangles_points'],w['triangles_points'])
    bad=dict(seed);bad['app_schema']=1
    with pytest.raises(ValueError):initial_wire(w,bad)
    bad=dict(seed);bad['triangles_points']=bad['triangles_points'][::-1].copy()
    with pytest.raises(AssertionError):initial_wire(w,bad)

def test_importance_protects_candidates():
    w=wire_grid();_,_,normal=simplify(w,np.ones(36),1.5,.2)
    _,_,protected=simplify(w,np.full(36,100.),1.5,.2)
    assert normal['merges']>0 and protected['merges']==0

def test_invalid_geometry_fails_without_repair():
    w=wire_grid();w['_triangle_indices'][0,1]=w['_triangle_indices'][0,0]
    with pytest.raises(RuntimeError,match='Repeated-vertex'):simplify(w,np.ones(36),8.,.2)

def test_health_detects_orientation_change():
    w=wire_grid(2);v=w['triangles_points'];changed=v.clone();changed[[0,1]]=changed[[1,0]]
    assert health(v,changed,w['_triangle_indices'])['flipped_faces']>0

def test_alpha_cap_contract():
    from pathlib import Path
    root=Path(__file__).parent/'renderer/cuda_rasterizer'
    assert 'min(0.999f, con_o.w * Cx)' in (root/'forward.cu').read_text()
    assert 'min(0.999f, con_o.w * Cx)' in (root/'backward.cu').read_text()

def independent_fixture():
    from appearance import expand_wire
    w=wire_grid();rest=torch.from_numpy(expand_wire(w))
    w={k:v for k,v in w.items() if not k.startswith('app_')};w['features_rest']=rest
    return w

def test_step_zero_and_upstream_loaded_opacity():
    w=independent_fixture();w['vertex_weight'].fill_(-10.)
    model=SharedMesh(w,'cpu')
    assert torch.equal(model.vertices,w['triangles_points'])
    expected=.999+.001*w['vertex_weight'].sigmoid()
    torch.testing.assert_close(model.opacity,expected,atol=0,rtol=0)
    assert float(model.opacity.min())>=.999

def test_local_altitude_trust_skinny_triangles_and_persistent_mask():
    from geometry_trust import configure,project
    w=independent_fixture();w['triangles_points'][:,1]*=1e-5
    model=SharedMesh(w,'cpu');reference=model.vertices.detach().clone()
    mask=np.arange(len(reference))%2==0
    configure(model,mask)
    assert torch.equal(reference,model.vertices)
    model.active=None  # appearance becomes global, geometry must not
    model.vertices.sum().backward()
    assert torch.count_nonzero(model.x.grad[~torch.tensor(mask)])==0
    assert model.x.grad[torch.tensor(mask)].abs().sum()>0
    generator=torch.Generator().manual_seed(18)
    for _ in range(50):
        previous=model.x.detach().clone()
        with torch.no_grad():model.x.add_(torch.randn(model.x.shape,generator=generator)*100)
        project(model,previous)
        assert model.x.norm(dim=1).max()<=.050001
        assert (model.x-previous).norm(dim=1).max()<=.010001
    assert torch.equal(model.vertices[~torch.tensor(mask)],reference[~torch.tensor(mask)])
    report=health(reference,model.vertices,model.faces)
    assert report['flipped_faces']==0 and report['new_zero_area_faces']==0

def test_saved_trainable_tensors_collapse_without_numpy_error():
    w=independent_fixture()
    for k in ('features_dc','features_rest','triangles_points','vertex_weight'):w[k]=torch.nn.Parameter(w[k])
    candidate,_,report=simplify(w,np.ones(36),8.,.2)
    assert report['merges']>0
    assert 'features_rest' in candidate and 'app_schema' not in candidate
    assert all(not candidate[k].requires_grad for k in ('features_dc','features_rest','triangles_points','vertex_weight'))

def test_independent_geometry_and_color_gradients():
    model=SharedMesh(independent_fixture(),'cpu')
    model.colors(torch.zeros(3)).square().mean().backward()
    for p in (model.x,model.dc,model.rest):assert p.grad is not None and torch.isfinite(p.grad).all() and p.grad.norm()>0

def test_full_exceptions_recover_independent_coefficients():
    from sharing_after import exceptions
    from appearance import expand_wire
    original=independent_fixture();original['features_rest']+=.13
    shared=wire_grid();fixed=exceptions(shared,original,1.)
    np.testing.assert_allclose(expand_wire(fixed),original['features_rest'].numpy(),atol=3e-8,rtol=1e-6)
    torch.testing.assert_close(fixed['features_dc'],original['features_dc'])

def test_float_xyz_delivery_fallback(tmp_path):
    from runtime import export_asset
    w=wire_grid();w['opacity_floor']=.999
    decoded,r=export_asset(w,tmp_path/'float','f32','f32')
    assert r['semantic_audit']['same_all_attributes'] and decoded['opacity_floor']==.999

@pytest.mark.parametrize('shared',[False,True])
def test_fit_phases_and_frozen_geometry(monkeypatch,tmp_path,shared):
    import optimize
    w=wire_grid() if shared else independent_fixture();original=w['triangles_points'].clone()
    def image(m):return m.colors(torch.zeros(3)).T.reshape(3,6,6)
    with torch.no_grad():target=image(SharedMesh(w,'cpu'))*.9
    c=SimpleNamespace(original_image=target)
    monkeypatch.setattr(optimize,'SharedMesh',lambda data:SharedMesh(data,'cpu'))
    monkeypatch.setattr(optimize,'render',lambda c,m,f:{'render':image(m)})
    def evaluate(m,views,include_lpips=False):
        loss=float((image(m)-target).abs().mean());return dict(loss=loss,psnr=-10*np.log10(max(loss*loss,1e-12)))
    a=SimpleNamespace(geo_lr=1e-5,dc_lr=.003,bank_lr=.0001,residual_lr=.0003,seed=7,local_steps=1,
        train_factor=1,anchor_weight=.005,eval_every=2,max_flip_fraction=0.,min_steps=4,patience=3)
    output=optimize.fit(w,None if shared else np.ones(36),4,[c],[c],evaluate,
        lambda x,y:1-(x-y).square().mean(),a,tmp_path,appearance_only=shared)
    assert not output['features_dc'].requires_grad
    assert not torch.equal(output['features_dc'],w['features_dc'])
    if shared:assert torch.equal(output['triangles_points'],original)
    assert torch.equal(w['triangles_points'],original)
