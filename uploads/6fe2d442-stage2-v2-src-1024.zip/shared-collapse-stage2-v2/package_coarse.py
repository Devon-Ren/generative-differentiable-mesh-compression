"""Complete source update excluding user scheduler settings and local binaries."""
import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
allowed={'.py','.cpp','.cu','.cuh','.h','.hpp','.inl','.md','.sh','.xml','.txt'}
files=sorted(p for p in root.rglob('*') if p.is_file() and p.suffix in allowed
    and not any(x in p.relative_to(root).parts for x in ('build','__pycache__','.pytest_cache')))
manifest=dict(package='historical-coarse-once-v1',sha256={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    validation='CPU tests only locally; CUDA smoke and Room experiment run on HPC')
(root/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
output=root.parent/'historical-coarse-once-update.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[root/'MANIFEST.json']:
        if p.name!='submit_room.sh':z.write(p,str(p.relative_to(root)))
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
    for name,digest in manifest['sha256'].items():
        if name!='submit_room.sh':assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(output.resolve(),output.stat().st_size)
