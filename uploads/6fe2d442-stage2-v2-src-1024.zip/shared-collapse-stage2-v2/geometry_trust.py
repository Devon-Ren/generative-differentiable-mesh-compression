"""Local-altitude coordinates and projected Adam constraints (not a mesh repair)."""
import numpy as np
import torch

def configure(model, mask=None):
    v=model.reference_vertices.detach().cpu().numpy().astype(np.float64)
    faces=model.faces.detach().cpu().numpy()
    scales=np.full(len(v),np.inf)
    for start in range(0,len(faces),100000):
        f=faces[start:start+100000];a,b,c=v[f[:,0]],v[f[:,1]],v[f[:,2]]
        longest=np.maximum.reduce([np.linalg.norm(b-a,axis=1),np.linalg.norm(c-a,axis=1),np.linalg.norm(c-b,axis=1)])
        altitude=np.linalg.norm(np.cross(b-a,c-a),axis=1)/np.maximum(longest,1e-300)
        altitude[~np.isfinite(altitude)]=0
        for corner in range(3):np.minimum.at(scales,f[:,corner],altitude)
    scales[~np.isfinite(scales)]=0
    model.scale=torch.as_tensor(scales,device=model.x.device,dtype=model.x.dtype)[:,None]
    active=np.ones(len(v),dtype=bool) if mask is None else np.asarray(mask,dtype=bool)
    active=active & (scales>0)
    model.geometry_active=torch.as_tensor(active,device=model.x.device,dtype=model.x.dtype)
    return dict(coordinates='incident minimum triangle altitude',active_vertices=int(active.sum()),
                altitude_quantiles=np.quantile(scales,[0,.1,.5,.9,1]).tolist())

@torch.no_grad()
def project(model, previous, step_limit=.01, total_limit=.05):
    if not 0<step_limit<=total_limit<=.1:raise ValueError('Invalid geometry trust limits')
    delta=model.x-previous
    delta*=torch.clamp(step_limit/delta.norm(dim=1,keepdim=True).clamp_min(1e-30),max=1)
    model.x.copy_(previous+delta)
    model.x.mul_(torch.clamp(total_limit/model.x.norm(dim=1,keepdim=True).clamp_min(1e-30),max=1))
    model.x.mul_(model.geometry_active[:,None])
