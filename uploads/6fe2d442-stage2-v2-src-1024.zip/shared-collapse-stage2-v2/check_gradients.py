"""Mandatory real-CUDA numerical gate, independent reference + actual updates.

Run on the allocated GPU. Passing CPU gradcheck alone is insufficient.
Only RGB loss is covered; auxiliary normal/depth losses are not used by v1.
"""
import argparse
import math
from pathlib import Path
import torch
from fixtures import camera,reference_pixels,wire_grid
from model import SharedMesh,render,optimizer
from algorithm import save_json

def raster(v,color,c,opacity,sigma,faces=None):
    from stage2_triangle_rasterization import TriangleRasterizer,TriangleRasterizationSettings
    bg=v.new_tensor([.05,.1,.2])
    settings=TriangleRasterizationSettings(c.image_height,c.image_width,math.tan(.5),math.tan(.5),bg,1.,
        c.world_view_transform,c.full_proj_transform,3,c.camera_center,False,False)
    if faces is None:faces=torch.tensor([[0,1,2]],device=v.device,dtype=torch.int32)
    return TriangleRasterizer(settings)(vertices=v.contiguous(),triangles_indices=faces,
        vertex_weights=v.new_full((len(v),),opacity),sigma=sigma,scaling=v.new_zeros(len(faces)),colors_precomp=color.contiguous())[0]

def compare_gradients(opacity,sigma):
    c=camera('cuda');v=torch.tensor([[-.8,-.6,3.],[.9,-.4,3.2],[.1,.8,2.8]],device='cuda',requires_grad=True)
    color=torch.tensor([[.2,.4,.7],[.6,.3,.2],[.8,.7,.4]],device='cuda',requires_grad=True)
    xy=torch.tensor([[30,29],[32,31],[29,33]],device='cuda');w=v.new_tensor([[.3,.5,.2],[.7,.2,.1],[.2,.3,.5]])
    image=raster(v,color,c,opacity,sigma);selected=image[:,xy[:,1],xy[:,0]].T
    target=reference_pixels(v,color,c,xy.to(v),opacity,sigma)
    torch.testing.assert_close(selected,target,atol=2e-5,rtol=2e-4)
    grads=torch.autograd.grad((selected*w).sum(),(v,color))
    refs=torch.autograd.grad((target*w).sum(),(v,color))
    errors={}
    for name,g,r in zip(('xyz','color'),grads,refs):
        torch.testing.assert_close(g,r,atol=2e-4,rtol=.015)
        errors[name]=float((g-r).abs().max())
    # Central differences of the CUDA forward itself, all 9 geometry coordinates.
    # Chosen interior pixels are away from coverage/argmax/depth-sort boundaries.
    numeric=torch.empty_like(v);eps=1e-3
    with torch.no_grad():
        for k in range(v.numel()):
            plus=v.detach().clone();minus=plus.clone();plus.view(-1)[k]+=eps;minus.view(-1)[k]-=eps
            hi=raster(plus,color.detach(),c,opacity,sigma)[:,xy[:,1],xy[:,0]].T
            lo=raster(minus,color.detach(),c,opacity,sigma)[:,xy[:,1],xy[:,0]].T
            numeric.view(-1)[k]=((hi-lo)*w).sum()/(2*eps)
    torch.testing.assert_close(grads[0],numeric,atol=4e-4,rtol=.025)
    errors['xyz_cuda_finite_difference']=float((grads[0]-numeric).abs().max())
    return errors

def update_test(independent=False):
    from geometry_trust import configure,project
    c=camera('cuda');wire=wire_grid(5);model=SharedMesh(wire)
    if independent:
        from appearance import expand_wire
        rest=torch.from_numpy(expand_wire(wire));wire={k:v for k,v in wire.items() if not k.startswith('app_')}
        wire['features_rest']=rest;model=SharedMesh(wire)
    configure(model)
    with torch.no_grad():target=(render(c,model,1)['render']*.85+.025).clamp(0,1)
    before={k:p.detach().clone() for k,p in model.named_parameters()}
    opt=optimizer(model);losses=[];norms={}
    for i in range(12):
        opt.zero_grad(set_to_none=True)
        loss=(render(c,model,1)['render']-target).square().mean();loss.backward()
        for k,p in model.named_parameters():
            assert p.grad is not None and torch.isfinite(p.grad).all(),k
            norms[k]=float(p.grad.norm());assert norms[k]>0,k
        previous=model.x.detach().clone()
        losses.append(float(loss));opt.step();project(model,previous)
    changed={k:float((p.detach()-before[k]).abs().max()) for k,p in model.named_parameters()}
    assert all(v>0 for v in changed.values()),changed
    assert min(losses[1:])<losses[0],losses
    # Multiple faces share vertices: checks additive accumulation in real kernel.
    return dict(max_parameter_changes=changed,gradient_norms=norms,initial_loss=losses[0],best_loss=min(losses))

def overlap_test():
    c=camera('cuda');front=torch.tensor([[-.8,-.6,3.],[.9,-.4,3.2],[.1,.8,2.8]],device='cuda')
    v=torch.cat((front,front+front.new_tensor([0.,0.,.5]))).requires_grad_()
    colors=torch.linspace(.2,.8,18,device='cuda').reshape(6,3).requires_grad_()
    faces=torch.tensor([[0,1,2],[3,4,5]],device='cuda',dtype=torch.int32)
    xy=v.new_tensor([[30,29],[32,31]])
    im=raster(v,colors,c,.8,.8,faces)[:,xy[:,1].long(),xy[:,0].long()].T
    black=v.new_zeros(3)
    first=reference_pixels(v[:3],colors[:3],c,xy,.8,.8,black)
    alpha=reference_pixels(v[:3],torch.ones_like(colors[:3]),c,xy,.8,.8,black)
    second=reference_pixels(v[3:],colors[3:],c,xy,.8,.8)
    reference=first+(1-alpha)*second
    torch.testing.assert_close(im,reference,atol=3e-5,rtol=3e-4)
    g=torch.autograd.grad(im.square().sum(),(v,colors));r=torch.autograd.grad(reference.square().sum(),(v,colors))
    for a,b in zip(g,r):torch.testing.assert_close(a,b,atol=3e-4,rtol=.02)
    return dict(max_gradient_error=max(float((a-b).abs().max()) for a,b in zip(g,r)))

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',default='gradient-report.json');a=p.parse_args()
    if not torch.cuda.is_available():raise RuntimeError('GPU required: this gate must not silently skip')
    from stage2_triangle_rasterization import _C
    assert _C.shared_stage2_backward_revision()==2,'Wrong renderer build'
    torch.manual_seed(17);torch.backends.cuda.matmul.allow_tf32=False
    report=dict(gpu=torch.cuda.get_device_name(),renderer=_C.__file__,passed=False)
    try:
        report['ordinary']=compare_gradients(.8,.8)
        report['saturated']=compare_gradients(.99999,.001)
        report['overlap']=overlap_test()
        report['updates']=update_test();report['independent_updates']=update_test(True);report['passed']=True
    finally:save_json(Path(a.output),report)
    print('CUDA gradient gate PASS:',a.output,flush=True)

if __name__=='__main__':main()
