import numpy as np
import torch
from coarse_once import build,select
from model import subset
from test_cpu import independent_fixture

def test_historical_collapse_attribute_correspondence():
    w=independent_fixture();raw=build(w,[1.,2.,4.]);index,level=select(raw,2.)
    coarse=subset(w,np.asarray(level['ids']),np.asarray(level['faces']))
    ids=torch.as_tensor(level['ids']).long()
    assert len(coarse['_triangle_indices'])<len(w['_triangle_indices'])
    assert coarse['_triangle_indices'].max()<len(ids)
    for key in ('triangles_points','features_dc','features_rest','vertex_weight'):
        assert torch.equal(coarse[key],w[key][ids])
    assert raw['offsets'][index]>0
    assert select(dict(error_limits=[0.,1.,4.],levels=['dense','one','four']),2.)==(1,'one')
