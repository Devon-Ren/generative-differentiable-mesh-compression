import json
import numpy as np
import torch
import torch
from model import expand_wire,subset,project,render

def save_json(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2,allow_nan=False));temp.replace(path)

def health(reference,current,faces):
    a=reference.detach().cpu().numpy();b=current.detach().cpu().numpy();f=faces.detach().cpu().numpy().astype(np.int64)
    result=dict(nonfinite_vertices=int((~np.isfinite(b).all(1)).sum()),new_zero_area_faces=0,flipped_faces=0,faces=len(f))
    for start in range(0,len(f),100000):
        ids=f[start:start+100000];x=a[ids].astype(np.float64);y=b[ids].astype(np.float64)
        an=np.cross(x[:,1]-x[:,0],x[:,2]-x[:,0]);bn=np.cross(y[:,1]-y[:,0],y[:,2]-y[:,0])
        result['new_zero_area_faces']+=int((((an*an).sum(1)>0)&((bn*bn).sum(1)<=1e-30)).sum())
        result['flipped_faces']+=int(((an*bn).sum(1)<0).sum())
    result['flipped_fraction']=result['flipped_faces']/max(1,len(f));return result

def acceptable(metrics,fixed,args):
    # All drops are relative to the SAME dense shared reference, never moving.
    if [r['camera'] for r in fixed['per_view']]!=[r['camera'] for r in metrics['per_view']]:raise ValueError('Validation correspondence mismatch')
    return (fixed['psnr']-metrics['psnr']<=args.max_psnr_drop and fixed['ssim']-metrics['ssim']<=args.max_ssim_drop
        and metrics['lpips']-fixed['lpips']<=args.max_lpips_increase
        and max(a['psnr']-b['psnr'] for a,b in zip(fixed['per_view'],metrics['per_view']))<=args.max_view_drop)

@torch.no_grad()
def importance(model,cameras,factor,bg):
    # Training-view proxy: visible incident faces + image residual at projected
    # vertex locations. Not a claim of exact per-pixel vertex contribution.
    total=torch.zeros(len(model.x),device=model.x.device);count=torch.zeros_like(total)
    for i,c in enumerate(cameras):
        output=render(c,model,factor,bg,True);im=output['render'].clamp(0,1);gt=c.original_image[:3].to(im.device)
        residual=(im-gt).abs().mean(0);p,z=project(model.vertices,c)
        finite=torch.isfinite(p).all(1);valid=finite&(z>0)&output['visible']&(p[:,0]>=0)&(p[:,0]<c.image_width)&(p[:,1]>=0)&(p[:,1]<c.image_height)
        ids=torch.where(valid)[0];xy=p[ids].round().long();xy[:,0].clamp_(0,c.image_width-1);xy[:,1].clamp_(0,c.image_height-1)
        total[ids]+=residual[xy[:,1],xy[:,0]];count[ids]+=1
        print('Score training view',i+1,'/',len(cameras),flush=True)
    mean=total/count.clamp_min(1);seen=count>0
    scale=torch.quantile(mean[seen],.75).clamp_min(.01) if seen.any() else mean.new_tensor(.01)
    # High-residual and unobserved regions receive protection, not removal priority.
    w=1+2*(mean/scale).clamp(0,1);w[~seen]=2.
    return w.cpu().numpy(),dict(visible_fraction=float(seen.float().mean()),residual_scale=float(scale))

def simplify(wire,priority,error_limit,batch_fraction,angle=75.,radiance_unit=.15):
    import _stage2_collapse as native
    cpu=lambda t:t.detach().cpu().numpy()
    rest=cpu(wire['features_rest']) if 'features_rest' in wire else expand_wire(wire)
    sh=np.concatenate((cpu(wire['features_dc']),rest),1)
    floor=float(wire.get('opacity_floor',.999))
    features=np.concatenate((sh.reshape(len(sh),-1)*(np.sqrt(16/(4*np.pi))/radiance_unit),
        (floor+(1-floor)*cpu(wire['vertex_weight'].sigmoid())).reshape(-1,1)/.15),1).astype(np.float32)
    def progress(row):print('Collapse:',row,flush=True)
    raw=native.batch(cpu(wire['triangles_points']),cpu(wire['_triangle_indices']),features,priority,error_limit,batch_fraction,angle,progress)
    ids=np.asarray(raw['ids']);faces=np.asarray(raw['faces']);merges=np.asarray(raw['collapses'])
    candidate=subset(wire,ids,faces)
    # Mark all surviving vertices in faces incident to any merge endpoint.
    touched=np.zeros(len(priority),bool)
    if len(merges):touched[merges.reshape(-1)]=True
    original=cpu(wire['_triangle_indices'])
    for start in range(0,len(original),200000):
        tri=original[start:start+200000];hit=touched[tri].any(1)
        # Do not expand repeatedly in-place: collect once below.
        if start==0:neighbor=touched.copy()
        neighbor[tri[hit].reshape(-1)]=True
    mask=neighbor[ids]
    report={k:v for k,v in raw.items() if k not in ('ids','face_ids','faces','collapses')}
    report.update(input_faces=len(original),faces=len(faces),input_vertices=len(priority),vertices=len(ids),merges=len(merges),
        error_limit=error_limit,batch_fraction=batch_fraction,active_fraction=float(mask.mean()),
        score='importance * max(accumulated position radius / median edge, SH+opacity radius)',
        caution='Topology-changing endpoint simplification, not topology-preserving or a global image-error bound')
    return candidate,mask,report
