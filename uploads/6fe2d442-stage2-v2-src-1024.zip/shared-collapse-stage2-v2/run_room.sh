#!/usr/bin/env bash
# No conda activation/deactivation hooks; use the already-working interpreter.
set -eo pipefail
PKG=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
ENV_PATH=${STAGE2_ENV:-/scratch/zr2245/conda-envs/pmsh-cu126}
LAB=${STAGE2_LAB:-/scratch/zr2245/meshsplatting-original-lossless-v1}
PYTHON=${STAGE2_PYTHON:-$LAB/.venv/bin/python}
if [[ ! -x "$PYTHON" ]]; then PYTHON="$ENV_PATH/bin/python"; fi
SOURCE=${ROOM_SOURCE:-/scratch/zr2245/room-fixed-sharing-0N4OSU/run/original/point_cloud/iteration_30000/point_cloud_state_dict.pt}
SEED=${ROOM_SEED:-/scratch/zr2245/room-delivery-quant-0i2F5s/run/xyz-q18_dc-q8-_luz1ezw/asset.mslb}
DATA=${ROOM_DATA:-/scratch/zr2245/datasets/m360/room}
for required in "$PYTHON" "$SOURCE" "$SEED" "$LAB/upstream/scene/__init__.py"; do
    if [[ ! -f "$required" ]]; then echo "Missing: $required" >&2; exit 2; fi
done
[[ -d "$DATA/images_2" && -d "$DATA/sparse" ]] || { echo "Missing Room dataset: $DATA" >&2; exit 2; }
export CUDA_HOME="$ENV_PATH"
export PATH="$ENV_PATH/bin:$PATH"
export PYTHONPATH="$PKG/renderer:$PKG:$LAB/upstream/submodules/effrdel/src:${PYTHONPATH:-}"
# Conda CUDA installs libcudart under targets/x86_64-linux/lib on Linux.
# LIBRARY_PATH is used at link time; LD_LIBRARY_PATH is used at runtime.
CUDA_LIB_DIRS="$ENV_PATH/targets/x86_64-linux/lib:$ENV_PATH/lib:$ENV_PATH/lib64"
export LIBRARY_PATH="$CUDA_LIB_DIRS:${LIBRARY_PATH:-}"
export LD_LIBRARY_PATH="$CUDA_LIB_DIRS:${LD_LIBRARY_PATH:-}"
export MAX_JOBS=4 OMP_NUM_THREADS=8
unset NVCC_PREPEND_FLAGS NVCC_APPEND_FLAGS
if [[ -x "$ENV_PATH/bin/x86_64-conda-linux-gnu-c++" ]]; then
    export CXX="$ENV_PATH/bin/x86_64-conda-linux-gnu-c++"
    export CC="$ENV_PATH/bin/x86_64-conda-linux-gnu-cc"
else export CXX=g++ CC=gcc; fi
export CUDAHOSTCXX="$CXX"
export TORCH_CUDA_ARCH_LIST
TORCH_CUDA_ARCH_LIST=$("$PYTHON" -c 'import torch; assert torch.cuda.is_available(), "GPU allocation required"; a,b=torch.cuda.get_device_capability(); print(f"{a}.{b}")')
if [[ $# -gt 0 ]]; then OUTPUT=$1; shift; else
    RUN=$(mktemp -d /scratch/zr2245/room-shared-collapse-XXXXXX)
    OUTPUT="$RUN/run"
fi
cd "$PKG"
echo "Interpreter: $PYTHON; source: $SOURCE; seed: $SEED; output: $OUTPUT"
"$PYTHON" verify_package.py
"$PYTHON" -c 'import torch,numpy,pytest,zstandard,meshoptimizer,PIL,lpips; print("Dependencies OK",torch.__version__)'
"$PYTHON" build_cpu.py
if [[ "${STAGE2_ENTRY:-train_collapse_first.py}" == "coarse_once.py" ]]; then "$PYTHON" build_legacy.py; fi
(cd renderer && "$PYTHON" setup.py build_ext --inplace)
"$PYTHON" -m pytest -q test_cpu.py
if [[ "${STAGE2_ENTRY:-train_collapse_first.py}" == "coarse_once.py" ]]; then "$PYTHON" -m pytest -q test_coarse_once.py; fi
mkdir -p "$(dirname -- "$OUTPUT")"
"$PYTHON" check_gradients.py --output "${OUTPUT}.gradient-report.json"
"$PYTHON" -u "${STAGE2_ENTRY:-train_collapse_first.py}" --source "$SOURCE" --seed-asset "$SEED" --dataset "$DATA" --lab "$LAB" --output "$OUTPUT" "$@" \
    2>&1 | tee "${OUTPUT}.log"
