import math
import json
import numpy as np
import torch
from model import SharedMesh,optimizer,render
from algorithm import health,save_json
from geometry_trust import configure,project

def fit(wire,mask,steps,cameras,validation,evaluate,ssim,args,folder,appearance_only=False):
    folder.mkdir(parents=True,exist_ok=True)
    model=SharedMesh(wire);opt=optimizer(model,args.geo_lr,args.dc_lr,args.bank_lr,args.residual_lr)
    if not appearance_only:save_json(folder/'geometry-trust.json',configure(model,mask))
    stop_reason='step budget'
    lrs=[g['lr'] for g in opt.param_groups]
    generator=np.random.default_rng(args.seed)
    reference=model.vertices.detach().clone();x0=model.x.detach().clone()
    appearance0={k:p.detach().clone() for k,p in model.named_parameters() if k in ('bank','residual','rest')}
    if appearance_only:model.x.requires_grad_(False)
    sampled=torch.as_tensor(generator.integers(0,len(model.faces),min(65536,len(model.faces))),device=model.x.device)
    f=model.faces[sampled].long();tri=reference[f];n0=torch.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0],dim=1)
    denominator=n0.square().sum(1).clamp_min(1e-24)
    initial=evaluate(model,validation,include_lpips=False);best_score=initial['loss'];best=model.wire();best_step=0;stale=0
    save_json(folder/'initial-validation.json',initial)
    local_mask=torch.as_tensor(mask,device=model.x.device,dtype=torch.float32) if mask is not None else None
    order=generator.permutation(len(cameras));cursor=0
    for step in range(1,steps+1):
        local=local_mask is not None and step<=args.local_steps
        model.active=local_mask if local else None
        if model.shared:model.bank.requires_grad_(not local);model.residual.requires_grad_(not local)
        for group,lr in zip(opt.param_groups,lrs):group['lr']=lr*(.25+.75*.5*(1+math.cos(math.pi*(step-1)/max(1,steps))))
        if cursor==len(order):order=generator.permutation(len(cameras));cursor=0
        c=cameras[int(order[cursor])];cursor+=1;opt.zero_grad(set_to_none=True)
        image=render(c,model,args.train_factor)['render'].clamp(0,1);gt=c.original_image[:3].to(image.device)
        image_loss=.8*(image-gt).abs().mean()+.2*(1-ssim(image,gt))
        tri=model.vertices[f];normal=torch.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0],dim=1)
        ratio=(normal*n0).sum(1)/denominator
        guard=(.1-ratio).clamp_min(0).square().mean()
        anchor=sum((p-appearance0[k]).square().mean() for k,p in model.named_parameters() if k in appearance0)
        loss=image_loss+.001*guard+args.anchor_weight*anchor+1e-4*(model.x-x0).square().mean()
        if not torch.isfinite(loss):raise FloatingPointError('Nonfinite loss; resume from last committed stage')
        loss.backward()
        gradients={}
        for name,param in model.named_parameters():
            if not param.requires_grad:continue
            if param.grad is None or not torch.isfinite(param.grad).all():raise FloatingPointError('Missing/nonfinite gradient: '+name)
            if step==1 or step%100==0:gradients[name]=float(param.grad.norm())
            torch.nn.utils.clip_grad_norm_([param],1.)
        previous=model.x.detach().clone() if not appearance_only else None
        opt.step()
        if not appearance_only:project(model,previous)
        if step==1 or step%100==0:
            phase=('shared-appearance' if appearance_only else ('local' if local else 'global')+('-shared' if model.shared else '-independent-SH'))
            row=dict(step=step,phase=phase,image_loss=float(image_loss),guard=float(guard),grad_norms=gradients,
                xyz_max_local_altitude_fraction=float(model.x.detach().norm(dim=1).max()),
                xyz_mean_world_displacement=float((model.vertices.detach()-reference).norm(dim=1).mean()),
                geometry_scope='frozen' if appearance_only else 'collapse affected vertices only; never globally unlocked',
                lr={g['tag']:g['lr'] for g in opt.param_groups})
            with (folder/'training.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
            print('Adapt:',row,flush=True)
        if step%args.eval_every==0 or step==steps or step in (25,50,args.local_steps,args.local_steps+25):
            val=evaluate(model,validation,include_lpips=False);geo=health(reference,model.vertices,model.faces)
            healthy=geo['nonfinite_vertices']==0 and geo['new_zero_area_faces']==0 and geo['flipped_fraction']<=args.max_flip_fraction
            if healthy and val['loss']<best_score:
                best_score=val['loss'];best=model.wire();best_step=step
                temp=folder/'best.tmp';torch.save(best,temp);temp.replace(folder/'best.pt')
                stale=0
            else:stale+=1
            save_json(folder/f'validation-{step:05d}.json',dict(metrics=val,geometry=geo,healthy=healthy,best_step=best_step))
            print('Validation',step,'PSNR',val['psnr'],'initial',initial['psnr'],'loss',val['loss'],'healthy',healthy,'flips',geo['flipped_faces'],'best step',best_step,flush=True)
            if not healthy or not math.isfinite(val['psnr']) or val['psnr']<initial['psnr']-.5:
                stop_reason='geometry or catastrophic quality guard; return best validated state'
                print(stop_reason,flush=True);break
            if step>=getattr(args,'min_steps',600) and stale>=getattr(args,'patience',3):break
    save_json(folder/'adaptation.json',dict(steps=step if steps else 0,requested_steps=steps,best_step=best_step,best_validation_loss=best_score,
        stop_reason=stop_reason,optimizer_transition='New Adam per topology transaction; local-altitude projected geometry updates',
        local_steps=min(steps,args.local_steps) if local_mask is not None else 0))
    return best
