"""Independent-SH simplification/recovery first; shared delivery conversion last."""
import argparse,gc,json,tempfile
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import torch
from model import SharedMesh
from algorithm import save_json,importance,simplify,acceptable
from runtime import load_scene,Evaluator,export_asset
from optimize import fit
from preflight import check_original
from sharing_after import convert,exceptions
from codec_benchmark import unpack
from train_stage2 import initial_wire,checkpoint
import local_codec as lc

def detach_state(source):
    keys=('triangles_points','features_dc','features_rest','_triangle_indices','vertex_weight','sigma','active_sh_degree')
    return {k:(source[k].detach().cpu().clone() if isinstance(source[k],torch.Tensor) else source[k]) for k in keys}

def safe_geometry(g,a):
    return not g['nonfinite_vertices'] and not g['new_zero_area_faces'] and g['flipped_fraction']<=a.max_flip_fraction

def assess(wire,evaluate,cameras,**kwargs):
    model=SharedMesh(wire);result=evaluate(model,cameras,**kwargs)
    del model;torch.cuda.empty_cache();return result

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('source','seed-asset','dataset','lab','output'):p.add_argument('--'+name,required=True)
    p.add_argument('--images',default='images_2');p.add_argument('--resume',action='store_true')
    p.add_argument('--steps',type=int,default=1000);p.add_argument('--local-steps',type=int,default=150)
    p.add_argument('--eval-every',type=int,default=250);p.add_argument('--min-steps',type=int,default=500);p.add_argument('--patience',type=int,default=2)
    p.add_argument('--rounds',type=int,default=6);p.add_argument('--batch-fraction',type=float,default=.15)
    p.add_argument('--error-limit',type=float,default=.75);p.add_argument('--max-error-limit',type=float,default=8.)
    p.add_argument('--geo-lr',type=float,default=.005,help='Adam LR in local triangle altitude units');p.add_argument('--dc-lr',type=float,default=.002)
    p.add_argument('--bank-lr',type=float,default=.0001,help='Independent directional SH learning rate during collapse fitting')
    p.add_argument('--residual-lr',type=float,default=.0003);p.add_argument('--anchor-weight',type=float,default=.005)
    p.add_argument('--max-psnr-drop',type=float,default=.25);p.add_argument('--max-ssim-drop',type=float,default=.005)
    p.add_argument('--max-lpips-increase',type=float,default=.01);p.add_argument('--max-view-drop',type=float,default=.5)
    p.add_argument('--max-flip-fraction',type=float,default=1e-4)
    p.add_argument('--train-factor',type=int,default=4);p.add_argument('--eval-factor',type=int,default=4)
    p.add_argument('--score-views',type=int,default=4);p.add_argument('--seed',type=int,default=17)
    p.add_argument('--shared-steps',type=int,default=200);p.add_argument('--dictionary-rounds',type=int,default=2)
    a=p.parse_args()
    if not torch.cuda.is_available():p.error('Allocated CUDA GPU required')
    if not 0<a.batch_fraction<.5 or not 0<a.error_limit<=a.max_error_limit:p.error('Invalid batch controls')
    if min(a.steps,a.rounds,a.eval_every,a.min_steps,a.patience,a.score_views,a.dictionary_rounds,a.train_factor,a.eval_factor)<=0:p.error('Positive controls required')
    if a.shared_steps<0 or a.local_steps<0 or min(a.geo_lr,a.dc_lr,a.bank_lr,a.residual_lr)<=0:p.error('Invalid optimization controls')
    if min(a.max_psnr_drop,a.max_ssim_drop,a.max_lpips_increase,a.max_view_drop,a.max_flip_fraction)<0:p.error('Nonnegative tolerances required')
    from stage2_triangle_rasterization import _C
    assert _C.shared_stage2_backward_revision()==2
    torch.set_num_threads(8);torch.manual_seed(a.seed);np.random.seed(a.seed)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    out=Path(a.output).resolve();root=Path(__file__).parent
    fingerprint=dict(version=2,config={k:v for k,v in vars(a).items() if k!='resume'},source=lc.digest(a.source),seed=lc.digest(a.seed_asset),
        manifest=lc.digest(root/'MANIFEST.json'),renderer=lc.digest(_C.__file__))
    if out.exists():
        if not a.resume or json.loads((out/'experiment.json').read_text())!=fingerprint:raise ValueError('Use a new output for v2 or identical v2 --resume')
    else:out.mkdir(parents=True);save_json(out/'experiment.json',fingerprint)
    train,val,test,ssim,official=load_scene(a,return_mesh=True);evaluate=Evaluator(ssim,a.eval_factor)
    save_json(out/'splits.json',dict(train=[c.image_name for c in train],validation=[c.image_name for c in val],test=[c.image_name for c in test],
        scope='Stage2-held-out validation; original reconstruction saw validation. Test excluded from choices.'))
    source=torch.load(a.source,map_location='cpu',weights_only=False);seed=unpack(a.seed_asset)
    initial_wire(source,seed)  # source-order identity check only; does not train/render shared
    wire=detach_state(source);wire['opacity_floor']=float(official.opacity_floor);del source
    report=check_original(wire,official,val[:3],a.eval_factor);save_json(out/'original-forward-check.json',report)
    if not report['passed']:raise RuntimeError('Original forward mismatch; stopped before optimization. Inspect original-forward-check.json')
    del official;gc.collect();torch.cuda.empty_cache()
    state_path=out/'run-state-v2.json'
    if state_path.exists():state=json.loads(state_path.read_text());del wire
    else:
        reference=assess(wire,evaluate,val)
        save_json(out/'original-validation.json',reference)
        cp=out/'original-independent.pt';checkpoint(cp,wire)
        state=dict(next_round=0,limit=a.error_limit,fraction=a.batch_fraction,reference=reference,
            accepted=[dict(checkpoint=str(cp),vertices=len(wire['triangles_points']),faces=len(wire['_triangle_indices']),validation=reference)],trials=[])
        save_json(state_path,state);del wire
    reference=state['reference']
    # Reserve part of the total degradation allowance for final shared encoding.
    collapse_tolerance=SimpleNamespace(**vars(a))
    for key in ('max_psnr_drop','max_ssim_drop','max_lpips_increase','max_view_drop'):
        setattr(collapse_tolerance,key,getattr(a,key)*.5)
    for ri in range(state['next_round'],a.rounds):
        if state.get('stop'):break
        previous=state['accepted'][-1];wire=torch.load(previous['checkpoint'],map_location='cpu',weights_only=False)
        folder=Path(tempfile.mkdtemp(prefix=f'collapse-{ri:02d}-',dir=out))
        model=SharedMesh(wire);indices=np.linspace(0,len(train)-1,min(a.score_views,len(train)),dtype=int)
        priority,score=importance(model,[train[i] for i in indices],a.train_factor,model.x.new_zeros(3));del model;torch.cuda.empty_cache()
        candidate,mask,build=simplify(wire,priority,state['limit'],state['fraction']);del priority,wire;gc.collect()
        save_json(folder/'build.json',dict(build=build,scoring=score));trial=dict(round=ri,folder=str(folder),build=build,accepted=False)
        if build['merges']==0:
            if state['limit']>=a.max_error_limit:state['stop']=True
            state['limit']=min(a.max_error_limit,state['limit']*1.5)
            trial['reason']='No collapse under current error bound';del candidate,mask
        else:
            fitted=fit(candidate,mask,a.steps,train,val,evaluate,ssim,a,folder/'fit');del candidate,mask
            metrics=assess(fitted,evaluate,val);quality=acceptable(metrics,reference,collapse_tolerance)
            trial.update(validation=metrics,accepted=quality and len(fitted['_triangle_indices'])<previous['faces'])
            if trial['accepted']:
                cp=folder/'independent.pt';checkpoint(cp,fitted)
                state['accepted'].append(dict(checkpoint=str(cp),vertices=len(fitted['triangles_points']),faces=len(fitted['_triangle_indices']),validation=metrics))
                state['limit']=min(a.max_error_limit,state['limit']*1.25)
            else:
                state['fraction']*=.5;state['limit']=max(.1,state['limit']*.8)
                if state['fraction']<.02:state['stop']=True
            del fitted
        state['trials'].append(trial);state['next_round']=ri+1
        save_json(folder/'trial.json',trial);save_json(state_path,state)
        print('Independent collapse round:',ri,'accepted:',trial['accepted'],'retained faces:',state['accepted'][-1]['faces'],flush=True)
    final=state['accepted'][-1]
    wire=torch.load(final['checkpoint'],map_location='cpu',weights_only=False)
    # Conversion happens ONCE, after the independent collapse/recovery loop.
    folder=Path(tempfile.mkdtemp(prefix='shared-final-',dir=out))
    shared=convert(wire,seed,a.dictionary_rounds);del seed;torch.cuda.empty_cache()
    if a.shared_steps:
        shared=fit(shared,None,a.shared_steps,train,val,evaluate,ssim,a,folder/'fit',appearance_only=True)
    shared_metrics=assess(shared,evaluate,val)
    save_json(folder/'shared-validation.json',shared_metrics)
    delivery_trials=[];chosen=None
    # Allow extra transmitted coefficients instead of accepting large quality loss.
    for fraction in (0.,.01,.05,.2,1.):
        candidate=shared if fraction==0 else exceptions(shared,wire,fraction)
        metric=shared_metrics if fraction==0 else assess(candidate,evaluate,val)
        row=dict(exception_fraction=fraction,unquantized_validation=metric)
        if not acceptable(metric,reference,a):
            row['accepted']=False;row['reason']='Shared representation exceeds fixed original quality tolerance'
            delivery_trials.append(row);continue
        for xyz,dc in (('q18','q8'),('q18','f32'),('f32','f32')):
            encoded_folder=folder/f'exception-{fraction:g}-{xyz}-{dc}'
            decoded,codec=export_asset(candidate,encoded_folder,xyz,dc)
            metrics=assess(decoded,evaluate,val);del decoded
            ok=acceptable(metrics,reference,a) and safe_geometry(codec['quantization_geometry'],a)
            item=dict(exception_fraction=fraction,xyz=xyz,dc=dc,validation=metrics,delivery=codec,accepted=ok)
            delivery_trials.append(item)
            if ok:chosen=item;break
        if chosen is not None:break
    save_json(folder/'delivery-trials.json',delivery_trials)
    independent_test=assess(wire,evaluate,test,png_dir=out/'png-independent-final')
    results=dict(version=2,reference_validation=reference,collapse_stages=state['accepted'],collapse_trials=state['trials'],
        simplification_achieved=final['faces']<state['accepted'][0]['faces'],
        final_independent_test=independent_test,delivery_trials=delivery_trials,
        geometry=dict(vertices=final['vertices'],faces=final['faces']),
        scope='Independent SH collapse/recovery; shared conversion only after simplification; fixed original validation quality reference')
    if chosen is not None:
        import topology as tc
        from delivery import restore
        with tempfile.TemporaryDirectory(dir=out) as temp:decoded=restore(tc.read_asset(chosen['delivery']['asset'],out/'native',Path(temp)))
        results['delivery']=chosen;results['delivery_test']=assess(decoded,evaluate,test,png_dir=out/'png-delivery-final')
        results['status']='quality_accepted';del decoded
    else:results['status']='no_delivery_meets_quality_tolerance'
    save_json(out/'stage2-summary.json',results)
    print('COMPLETE',results['status'],out/'stage2-summary.json',flush=True)

if __name__=='__main__':main()
