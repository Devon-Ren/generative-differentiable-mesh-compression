import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for name,expected in manifest['sha256'].items():
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    if name=='submit_room.sh' and actual!=expected:
        print('Local scheduler configuration accepted:',name)
        continue
    if actual!=expected:raise RuntimeError('Package changed: '+name)
print('Package verified:',len(manifest['sha256']),'files')
