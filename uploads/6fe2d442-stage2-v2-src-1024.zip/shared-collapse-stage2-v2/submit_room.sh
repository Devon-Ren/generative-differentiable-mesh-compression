#!/usr/bin/env bash
#SBATCH --account=torch_pr_38_general
#SBATCH --job-name=room-collapse
#SBATCH --gres=gpu:1
#SBATCH --constraint=l40s
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=48G
#SBATCH --time=02:00:00
#SBATCH --output=/scratch/zr2245/room-collapse-%j.out
#SBATCH --error=/scratch/zr2245/room-collapse-%j.err
set -eo pipefail
cd /scratch/zr2245/shared-collapse-stage2-v1
bash run_room.sh "$@"
