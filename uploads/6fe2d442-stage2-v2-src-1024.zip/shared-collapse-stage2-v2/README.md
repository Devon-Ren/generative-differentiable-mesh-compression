# Collapse first, shared appearance last — Stage 2 v2

Start with the fully trained original independent-SH asset; simplify and recover its quality first. Convert to shared SH only after the independent simplification loop finishes. This replaces v1's shared-first workflow.

## Fixed defects

- Original MeshSplatting `load_parameters()` sets `opacity_floor=0.999`. The v1 wrapper incorrectly used plain sigmoid. v2 uses `floor+(1-floor)*sigmoid(weight)` and saves the floor in delivery metadata. The approximately 15 dB v1 result is not a valid shared-SH baseline.
- Original checkpoint tensors can retain `requires_grad=True`. CPU simplification explicitly detaches tensors; trainable rendering parameters remain differentiable.
- Step-zero geometry is now bit-identical to input FP32 coordinates: optimize zero-initialized displacement from reference positions.
- Remove the 800-step dense-shared warmup and acceptance relative to that degraded reference.
- Preserve the explicit Conda CUDA library paths. CUDA source is unchanged from revision 2, so compiled objects can be reused.

## Sequence

1. Compare original and corrected renderers on three identical validation views using independent SH and 4x supersampling. Write `original-forward-check.json`; mismatch stops before optimization.
2. Evaluate original independent quality on validation cameras. Freeze that reference. No dense fitting.
3. Score and batch-collapse using geometric/independent-SH bounds plus training visibility/residuals. The 15% face-reduction cap is not a required target. No new points.
4. Optimize surviving XYZ/DC/independent SH for up to 1,000 steps: 150 local steps then global steps. Validate every 250; two non-improving checks after at least 500 steps permit early stopping. Log geometry status and initial/best metrics.
5. Accept only within half of final quality tolerances, reserving capacity for sharing. Rejected batches roll back. Up to six rounds; reduction is measured, not guaranteed.
6. After the loop, convert the last accepted mesh to primary+residual dictionaries initialized from the existing seed. Refit assignments against adapted independent coefficients. Optionally fit appearance for 200 steps with geometry frozen.
7. Evaluate actual encoded/decoded quality. When dictionary capacity is insufficient, transmit explicit per-vertex directional residual codes at 1%, 5%, 20%, then 100% coverage. Try FP32 DC/XYZ if quantization prevents passing. Every added field counts toward size. This quality fallback does not promise the earlier 41 MB result.
8. Render all test views for the final independent and delivered meshes; save GT/render PNGs and PSNR/SSIM/LPIPS. Test views never select candidates. Intermediate accepted checkpoints/validation reports remain available.

Final default maximum validation degradation from the original independent asset: **0.25 dB PSNR, 0.005 SSIM, 0.01 LPIPS, 0.5 dB worst-view PSNR**. Collapse uses half these allowances. If no delivered asset passes, report failure. Validation acceptance does not guarantee test-view performance.

Deliveries are standalone meshes. Exception/precision search takes the first passing configuration; it does not prove minimum rate. No progressive-patch construction in this experiment.

## Apply and run

Upload `meshsplatting-collapse-first-v2.zip` to `/scratch/zr2245/`:

```bash
cd /scratch/zr2245
unzip -o meshsplatting-collapse-first-v2.zip -d .
cd shared-collapse-stage2-v1
sbatch submit_room.sh
```

Directory name remains `shared-collapse-stage2-v1` to reuse the compiled extension. Entry point is now `train_collapse_first.py`; old direct `train_stage2.py` execution is disabled. Start a **new v2 run**, not a v1 resume. Existing original assets are reused; no Stage1 retraining.

Defaults use the original Room checkpoint and original-order approximately 79.45 MB shared seed. The seed supplies dictionary initialization and identity checks only. Override via `ROOM_SOURCE`, `ROOM_SEED`, `ROOM_DATA`, `STAGE2_LAB`, `STAGE2_PYTHON`.

Launcher requests one L40S, 48 GB CPU RAM, four hours. It verifies package/files, builds isolated extensions, runs CPU/GPU tests, then performs the real-scene forward comparison. No original-renderer replacement or Conda activation hooks.

Logs: `/scratch/zr2245/room-collapse-JOBID.out` and `.err`; printed `output:` identifies `run.log` and result directory. Final report: `run/stage2-summary.json`; PNGs: `png-independent-final/`, `png-delivery-final/`. `run-state-v2.json` records committed independent batches. Interrupted shared conversion may repeat.

Identical v2 continuation:

```bash
sbatch submit_room.sh /scratch/zr2245/room-shared-collapse-XXXXXX/run --resume
```

## Optimization and verification

Normalized displacement LR 5e-5, DC 0.002, independent SH 0.0001; cosine decay to 25% and gradient norm clipping at 1 per parameter. Fitting/evaluation both default to 4x supersampling. Time reductions come from removing dense warmup, skipping intermediate LPIPS, deferring compression until the end and early stopping. Full-scene runtime is not locally validated.

CPU tests cover independent/shared gradients, detached checkpoint data, step-zero coordinates, loaded opacity semantics, attribute transfer, and quantized/FP32 codec roundtrips. Mandatory GPU checks test numerical derivatives and actual XYZ/color updates; scene-level forward equivalence is checked separately.

Topology and group assignments are discrete and fixed during fitting. RGB gradients reach projection, barycentrics, opacity support, viewing direction and coefficients. Sigma/weights are fixed. No derivative through collapse/entropy coding is claimed. Geometry checks cover finite coordinates, area and relative orientation, not arbitrary self-intersections/CAD validity.

Upstream licenses remain in `renderer/`; research/noncommercial restrictions apply. GPU and full Room execution must be verified on HPC.
