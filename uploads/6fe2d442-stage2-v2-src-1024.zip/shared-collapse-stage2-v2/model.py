"""Continuous optimization in the SAME shared representation as delivery.
Indices/topology are discrete constants during each optimization transaction.
"""
from pathlib import Path
import sys
import numpy as np
import torch
from torch import nn
sys.path.insert(0,str(Path(__file__).parent/'codec'))
from appearance import expand_wire
from sh_utils import eval_sh

class SharedMesh(nn.Module):
    def __init__(self,wire,device='cuda'):
        super().__init__()
        self.shared='app_schema' in wire
        if self.shared and (wire['app_schema']!=2 or np.asarray(wire['app_gain']).size):raise ValueError('Requires residual dictionaries, no gain')
        v=wire['triangles_points'].detach().to(device).float()
        scale=(v.max(0).values-v.min(0).values).norm()
        if not torch.isfinite(scale) or scale<=0:raise ValueError('Invalid extent')
        self.register_buffer('reference_vertices',v.clone());self.register_buffer('scale',scale)
        # Zero displacement preserves every input FP32 coordinate at step zero.
        self.x=nn.Parameter(torch.zeros_like(v))
        self.dc=nn.Parameter(wire['features_dc'].detach().to(device).float().clone())
        if self.shared:
            self.bank=nn.Parameter(torch.as_tensor(wire['app_bank'],device=device).clone())
            self.residual=nn.Parameter(torch.as_tensor(wire['app_residual_bank'],device=device).clone())
            n=len(v);rows=np.asarray(wire['app_rows']).astype(np.int64)
            if not np.array_equal(rows,np.arange(n)):raise ValueError('Requires full residual coverage')
            self.register_buffer('z',torch.as_tensor(wire['app_mapping'].astype(np.int64),device=device))
            self.register_buffer('u',torch.as_tensor(wire['app_residual_mapping'].astype(np.int64),device=device))
        else:self.rest=nn.Parameter(wire['features_rest'].detach().to(device).float().clone())
        self.register_buffer('faces',wire['_triangle_indices'].to(device).int().contiguous())
        self.register_buffer('weights',wire['vertex_weight'].detach().to(device).float().clone())
        self.sigma=wire['sigma'];self.degree=int(wire['active_sh_degree'])
        self.opacity_floor=float(wire.get('opacity_floor',.999))
        self.active=None;self.geometry_active=None
        self.x.register_hook(lambda g:g*self.geometry_active[:,None] if self.geometry_active is not None else (g if self.active is None else g*self.active[:,None]))
        self.dc.register_hook(lambda g:g if self.active is None else g*self.active[:,None,None])
        if not self.shared:self.rest.register_hook(lambda g:g if self.active is None else g*self.active[:,None,None])
    @property
    def vertices(self):return self.reference_vertices+self.scale*self.x
    @property
    def opacity(self):return self.opacity_floor+(1-self.opacity_floor)*self.weights.sigmoid()
    def colors(self,center):
        v=self.vertices;direction=v-center[None]
        direction=direction/direction.norm(dim=-1,keepdim=True).clamp_min(1e-12)
        rest=self.bank[self.z]+self.residual[self.u] if self.shared else self.rest
        sh=torch.cat((self.dc,rest),dim=1).transpose(1,2)
        return (eval_sh(self.degree,sh,direction)+.5).clamp_min(0).contiguous()
    @torch.no_grad()
    def wire(self):
        if not self.shared:
            return dict(triangles_points=self.vertices.detach().cpu().clone(),features_dc=self.dc.detach().cpu().clone(),
                features_rest=self.rest.detach().cpu().clone(),_triangle_indices=self.faces.detach().cpu().clone(),
                vertex_weight=self.weights.detach().cpu().clone(),sigma=self.sigma,active_sh_degree=self.degree,opacity_floor=self.opacity_floor)
        z=self.z.cpu().numpy();u=self.u.cpu().numpy()
        bz,z=np.unique(z,return_inverse=True);ru,u=np.unique(u,return_inverse=True)
        # Prune unused dictionary entries only at transaction boundaries.
        return dict(triangles_points=self.vertices.detach().cpu().contiguous(),features_dc=self.dc.detach().cpu().contiguous(),
            _triangle_indices=self.faces.cpu().contiguous(),vertex_weight=self.weights.cpu().contiguous(),sigma=self.sigma,active_sh_degree=self.degree,opacity_floor=self.opacity_floor,
            app_schema=2,app_bank=self.bank.detach().cpu().numpy()[bz],app_mapping=z.astype(np.uint16 if len(bz)<=65536 else np.uint32),
            app_gain=np.empty((0,3),np.float32),app_rows=np.arange(len(z),dtype=np.uint32),app_correction=np.empty((0,15,3),np.float32),
            app_residual_bank=self.residual.detach().cpu().numpy()[ru],app_residual_mapping=u.astype(np.uint16 if len(ru)<=65536 else np.uint32))

def project(vertices,camera):
    hom=torch.cat((vertices,torch.ones_like(vertices[:,:1])),1)@camera.full_proj_transform
    p=hom[:,:2]/(hom[:,3:4]+1e-7)
    size=vertices.new_tensor([camera.image_width,camera.image_height])
    return ((p+1)*size-1)*.5,hom[:,3]

def render(camera,model,factor=2,background=None,visibility=False):
    import math
    from stage2_triangle_rasterization import TriangleRasterizationSettings,TriangleRasterizer
    h,w=camera.image_height,camera.image_width
    if background is None:background=model.x.new_zeros(3)
    settings=TriangleRasterizationSettings(image_height=h*factor,image_width=w*factor,tanfovx=math.tan(camera.FoVx*.5),
        tanfovy=math.tan(camera.FoVy*.5),bg=background,scale_modifier=1.,viewmatrix=camera.world_view_transform,
        projmatrix=camera.full_proj_transform,sh_degree=model.degree,campos=camera.camera_center,prefiltered=False,debug=False)
    sigma=math.exp(float(model.sigma))
    image,_,_,_,_,seen=TriangleRasterizer(settings)(vertices=model.vertices.contiguous(),triangles_indices=model.faces,
        vertex_weights=model.opacity.reshape(-1).contiguous(),sigma=sigma,shs=None,
        colors_precomp=model.colors(camera.camera_center),scaling=torch.zeros(len(model.faces),device=model.x.device))
    image=torch.nn.functional.interpolate(image[None],size=(h,w),mode='area')[0]
    result={'render':image}
    if visibility:
        visible=torch.zeros(len(model.x),device=model.x.device,dtype=torch.bool)
        visible[model.faces[seen.reshape(-1)>0].long().reshape(-1)]=True
        result['visible']=visible
    return result

def subset(wire,ids,faces):
    ids=np.asarray(ids,dtype=np.int64);n=len(ids);result=dict(wire)
    for k in ('triangles_points','features_dc','vertex_weight'):result[k]=wire[k].detach().cpu()[torch.from_numpy(ids)].clone()
    result['_triangle_indices']=torch.as_tensor(np.asarray(faces),dtype=torch.int32).clone()
    if 'features_rest' in wire:
        result['features_rest']=wire['features_rest'].detach().cpu()[torch.from_numpy(ids)].clone()
        return result
    result['app_mapping']=wire['app_mapping'][ids].copy()
    if not np.array_equal(wire['app_rows'],np.arange(len(wire['app_mapping']))):raise ValueError('Coverage')
    result['app_rows']=np.arange(n,dtype=np.uint32);result['app_residual_mapping']=wire['app_residual_mapping'][ids].copy()
    return result

def optimizer(model,geo_lr=1e-4,dc_lr=.003,bank_lr=.00015,residual_lr=.0008):
    groups=[{'params':[model.x],'lr':geo_lr,'tag':'xyz'}, {'params':[model.dc],'lr':dc_lr,'tag':'dc'}]
    if model.shared:groups.extend([{'params':[model.bank],'lr':bank_lr,'tag':'bank'},{'params':[model.residual],'lr':residual_lr,'tag':'residual'}])
    else:groups.append({'params':[model.rest],'lr':bank_lr,'tag':'independent_sh'})
    return torch.optim.Adam(groups,eps=1e-8)
