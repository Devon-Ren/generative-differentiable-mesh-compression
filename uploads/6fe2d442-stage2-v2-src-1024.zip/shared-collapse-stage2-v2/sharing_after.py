"""Convert an already-adapted independent mesh; never used during collapse."""
import numpy as np
import torch
from model import SharedMesh
from appearance import assign,expand_wire

@torch.no_grad()
def convert(wire,seed,rounds=2):
    target=wire['features_rest'].detach().cuda().float()
    b=torch.as_tensor(seed['app_bank'],device='cuda').clone()
    r=torch.as_tensor(seed['app_residual_bank'],device='cuda').clone()
    def refine(x,bank):
        for _ in range(rounds):
            ids,_=assign(x,bank)
            sums=torch.zeros_like(bank);sums.index_add_(0,ids,x)
            counts=torch.bincount(ids,minlength=len(bank));used=counts>0
            bank[used]=sums[used]/counts[used,None,None]
        ids,_=assign(x,bank);return bank,ids
    b,z=refine(target,b);r,u=refine(target-b[z],r)
    print('Shared conversion: independent fitting complete; dictionaries',len(b),len(r),flush=True)
    result={k:v for k,v in wire.items() if k!='features_rest'}
    result.update(app_schema=2,app_bank=b.cpu().numpy(),app_mapping=z.cpu().numpy().astype(np.uint32),
        app_residual_bank=r.cpu().numpy(),app_residual_mapping=u.cpu().numpy().astype(np.uint32),
        app_gain=np.empty((0,3),np.float32),app_correction=np.empty((0,15,3),np.float32),app_rows=np.arange(len(z),dtype=np.uint32))
    # Compact unused dictionary entries and label integer widths once.
    return SharedMesh(result).wire()

def exceptions(shared,independent,fraction):
    """Restore difficult vertices with explicit FP32 residual codes, cost counted.

    Full coverage approaches independent SH up to FP32 subtraction/addition.
    This is a quality fallback, not a promise of the previous 41 MB rate.
    """
    target=independent['features_rest'].detach().cpu().numpy()
    predicted=expand_wire(shared);scores=np.square(target-predicted).sum((1,2))
    count=min(len(target),max(0,int(np.ceil(len(target)*fraction))))
    ids=np.argsort(-scores,kind='stable')[:count]
    result=dict(shared);bank=shared['app_residual_bank'];mapping=shared['app_residual_mapping'].astype(np.uint32).copy()
    exact=target[ids]-shared['app_bank'][shared['app_mapping'][ids].astype(np.int64)]
    result['app_residual_bank']=np.concatenate((bank,exact),0)
    mapping[ids]=np.arange(len(bank),len(bank)+count,dtype=np.uint32)
    result['app_residual_mapping']=mapping
    if fraction==1.:result['features_dc']=independent['features_dc'].detach().cpu().clone()
    return result
