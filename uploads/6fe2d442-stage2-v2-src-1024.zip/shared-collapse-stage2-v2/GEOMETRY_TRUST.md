# Geometry adaptation correction

The reported Room run passes the original forward-render check and starts collapse
candidates near 30.69 dB. Global geometry updates subsequently cause millions of
orientation reversals and 13–14 dB validation. The accepted best-step-zero state
is the pre-adaptation candidate, not the damaged optimization endpoint.

Geometry now uses v = v_reference + h*x, where h is each vertex's minimum incident
triangle altitude. Projected Adam limits each step to 0.01 altitude and total
displacement to 0.05 altitude per collapse transaction. Geometry outside the
affected mask remains fixed; appearance may become global. Default geometry LR
is 0.005 in these NEW units, not scene-diagonal units. Projection is a post-step
constraint, not a differentiable topology operation. Image gradients still reach
geometry through the fixed diagonal scale h, and appearance through SH evaluation.

For nondegenerate triangles in real arithmetic, if each vertex moves at most eta
times the minimum altitude, the relative cross-product perturbation is bounded
by 4*eta + 4*eta^2. At eta=0.05 this is below one. Floating-point behavior remains
subject to full geometry checks. This is not a self-intersection or manifoldness
guarantee, and successive collapse transactions have separate references.

Early validation at steps 25, 50, local-phase end and 25 steps later terminates
adaptation on unhealthy geometry or >0.5 dB loss from its initial candidate.
Existing final acceptance tolerances are unchanged. The best validated state is
returned. No quality improvement or target reduction ratio is guaranteed.

CPU tests include thin triangles under oversized updates, permanent geometry
masking and gradient propagation. CUDA update smoke checks now use the same
local coordinates and projection. Full Room GPU validation must run on HPC.
Start a fresh Stage 2 output; the original source asset requires no retraining.
