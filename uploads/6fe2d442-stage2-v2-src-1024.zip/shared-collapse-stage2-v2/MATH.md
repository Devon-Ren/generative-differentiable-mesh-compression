# Mathematical scope and implementation contracts

## Shared appearance and gradients

During collapse/recovery, s_i is an independent trainable 15x3 tensor per vertex. After that loop, shared conversion uses fixed integer assignments z_i,u_i:

    s_i = B[z_i] + R[u_i]                 # 15 x 3 FP32 directional coefficients
    d_i = (v_i-c) / ||v_i-c||
    color_i = max(0, 0.5 + Y_0 DC_i + sum_{j=1}^{15} Y_j(d_i) s_ij)
    v_i = reference_vertex_i + scene_diagonal * displacement_i

DC has shape N x 1 x 3. After conversion, B and R replace the independent directional tensors. Gathers are differentiable with respect to their values, not their integer indices:

    dL/dB[k] = sum_{i:z_i=k} dL/ds_i
    dL/dR[k] = sum_{i:u_i=k} dL/ds_i

The direction path contributes `(I-dd^T)/||v-c||` to dcolor/dv, in addition to rasterization derivatives. PyTorch implements this path without detach. `dL/dx = scene_diagonal * dL/dv`. The only clamp on the norm is at 1e-12; ordinary visible vertices are away from this singularity. RGB lower clamping has its usual zero/subgradient behavior.

Image loss is `0.8*mean(abs(I-GT)) + 0.2*(1-SSIM(I,GT))`. During simplification recovery, XYZ, DC and independent SH are Adam parameters, with local masks first and global updates later. After shared conversion, geometry is frozen and DC/B/R can adapt. Regularizers are sampled signed-area preservation, coefficient anchoring and small normalized displacement. Nonfinite gradients fail fast.

The original final-checkpoint loader uses `opacity_i = 0.999 + 0.001*sigmoid(saved_weight_i)`. v2 matches this exactly and stores the floor as metadata. Plain sigmoid was a v1 forward mismatch; finite gradient checks alone could not detect that asset-semantics error. Scene-level comparison against the original renderer now runs before training. Displacements initialize to zero, so initial geometry has no normalization roundoff.

## Corrected raster backward

For one covered pixel, outward signed edge distances are negative:

    phi = max_k distance_k(pixel)
    r = abs(cross(B-A,C-A)) / (|B-A| + |C-B| + |A-C|)
    C = (-phi/r)^sigma
    alpha = min(0.999, min_vertex_weight * C)

Away from active-edge and saturation boundaries:

    dC/dphi = sigma*C/phi
    dC/dr   = -sigma*C/r
    dr      = (sign(area)*darea - r*dperimeter) / perimeter

Backward now includes the projected inradius derivative, which was missing in the inherited implementation. Forward/backward use the same 0.999 alpha cap; saturated alpha has zero derivative but color-interpolation gradients still flow. One active max-edge subgradient is used at ties. Earlier projection quotient, pixel/NDC scale, shared-vertex atomic accumulation and barycentric fixes are preserved. An unused face-indexed color read in backward was removed (colors are vertex-indexed).

This is **piecewise differentiability**. Visibility, coverage, depth sorting, min/max switches and topology have discontinuities. We do not claim a globally differentiable reconstruction/simplification program, and do not differentiate entropy coding. Tests deliberately stay inside a smooth rasterization region for numerical comparisons. CUDA floating point/atomics need not reproduce bitwise-identical gradients across runs.

`check_gradients.py` compares real CUDA XYZ/color derivatives with an independent PyTorch area/perimeter reference and central differences of the CUDA forward. It tests actual updates for both independent and shared appearance on a shared-vertex mesh. CPU `gradcheck` covers the analytic reference including SH directions and shared gathers. Auxiliary normal/depth gradients are outside the training/test contract.

## Batch collapse score

Within each batch, initialize every vertex cluster's geometric and appearance radii to zero. In scene-normalized coordinates, collapsing u into surviving endpoint v has bounds:

    rho'_v = max(rho_v, rho_u + ||x_u-x_v||)
    eta'_v = max(eta_v, eta_u + ||a_u-a_v||)
    score = max(importance_u,importance_v) * max(rho'_v / median_edge, eta'_v)

`a_i` concatenates all 16 RGB SH coefficients scaled by `sqrt(16/(4*pi))/0.15`, and opacity scaled by `1/0.15`. The SH factor is a conservative degree-3 directional-response bound, not measured photometric distortion. Orphan vertices consumed by a legal operation also enter the radius and importance bounds. Priority increases for high training-image residuals; unseen vertices receive protection of 2.0. The queue checks the full updated bound before commit.

Operations above the error limit are not accepted. The face-fraction cap stops a batch to allow recovery; a final individual operation can slightly cross the cap. Legal operations reject degeneracy/large normal change/component erasure but permit topology changes and remove duplicate faces created by a merge. Input duplicate or numerically degenerate faces fail with diagnostics; there is no silent input repair. Each new batch recomputes bounds on the adapted mesh. Therefore only image validation against the fixed dense reference controls cumulative visual drift.

## Selection, bytes, and experimental controls

Fitting/visibility scoring and Stage2 validation are disjoint subsets of upstream training cameras. Original reconstruction may have seen both: this is not a claim of fully unseen reconstruction validation. Original test cameras never choose operations or checkpoints.

The final acceptance gate evaluates the actual decoded quantized/reordered asset. Costs include every transmitted field/header in `asset.mslb`; no source-order permutation is transmitted. Topology, per-vertex attributes and sparse/dictionary maps are reordered consistently. Semantic array checks are necessary but not claimed to ensure bit-identical CUDA rendering; measured image metrics determine acceptance.

FP32 independent master parameters continue between batches. At final shared export, XYZ18/DC8 is tried first, followed by FP32 precision if needed. Additional residual codes restore difficult vertices when the shared banks alone exceed quality tolerances; their bytes are included. Final independent and delivered meshes are tested on all test views. Intermediate accepted checkpoints have validation reports. Smaller bytes/faces do not by themselves prove faster rendering; GPU device time is reported separately.
