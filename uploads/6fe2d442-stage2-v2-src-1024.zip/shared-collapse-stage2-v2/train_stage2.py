"""Transactional simplification + adaptation in final shared-SH representation."""
import argparse
import gc
import json
from pathlib import Path
import tempfile
import numpy as np
import torch
from model import SharedMesh
from algorithm import save_json,importance,simplify,acceptable
from runtime import load_scene,Evaluator,export_asset
from optimize import fit
from codec_benchmark import unpack,equal
from delivery import prepare
import local_codec as lc

def initial_wire(source,seed):
    if seed.get('app_schema')!=2 or seed.get('delivery_schema')!=1:raise ValueError('Use original-order quantized shared seed, not reordered topology packet')
    # Exact source-order correspondence, NOT just matching vertex counts.
    inference={k:source[k] for k in ('triangles_points','features_dc','_triangle_indices','vertex_weight','sigma','active_sh_degree')}
    quant=prepare(inference,'q18','q8',True)
    equal(quant,{k:seed[k] for k in quant})
    result={k:(v.detach().cpu().clone() if isinstance(v,torch.Tensor) else v) for k,v in inference.items()}
    result.update({k:v for k,v in seed.items() if k.startswith('app_')})
    return result

def checkpoint(path,wire):
    temp=path.with_suffix('.tmp');torch.save(wire,temp);temp.replace(path)

def main():
    p=argparse.ArgumentParser()
    for name in ('source','seed-asset','dataset','lab','output'):p.add_argument('--'+name,required=True)
    p.add_argument('--images',default='images_2');p.add_argument('--resume',action='store_true')
    p.add_argument('--warmup-steps',type=int,default=800);p.add_argument('--steps',type=int,default=1200)
    p.add_argument('--local-steps',type=int,default=200);p.add_argument('--eval-every',type=int,default=200)
    p.add_argument('--rounds',type=int,default=8);p.add_argument('--batch-fraction',type=float,default=.15)
    p.add_argument('--error-limit',type=float,default=.75);p.add_argument('--max-error-limit',type=float,default=8.)
    p.add_argument('--geo-lr',type=float,default=1e-4);p.add_argument('--dc-lr',type=float,default=.003)
    p.add_argument('--bank-lr',type=float,default=.00015);p.add_argument('--residual-lr',type=float,default=.0008)
    p.add_argument('--anchor-weight',type=float,default=.01)
    p.add_argument('--max-psnr-drop',type=float,default=.25);p.add_argument('--max-ssim-drop',type=float,default=.008)
    p.add_argument('--max-lpips-increase',type=float,default=.015);p.add_argument('--max-view-drop',type=float,default=1.)
    p.add_argument('--max-flip-fraction',type=float,default=1e-4)
    p.add_argument('--train-factor',type=int,default=2);p.add_argument('--eval-factor',type=int,default=4)
    p.add_argument('--score-views',type=int,default=8);p.add_argument('--seed',type=int,default=17)
    a=p.parse_args()
    if not torch.cuda.is_available():p.error('CUDA GPU required')
    if not (0<a.batch_fraction<.5 and 0<a.error_limit<=a.max_error_limit):p.error('Bad simplification controls')
    if min(a.steps,a.warmup_steps,a.eval_every,a.score_views,a.train_factor,a.eval_factor,a.rounds)<=0:p.error('Positive step counts/factors required')
    if min(a.geo_lr,a.dc_lr,a.bank_lr,a.residual_lr)<=0 or min(a.max_psnr_drop,a.max_ssim_drop,a.max_lpips_increase,a.max_view_drop,a.max_flip_fraction)<0:p.error('Invalid LR/tolerance')
    from stage2_triangle_rasterization import _C
    if not hasattr(_C,'shared_stage2_backward_revision') or _C.shared_stage2_backward_revision()!=2:raise RuntimeError('Build isolated Stage2 renderer first')
    torch.set_num_threads(8);torch.manual_seed(a.seed);np.random.seed(a.seed)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    out=Path(a.output).resolve();root=Path(__file__).parent
    fingerprint=dict(config={k:v for k,v in vars(a).items() if k!='resume'},source_sha256=lc.digest(a.source),seed_sha256=lc.digest(a.seed_asset),
        code={str(k.relative_to(root)):lc.digest(k) for k in root.rglob('*') if k.is_file() and k.suffix in ('.py','.cpp','.cu','.h','.hpp') and 'build' not in k.parts},renderer=lc.digest(_C.__file__))
    if out.exists():
        if not a.resume or json.loads((out/'experiment.json').read_text())!=fingerprint:raise ValueError('Use new output or identical --resume')
    else:out.mkdir(parents=True);save_json(out/'experiment.json',fingerprint)
    fit_views,val_views,test_views,ssim=load_scene(a);evaluate=Evaluator(ssim,a.eval_factor)
    save_json(out/'splits.json',dict(fit=[c.image_name for c in fit_views],validation=[c.image_name for c in val_views],test=[c.image_name for c in test_views],
        caveat='Stage2 excludes validation from fitting/scoring; original Stage1 reconstruction may already have used these views. Test never drives choices.'))
    save_json(out/'runtime.json',dict(gpu=torch.cuda.get_device_name(),torch=torch.__version__,renderer=_C.__file__,
        train_factor=a.train_factor,eval_factor=a.eval_factor,gradient_scope='Fixed-topology, fixed-rasterization branches; no derivative through collapse, culling or sorting'))
    state_path=out/'run-state.json'
    if state_path.exists():state=json.loads(state_path.read_text())
    else:
        source=torch.load(a.source,map_location='cpu',weights_only=False);seed=unpack(a.seed_asset)
        wire=initial_wire(source,seed);del source,seed
        initial=SharedMesh(wire);save_json(out/'initial-shared-validation.json',evaluate(initial,val_views));del initial;torch.cuda.empty_cache()
        folder=Path(tempfile.mkdtemp(prefix='dense-',dir=out))
        adapted=fit(wire,None,a.warmup_steps,fit_views,val_views,evaluate,ssim,a,folder/'adapt');del wire;gc.collect();torch.cuda.empty_cache()
        decoded,codec=export_asset(adapted,folder/'delivery');m=SharedMesh(decoded);metrics=evaluate(m,val_views);del m,decoded;torch.cuda.empty_cache()
        geo=codec['quantization_geometry']
        if geo['nonfinite_vertices'] or geo['new_zero_area_faces'] or geo['flipped_fraction']>a.max_flip_fraction:
            raise RuntimeError('Dense delivery quantization failed geometry gate; inspect codec-report.json')
        cp=folder/'accepted.pt';checkpoint(cp,adapted)
        dense=dict(stage=0,checkpoint=str(cp),delivery=codec,validation=metrics,vertices=len(adapted['triangles_points']),faces=len(adapted['_triangle_indices']))
        state=dict(next_round=0,error_limit=a.error_limit,batch_fraction=a.batch_fraction,accepted=[dense],trials=[],completed=False)
        save_json(state_path,state);del adapted
    reference=state['accepted'][0]['validation']
    for round_id in range(state['next_round'],a.rounds):
        if state['completed']:break
        previous=state['accepted'][-1];wire=torch.load(previous['checkpoint'],map_location='cpu',weights_only=False)
        folder=Path(tempfile.mkdtemp(prefix=f'round-{round_id:02d}-',dir=out))
        m=SharedMesh(wire);chosen=np.linspace(0,len(fit_views)-1,min(a.score_views,len(fit_views)),dtype=int)
        priority,score_report=importance(m,[fit_views[i] for i in chosen],a.train_factor,m.x.new_zeros(3));del m;torch.cuda.empty_cache()
        candidate,mask,build=simplify(wire,priority,state['error_limit'],state['batch_fraction']);del priority,wire;gc.collect()
        save_json(folder/'build.json',dict(build=build,scoring=score_report))
        trial=dict(round=round_id,folder=str(folder),build=build,accepted=False)
        if build['merges']==0:
            trial['reason']='No legal candidate under current error bound'
            if state['error_limit']>=a.max_error_limit:state['completed']=True
            state['error_limit']=min(a.max_error_limit,state['error_limit']*1.5)
        else:
            adapted=fit(candidate,mask,a.steps,fit_views,val_views,evaluate,ssim,a,folder/'adapt');del candidate,mask;gc.collect();torch.cuda.empty_cache()
            decoded,codec=export_asset(adapted,folder/'delivery');m=SharedMesh(decoded)
            metrics=evaluate(m,val_views);del m,decoded;torch.cuda.empty_cache()
            geo=codec['quantization_geometry']
            quality=acceptable(metrics,reference,a)
            safe=geo['nonfinite_vertices']==0 and geo['new_zero_area_faces']==0 and geo['flipped_fraction']<=a.max_flip_fraction
            cheaper=codec['file_bytes']<previous['delivery']['file_bytes'] and len(adapted['_triangle_indices'])<previous['faces']
            accepted=quality and safe and cheaper
            trial.update(accepted=accepted,quality_passed=quality,quantization_geometry_passed=safe,rate_faces_improved=cheaper,
                validation=metrics,delivery=codec)
            if accepted:
                cp=folder/'accepted.pt';checkpoint(cp,adapted)
                state['accepted'].append(dict(stage=len(state['accepted']),checkpoint=str(cp),delivery=codec,validation=metrics,
                    vertices=len(adapted['triangles_points']),faces=len(adapted['_triangle_indices'])))
                state['error_limit']=min(a.max_error_limit,state['error_limit']*1.25)
            else:
                state['batch_fraction']*=.5;state['error_limit']=max(.1,state['error_limit']*.8)
                if state['batch_fraction']<.02:state['completed']=True
            del adapted
        save_json(folder/'trial.json',trial);state['trials'].append(trial);state['next_round']=round_id+1;save_json(state_path,state)
        print('ROUND',round_id,'accepted',trial['accepted'],'stages',len(state['accepted']),flush=True)
    state['completed']=True;save_json(state_path,state)
    # All decisions above use validation only. Decode actual delivery files for test.
    import topology as tc
    from delivery import restore
    results=[]
    for stage in state['accepted']:
        done=out/f"test-stage-{stage['stage']:02d}.json"
        if done.exists():row=json.loads(done.read_text())
        else:
            with tempfile.TemporaryDirectory(dir=out) as temp:
                decoded=restore(tc.read_asset(stage['delivery']['asset'],out/'native',Path(temp)))
            m=SharedMesh(decoded);metrics=evaluate(m,test_views,out/f"png-stage-{stage['stage']:02d}");del m,decoded;torch.cuda.empty_cache()
            row=dict(stage=stage['stage'],vertices=stage['vertices'],faces=stage['faces'],file_bytes=stage['delivery']['file_bytes'],
                asset=stage['delivery']['asset'],test=metrics);save_json(done,row)
        results.append(row)
    save_json(out/'stage2-summary.json',dict(results=results,accepted_stages=len(results),trials=state['trials'],
        scope='Standalone simplified LOD assets, not progressive patches. New topology may differ. Shared representation throughout training and export.',
        quality_reference='Fixed initial dense shared asset after warmup and delivery quantization',
        no_guarantee='Actual face reduction is measured, not guaranteed. GPU gradient gate required before training.'))
    print('COMPLETE',out/'stage2-summary.json',flush=True)

if __name__=='__main__':
    raise SystemExit('The shared-first v1 workflow is retired. Run train_collapse_first.py through run_room.sh.')
