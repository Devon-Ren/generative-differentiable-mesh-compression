# Historical hierarchy coarse experiment

Run with STAGE2_ENTRY=coarse_once.py through submit_room.sh. It builds the original
delivery hierarchy C++ source unchanged, with limits 1,2,4 and selects error 2.
The wrapper uses all independent SH coefficients and actual opacity, with the
historical radiance/opacity units 0.1 and angle 80 degrees. No batch-collapse loop
or prescribed face count is used. Current input is the final trained original
mesh, so face ratios need not match older post-RDel/prepared-mesh experiments.

Default: independent coarse geometry+SH adaptation 800 steps, then dictionary
initialization and shared appearance adaptation 400 steps. Geometry uses the
local-altitude trust constraints. Set --independent-steps 0 to directly share.
Shared adaptation holds geometry fixed; this isolates shared representation loss.
Both modes use the existing q18 XYZ / q8 DC / topology arithmetic delivery codec.

All stages are measured on the same validation views. Final independent and
decoded shared assets are measured on all test views with PNGs. The prototype
exports observed results even when quality is poor; export is not quality acceptance.
Best-step-zero remains possible and is reported in each fit/adaptation.json.
The selected collapse map is an experimental sidecar and not part of the
standalone delivery stream. Decoder does not require it. This experiment exports
one coarse asset, not base-plus-refinement packets.

Outputs: coarse-summary.json, progress.json, hierarchy-report.json,
coarse-independent.pt, shared-final.pt, delivery/asset.mslb,
png-coarse/ and png-delivery/. The seed dictionary is reused for initialization,
but all vertex assignments are recomputed for the simplified geometry.

Upload historical-coarse-once-update.zip to /scratch/zr2245, then:

```bash
cd /scratch/zr2245/shared-collapse-stage2-v1
unzip -o /scratch/zr2245/historical-coarse-once-update.zip -d .
sbatch --export=ALL,STAGE2_ENTRY=coarse_once.py submit_room.sh
```

The update preserves submit_room.sh including your account. Use a fresh output
(the command above creates one automatically). No Stage 1 rerun is needed.
results.csv contains validation at every stage and original/coarse/delivery test
metrics, with real delivery MB. Validation and test numbers are different splits.
The GPU startup includes the existing renderer update check. This package has not
been tested on a full Room asset locally. The selected threshold may retain more
or less than half the original faces; no ratio is promised. A threshold with no
additional merges uses the preceding identical snapshot and is recorded as skipped.
