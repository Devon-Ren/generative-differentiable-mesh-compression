from pathlib import Path
import sys
from types import SimpleNamespace
import numpy as np
import torch
from model import SharedMesh,render
from algorithm import save_json

def load_scene(args,return_mesh=False):
    upstream=Path(args.lab).resolve()/'upstream'
    sys.path.insert(0,str(upstream/'submodules/effrdel/src'));sys.path.insert(0,str(upstream))
    from scene import Scene
    from scene.triangle_model import TriangleModel
    from utils.loss_utils import ssim
    data=SimpleNamespace(source_path=str(Path(args.dataset).resolve()),model_path=str(Path(args.source).resolve().parents[2]),images=args.images,
        resolution=1,eval=True,white_background=False,data_device='cpu',sh_degree=3)
    scene=Scene(data,TriangleModel(3),None,None,load_iteration=30000,shuffle=False)
    train=sorted(scene.getTrainCameras(),key=lambda c:(c.image_name,c.uid))
    validation=train[::8];hold={id(c) for c in validation};fit=[c for c in train if id(c) not in hold]
    test=sorted(scene.getTestCameras(),key=lambda c:(c.image_name,c.uid))
    if not fit or not validation or not test:raise ValueError('Empty split')
    return (fit,validation,test,ssim,scene.triangles) if return_mesh else (fit,validation,test,ssim)

class Evaluator:
    def __init__(self,ssim,factor):
        import lpips
        self.ssim=ssim;self.factor=factor;self.lpips=lpips.LPIPS(net='vgg').cuda().eval()
        for p in self.lpips.parameters():p.requires_grad_(False)
    @torch.no_grad()
    def __call__(self,model,cameras,png_dir=None,include_lpips=True):
        if png_dir:png_dir.mkdir(parents=True,exist_ok=True)
        rows=[]
        for i,c in enumerate(cameras):
            if i==0:render(c,model,self.factor)  # untimed device warmup
            start=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True)
            start.record();im=render(c,model,self.factor)['render'].clamp(0,1);end.record();end.synchronize()
            render_ms=start.elapsed_time(end);gt=c.original_image[:3].to(im.device)
            if not torch.isfinite(im).all():raise FloatingPointError('Nonfinite validation render')
            l1=(im-gt).abs().mean();ss=self.ssim(im,gt)
            rows.append(dict(camera=c.image_name,psnr=float(-10*torch.log10((im-gt).square().mean().clamp_min(1e-12))),
                ssim=float(ss),loss=float(.8*l1+.2*(1-ss)),render_ms=render_ms))
            if include_lpips:rows[-1]['lpips']=float(self.lpips(im[None]*2-1,gt[None]*2-1).mean())
            if png_dir:
                from PIL import Image
                for name,x in [('render',im),('gt',gt)]:Image.fromarray((x.permute(1,2,0).cpu().numpy()*255).round().clip(0,255).astype(np.uint8)).save(png_dir/f'{i:04d}-{name}.png')
        keys=('psnr','ssim','loss','render_ms')+(('lpips',) if include_lpips else ())
        return dict(**{k:float(np.mean([r[k] for r in rows])) for k in keys},views=len(rows),per_view=rows,
            timing_scope='CUDA device time: SH evaluation+rasterization+downsample; excludes decoding, metrics, PNG I/O and CPU overhead')

def export_asset(wire,folder,xyz='q18',dc='q8',weight='const',index_codec='ctx'):
    # stage2-v2: weight='const' drops per-vertex opacity logits (one constant); index_codec='ctx' context-codes the SH indices.
    import tempfile
    from codec_benchmark import pack,unpack,equal
    from delivery import prepare,restore
    import topology as tc
    folder.mkdir(parents=True,exist_ok=False)
    if index_codec not in ('ctx','zstd'):raise ValueError('index_codec')
    quant=prepare(wire,xyz,dc,True,weight);ordered,p=tc.reorder(quant,'strip-fetch');audit=tc.semantic_audit(quant,ordered,p)
    with tempfile.TemporaryDirectory(dir=folder) as temp:
        temp=Path(temp);exe=tc.lc.native(folder/'native');edge=tc.edge_native(folder/'native');ctx=tc.ic.native(folder/'native') if index_codec=='ctx' else None
        pred=tc.lc.graph(exe,ordered,temp);encoded=tc.encode(ordered,'edge-arithmetic',1,exe,edge,temp,pred,ctx)
        path=folder/'asset.mslb';info=pack(encoded,path,'auto');del encoded
        decoded=tc.decode(unpack(path),exe,edge,temp,ctx)
        equal({k:v for k,v in ordered.items() if k!='_triangle_indices'}, {k:decoded[k] for k in ordered if k!='_triangle_indices'})
        if not np.array_equal(tc.cyclic(ordered['_triangle_indices'].numpy()),tc.cyclic(decoded['_triangle_indices'].numpy())):raise AssertionError('Topology roundtrip')
    report=dict(file_bytes=path.stat().st_size,asset=str(path),sha256=tc.lc.digest(path),semantic_audit=audit,
        scope=f'XYZ={xyz}, DC={dc}, vertex_weight={weight}, indices={index_codec}; shared banks FP32; reordered edge/arithmetic codec; lossy representation',
        payload_bytes={f['name']:f.get('payload_bytes',0) for f in info['fields']})
    save_json(folder/'codec-report.json',report)
    # Health check is before vertex/face reordering, so correspondence is exact.
    from algorithm import health
    qhealth=health(wire['triangles_points'],restore(quant)['triangles_points'],wire['_triangle_indices'])
    report['quantization_geometry']=qhealth
    if weight=='const' and 'vertex_weight' in wire:
        from delivery import weight_summary
        const,err,_=weight_summary(wire);report['vertex_weight_const']=dict(value=const,max_abs_opacity_error=err)
    save_json(folder/'codec-report.json',report)
    return restore(decoded),report
