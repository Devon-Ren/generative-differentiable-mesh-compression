# Room阶段结果资料包

原始上传文件已重命名标注阶段，内容保持不变。ORIGINAL = 原件；
EXTRACTED = 从原件提取；RECONSTRUCTED = 从汇总重建。SHA-256见MANIFEST.json。

## 你要的三项

1. collapse/01_coarse-summary_ORIGINAL.json：你上传的coarse-summary原件。
   collapse/02_results_RECONSTRUCTED_FROM_SUMMARY.csv：从上述JSON重建，与聊天
   粘贴表对应；不是从HPC直接下载的原始results.csv。包含各stage validation
   和original/coarse_independent/decoded_delivery test。不可混用两种split。
2. dense/08_final-41MB-encode-summary_EXTRACTED.json：从最终拓扑实验原件提取
   strip-fetch_edge-arithmetic_xyz-ac候选，41,399,087字节。含payload_bytes。
   没有找到旧实验同名encode-summary.json原件；这里明确提供等价编码统计提取件。
   dense/09_final-41MB-field-bytes_EXTRACTED.csv：逐字段字节、非payload开销与总量。
3. CHECKPOINT_REFERENCE.json：原版Room 30k checkpoint路径、字节数、顶点/面数、
   原始SHA-256，以及历史shared和最终asset路径。checkpoint本体不在包内。

## 阶段对照

Dense 01：819.142175 MB原始独立SH资产；02：通用无损对照；
03：4096主字典+1024残差字典；04：精简字段及量化；
05：XYZ局部编码；06：重排与拓扑候选；07：对应GPU渲染检验；08/09：最终候选提取。
Collapse 01/02：error=2简化→独立SH优化→共享初始化→共享优化→最终26.883858 MB。
完整几何dense与collapse是两条不同实验路线，不要将collapse行混入dense编码消融。

## 原版checkpoint如何复用

可以用torch.load(path,map_location="cpu",weights_only=False)读取可信自己的checkpoint。
它包含triangles_points、_triangle_indices、features_dc、features_rest、vertex_weight等。
不需要GPU即可统计拓扑邻接、DC相关性、独立SH相关性。读入后先detach再转numpy。
共享字典index与DC的相关性，需要shared资产中的app_mapping/app_residual_mapping；
原始checkpoint不包含这些索引。对最终重排资产做统计时，必须使用该资产自身的
坐标/DC/索引配对，不能把最终编号直接对应到原版checkpoint编号。

这些HPC路径是历史记录；本次没有远程确认文件仍在。未找到本机Room checkpoint本体。
在HPC检查：

```bash
ls -lh /scratch/zr2245/room-fixed-sharing-0N4OSU/run/original/point_cloud/iteration_30000/point_cloud_state_dict.pt
sha256sum /scratch/zr2245/room-fixed-sharing-0N4OSU/run/original/point_cloud/iteration_30000/point_cloud_state_dict.pt
```

将哈希与CHECKPOINT_REFERENCE.json中的expected_sha256核对即可确认是同一资产。
报告只证明当时的实验结果；不能据此保证历史路径当前仍有效。
